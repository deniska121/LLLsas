local function NotNoclipUser(ply)
	if not ply:IsAdmin() then
		ply:ChatPrint( "Ноуклип доступен для администрации" )
		return false
	end
end
hook.Add( "PlayerNoClip", "RestrictUserNoclip", NotNoclipUser )