--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

McPhone.Language["es"] = {
 
    -- Main UI
   
    lang_name = "Spanish",
    settings = "Configuraciones",
    contacts = "Contactos",
    texts = "Textos",
    mail = "Correo electrónico",
    camera = "Cámara",
    GPS = "GPS",
    enter_number = "Ingresar número",
    background = "Antecedentes",
    profile = "Perfil",
    ringtone = "Tono de llamada",
    theme = "Tema",
    normal_mode = "Modo normal",
    sleep_mode = "Modo de sueño",
    silent = "Silenciosa",
    advanced = "Avanzada",
    close = "Cerrar",
   
    new_сontact = "Contacto agregada",
    text_copy = "Texto copiado!",
    my_num = "Mi número:",
    new_text = "Enviar mensaje de texto",
    point_reached = "Destino alcanzado",
    stop_gps = "Detener GPS",
   
    email_topic = "Entrar tema",
    email_last = "Último paso",
    email_fee = "Se le cobrará %s%s por enviar este correo electrónico como un anuncio. ¿Quieres continuar?",
   
    email_canceled = "Email cancelado",
    email_notenough = "¡Fondos insuficientes!",
   
    -- Config name translation
   
    ["Connecting"] = "Conectando",
    ["Connected"] = "Conectada",
    ["Not available"] = "No disponible",
    ["Busy"] = "Ocupada",
    ["Incoming"] = "Entrante",
   
    ["Theme Green"] = "Verde",
    ["Theme Orange"] = "Naranja",
    ["Theme Blue"] = "Azul",
    ["Theme Red"] = "Roja",
    ["Theme Grey"] = "Gris",
    ["Theme Purple"] = "Morada",
    ["Theme Pink"] = "Rosado",
   
    ["None"] = "Ninguna",
    ["Default"] = "Defecto",
    ["Blue Shards"] = "Fragmentos azules",
    ["Blue Angles"] = "Ángeles Azules",
    ["Blue Circles"] = "Círculos azules",
    ["Diamonds"] = "Diamantes",
    ["Green Glow"] = "Resplandor verde",
    ["Green Shards"] = "Fragmentos Verdes",
    ["Green Squares"] = "Cuadrados verdes",
    ["Green Triangles"] = "Triángulos verdes",
    ["Orange 8bit"] = "Naranja 8bit",
    ["Orange Halftone"] = "Tono medio naranja",
    ["Orange Herringbone"] = "Espina de pescado naranja",
    ["Orange Triangles"] = "Triángulos naranjas",
    ["Red Triangles"] = "Triángulos rojos",
    ["Purple Glow"] = "Resplandor púrpura",
    ["Purple Tartan"] = "Tartán morado",
   
    -- Settings
   
    on = "EN",
    off = "APAGADA",
    key_binds = "Atajos de teclado",
    ui_binds = "Teclas de interfaz de usuario",
    sets_save = "Guardar cambios y cerrar",
    server_setts = "Configuración del servidor",
    sa_notification = "Esta es la configuración del cliente, los cambios afectarán solo a usted",
    sets_mkb = "Bindigs de teclas del mouse:",
    sets_lmb = "Left MB - Botón Enter",
    sets_rmb = "MB derecho: botón Atrás",
    sets_mmb = "Middle MB (también conocido como Wheel press) - Botón de opción / Abrir teléfono",
    sets_wscr = "Desplazamiento de la rueda: navega por el teléfono",
    sets_umb = "Use los botones del mouse para controlar la interfaz de usuario del teléfono",
    sets_kupb = "Abrir teléfono / botón Arriba",
    sets_kopen = "Vuelva a unir mouse3 a mouse4 o mouse5 en caso de que lo necesite",
    sets_kdwnb = "Botón abajo",
    sets_klfb = "Botón izquierdo",
    sets_krtb = "Botón derecho",
    sets_kcls = "Cerrar teléfono",
    sets_kbkb = "Botón de retroceso",
    sets_kent = "Botón Enter",
    sets_kopt = "Botón de opciones",
    sets_reset = "Restablecer los valores predeterminados",
    sets_popup = "Teléfono emergente en llamadas entrantes",
   
    sets_manage_gps = "Teléfono emergente en llamadas entrantes",
    sets_gps_upd = "Actualizar posición",
    sets_gps_set_name = "Escoge un nombre",
    sets_gps_rmv = "Eliminar",
   
    sets_gps_info = "El marcador GPS usará su posición actual",
   
    GlobalContacts = "El jugador puede ver a todos los otros jugadores en su lista de contactos",
    Draw3DModel = "Habilite el modelo de teléfono 3D, cuando el jugador use el teléfono",
    AtmosTime = "Utilice el sistema de tiempo del complemento Atmos",
    StormFoxTime = "Use el sistema de tiempo del plugin StormFox",
    EmailFee = "Jugador cobrado por enviar un anuncio por correo electrónico",
    EmailFeeSize = "Tamaño de tarifa de correo electrónico",
    CameraWaterMark = "Marca de agua en las fotos tomadas con la cámara del teléfono",
    ServerCurensy = "Moneda del servidor",
    DarkRPLog = "Habilite los registros de administración de DarkRP en la consola (registros de llamadas, sms y correo electrónico)",
   
    go_back = "regreso",
    sets_new_gps = "Añadir nueva posición gps",
   
    hint_1 = "¡Puedes acceder a tu teléfono!",
    hint_2 = "Presione la tecla ARRIBA o el botón central del mouse",
   
    -- Update 1.4 stuff
 
    phone = "Teléfono",
    last_owner = "Último dueño",
   
    cancel = "Cancelar",
    close_nosave = "Cerrar sin guardar",
   
    sets_ply_cursor = "Habilite la entrada del cursor en el teléfono emergente en lugar de la navegación de botones",
   
    sets_dropphone = "Permitir a los jugadores soltar su teléfono",
    sets_dropphone_command = "Comando de caída del teléfono",
   
    hint_dropphone = "Para soltar su teléfono, escriba este comando de chat:",
   
    sets_givephone = "Dale al jugador un teléfono cuando aparezca",
    sets_phone_death = "El jugador pierde su teléfono al morir",
    sets_phone_disconnect = "El jugador pierde su teléfono al desconectarse",
   
    dropphone_error_1 = "No puedes soltar el teléfono ahora",
    dropphone_error_2 = "No tienes teléfono para soltar",
   
    web = "Web",
   
    char_pd = "Departamento de Policia",
    char_911 = "Servicios de emergencia",
    char_taxi = "Servicios de taxi",
    char_dealer = "Distribuidor",
    char_lester = "Lester",
   	
	-- Update 1.4a +
	
	drp_support_ef = "El sistema de tarifas de correo electrónico solo admite DarkRP por ahora",
	
	manage_conts = "Gestionar contactos",
	cont_removed = "¡Contacto eliminado!",
	sets_ply_volume = "Cambiar el volumen de sonido de la interfaz de usuario",

    -- 1.1.8+

    sets_ep1 = "Configuración de Extension Pack One",
    ["Command"] = "Mando",
    ["Smoke"] = "Fumar",
    ["RelWeb"] = "Sitios web más relevantes",
    
    -- EP1
    
    NumberOnly = "Ingrese solo números",
    Watermark = "Filigrana",
    Currency = "Moneda",
    ShowZones = "Muestra el rango de la zona de la torre en el espacio 3D (solo para administradores)",
    TowerRangebasedNet = "Base la señal del teléfono en el alcance de la torre",
    TowerMaxRange = "Alcance máximo de la torre",
    InUnits = "Ingrese el número (Unidades de juego)",
    HP = "Ingrese el número (unidades de salud)",
    InSeconds = "Ingrese el número en segundos",
    DestructibleTowers = "Torres destruibles",
    TowerHealth = "Salud de la torre",
    TowerRepairTime = "Tiempo de reparación automática de la torre",
    JammerRange = "Rango máximo de Jammer",
    JammerLiveTime = "Tiempo de eliminación automática de Jammer",
    DestructibleJammer = "Jammer destructible",
    JammerHealth = "Salud de Jammer",
    SaveTower = "Guarde todas las torres en este mapa",
    SpawnTower = "Genera una torre frente a ti",
    RemoveTowers = "Eliminar todas las torres de este mapa",

}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
