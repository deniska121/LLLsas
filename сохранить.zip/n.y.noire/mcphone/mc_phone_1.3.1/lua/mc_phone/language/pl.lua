--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000


McPhone.Language["pl"] = {

	-- Main UI
	
	lang_name = "Polskie",
	settings = "Ustawienia",
	contacts = "Kontakty",
	texts = "Teksty",
	mail = "Email",
	camera = "Aparat",
	GPS = "GPS",
	enter_number = "Wpisz numer",
	background = "Tapeta",
	profile = "Profil",
	ringtone = "Dzwonki",
	theme = "Motyw",
	normal_mode = "Zwykły tryb",
	sleep_mode = "Tryb snu",
	silent = "Cichy",
	advanced = "Zaawansowane",
	close = "Zamknij",
	
	new_сontact = "Kontakt dodany",
	text_copy = "Tekst skopiowany!",
	my_num = "Mój numer:",
	new_text = "Wyślij wiadomość",
	point_reached = "Punkt docelowy osiągnięty",
	stop_gps = "Stop GPS",
	
	email_topic = "Wpisz temat",
	email_last = "Ostatni krok",
	email_fee = "Za wysłanie tego emaila jako reklamy zostaje naliczona opłata %s%s. Czy chcesz kontynuować?",
	
	email_canceled = "Email anulowany",
	email_notenough = "Nie wystarczająco pieniędzy!",
	
	-- Config name translation
	
	["Connecting"] = "Łączenie",
	["Connected"] = "Połączony",
	["Not available"] = "Nie dostępny",
	["Busy"] = "Zajęty",
	["Incoming"] = "Przychodzący",
	
	["Theme Green"] = "Zielony",
	["Theme Orange"] = "Pomarańczowy",
	["Theme Blue"] = "Niebieski",
	["Theme Red"] = "Czerwony",
	["Theme Grey"] = "Szary",
	["Theme Purple"] = "Fioletowy",
	["Theme Pink"] = "Różowy",
	
	["None"] = "Żaden",
	["Default"] = "Podstawowy",
	["Blue Shards"] = "Niebieskie odłamki",
	["Blue Angles"] = "Niebieskie kąty",
	["Blue Circles"] = "Niebieskie kółka",
	["Diamonds"] = "Diamenty",
	["Green Glow"] = "Zielona poświata",
	["Green Shards"] = "Zielone odłamki",
	["Green Squares"] = "Zielone kwadraty",
	["Green Triangles"] = "Zielone trójkąty",
	["Orange 8bit"] = "Pomarańczowy 8bit",
	["Orange Halftone"] = "Pomarańczowy półtony",
	["Orange Herringbone"] = "Pomarańczowo jodełkowy",
	["Orange Triangles"] = "Pomarańczowe trójkąty",
	["Red Triangles"] = "Czerwone trójkąty",
	["Purple Glow"] = "Fioletowa poświata",
	["Purple Tartan"] = "Fioletowy tartan",
	
	-- Settings
	
	on = "WŁĄCZONY",
	off = "WYŁĄCZONY",
	key_binds = "Przypisy klawiszy",
	ui_binds = "Powiązania klawiszy interfejsu użytkownika",
	sets_save = "Zapisz zmiany i Zamknij",
	server_setts = "Ustawienia serwera",
	sa_notification = "To są ustawienia klienta, zobaczysz je tylko u Siebie.",
	sets_mkb = "Przypisy myszy:",
	sets_lmb = "Lewy MB - Przycisk enter",
	sets_rmb = "Prawy MB - Przycisk powrotu",
	sets_mmb = "Środkowy MB (aka przyciśnięcie kółka) - Przycisk opcji / Otwórz telefon",
	sets_wscr = "Przewijanie kółkiem - Nawiguj po telefonie",
	sets_umb = "Użyj przycisków myszy aby kontrolować telefon",
	sets_kupb = "Otwórz telefon / Strzałka w górę",
	sets_kopen = "Powiąż mouse3 z mouse4 lub mouse5 w razie potrzeby",
	sets_kdwnb = "Strzałka w dół",
	sets_klfb = "Strzałka w lewo",
	sets_krtb = "Strzałka w prawo",
	sets_kcls = "Zamknij telefon",
	sets_kbkb = "Przycisk cofnij",
	sets_kent = "Przycisk enter",
	sets_kopt = "Przycisk opcji",
	sets_reset = "Resetuj do domyślnych",
	sets_popup = "Wyskakujący telefon na połączeniach przychodzących",
	
	sets_manage_gps = "Zarządzaj markerami GPS",
	sets_gps_upd = "Aktualizuj pozycję",
	sets_gps_set_name = "Zmień nazwę",
	sets_gps_rmv = "Usuń",
	
	sets_gps_info = "Znacznik GPS użyje aktualniej pozycji",
	
	GlobalContacts = "Gracz może widzieć wszystkich innych graczy w jego liście kontaktów",
	Draw3DModel = "Włącz 3D model telfonu, gdy gracz go używa",
	AtmosTime = "Użyj addonu Atmos do systemu czasu",
	StormFoxTime = "Użyj addonu StormFox do systemu czasu",
	EmailFee = "Koszt za wysłanie email ogłoszenia",
	EmailFeeSize = "Rozmiar opłaty za email",
	CameraWaterMark = "Znak wodny na zdjęciach wykonanych aparatem telfonu",
	ServerCurensy = "Waluta serwera",
	DarkRPLog = "Włącz DarkRP logi admina w konsoli (logi do połączeń, sms oraz email)",
	
	go_back = "Wróć",
	sets_new_gps = "Dodaj nowy punkt GPS",
	
	hint_1 = "Możesz uzyskać dostęp do telefonu!",
	hint_2 = "Wciśnij strzałkę w górę lub kółko na myszce",
	
	phone = "Telefon",
    last_owner = "Ostatni wlasciciel",
    
    cancel = "Anuluj",
    close_nosave = "Anuluj bez zapisywania",
    
    sets_ply_cursor = "Wlacz myszke w telefonie do nawigacji zamiast przyciskow",
    
    sets_dropphone = "Pozwol graczom na wyrzucenie telefonu",
    sets_dropphone_command = "Komenda na wyrzucenie telefonu",
    
    hint_dropphone = "Aby wyrzucic telefon wpisz:",
    
    sets_givephone = "Daj graczom telefon gdy sie zrespia",
    sets_phone_death = "Gracz traci telefon przy smierci",
    sets_phone_death = "Gracz traci telefon przy opuszczeniu serwera",
    
    dropphone_error_1 = "Nie mozesz teraz wyrzucic telefonu",
    dropphone_error_2 = "Nie masz telefonu do wyrzucenia",
    
    web = "Strona",
    
    char_pd = "Komisariat Policji",
    char_911 = "Numer alarmowy",
    char_taxi = "Taxi",
    char_dealer = "Diler",
    char_lester = "Lester",
		
	-- Update 1.4a +
	
	drp_support_ef = "System kosztów na chwilę obecną jest wspierany wyłącznie przez tryby bazowane na DarkRP",

    manage_conts = "Zarządzaj kontaktami",
    cont_removed = "Kontakt skutecznie usunięty z listy!",
    sets_ply_volume = "Zmień głośność dźwięków UI",
	
	-- Update 1.8+
	
	sets_ep1 = "Dodatek nr. 1 - Ustawienia",
	["Command"] = "Komenda",
	["Smoke"] = "Dym",
	["RelWeb"] = "Odpowiednie witryny",
 
	-- EP1
 
	NumberOnly = "Wprowadź wyłącznie cyfry",
	Watermark = "Watermark",
	Currency = "Waluta",
	ShowZones = "Pokazuj zakres zasięgu radiostacji (Tylko dla administracji)",
	TowerRangebasedNet = "Zasięg telefonu jest zależny od odległości od radiostacji",
	TowerMaxRange = "Maksymalny zasięg radiostacji",
	InUnits = "Wprowadź numer (Game Units)",
	HP = "Wprowadź numer (Health Units)",
	InSeconds = "Wprowadź numer w sekundach",
	DestructibleTowers = "Destrukcja radiostacji",
	TowerHealth = "Życie radiostacji",
	TowerRepairTime = "Czas automatycznej naprawy",
	JammerRange = "Maksymalny zasięg jammera",
	JammerLiveTime = "Czas automatycznego usuwania jammera",
	DestructibleJammer = "Zniszczenie jammera",
	JammerHealth = "Życie jammera",
	SaveTower = "Zapisz wszystkie radiostacje na mapie",
	SpawnTower = "Postaw radiostacje przed tobą",
	RemoveTowers = "Usuń wszystkie radiostacje z mapy",
}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
