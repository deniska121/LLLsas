--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

McPhone.Language["dk"] = {
 
    -- Main UI
   
    lang_name = "Danish",
    settings = "Indstillinger",
    contacts = "Kontakter",
    texts = "Beskeder",
    mail = "Email",
    camera = "Kamera",
    GPS = "GPS",
    enter_number = "Skriv nummer",
    background = "Baggrund",
    profile = "Profil",
    ringtone = "Ringetone",
    theme = "Tema",
    normal_mode = "Normal tilstand",
    sleep_mode = "Sove tilstand",
    silent = "Lydløs",
    advanced = "Advanceret",
    close = "Luk",
   
    new_сontact = "Kontakt tilføjet",
    text_copy = "Besked kopiret!",
    my_num = "Mit Num:",
    new_text = "Send besked",
    point_reached = "Destination nået",
    stop_gps = "Stop GPS",
   
    email_topic = "Skriv Emne",
    email_last = "Sidste Trin",
    email_fee = "Du får trukket %s%s for at sende denne email som en advert. Vil du fortsætte?",
   
    email_canceled = "Email annulleret",
    email_notenough = "Ugyldige midler!",
   
    -- Config name translation
   
    ["Connecting"] = "Tilslutter",
    ["Connected"] = "Tilsluttet",
    ["Not available"] = "Ikke tilgængelig",
    ["Busy"] = "Travl",
    ["Incoming"] = "Indgående",
   
    ["Theme Green"] = "Grøn",
    ["Theme Orange"] = "Orange",
    ["Theme Blue"] = "Blå",
    ["Theme Red"] = "Rød",
    ["Theme Grey"] = "Grå",
    ["Theme Purple"] = "Lilla",
    ["Theme Pink"] = "Pink",
   
    ["None"] = "Ingen",
    ["Default"] = "Standard",
    ["Blue Shards"] = "Blå Kort",
    ["Blue Angles"] = "Blå Engle",
    ["Blue Circles"] = "Blå Cirkler",
    ["Diamonds"] = "Diamanter",
    ["Green Glow"] = "Grøn Lys",
    ["Green Shards"] = "Grønne Kort",
    ["Green Squares"] = "Grønne Firkanter",
    ["Green Triangles"] = "Grønne Trekanter",
    ["Orange 8bit"] = "Orange 8bit",
    ["Orange Halftone"] = "Orange Halvtone",
    ["Orange Herringbone"] = "Orange Herringbone",
    ["Orange Triangles"] = "Orange Trekanter",
    ["Red Triangles"] = "Røde Trekanter",
    ["Purple Glow"] = "Lilla Lys",
    ["Purple Tartan"] = "Lilla Tartan",
   
    -- Settings
   
    on = "TÆNDT",
    off = "SLUKKET",
    key_binds = "Tast tilknytninger",
    ui_binds = "UI tast tilknytninger",
    sets_save = "Gem ændringer og luk",
    server_setts = "Server indstillinger",
    sa_notification = "Dette er klientenside indstillinger, ændringer påvirker kun dig",
    sets_mkb = "Mus tast tilknytninger:",
    sets_lmb = "Venstreklik - Enter button",
    sets_rmb = "Højreklik - Back button",
    sets_mmb = "Mellemklik (aka scroll/hjul) - Indstilling knap / Åben Telefon",
    sets_wscr = "Hjul scroll - Naviger igennem telefon",
    sets_umb = "Brug museknapperne til at kontrollere telefonens UI",
    sets_kupb = "Åben telefon / Pil Op",
	sets_kopen = "Bind musen3 til musen4 eller musen5, hvis du har brug for det",
    sets_kdwnb = "Pil Ned",
    sets_klfb = "Venstre Pil",
    sets_krtb = "Højre Pil",
    sets_kcls = "Luk telefon",
    sets_kbkb = "Tilbage knap",
    sets_kent = "Bekræft knap",
    sets_kopt = "Indstillinger knap",
    sets_reset = "Genindstil til standard",
    sets_popup = "Pop-op telefon ved opkald",
   
    sets_manage_gps = "Bestyr GPS markører",
    sets_gps_upd = "Opdater position",
    sets_gps_set_name = "Sæt navn",
    sets_gps_rmv = "Fjern",
   
    sets_gps_info = "GPS markøren vil bruge din nuværende position",
   
    GlobalContacts = "Spilleren kan se alle andre spillere på sin kontaktliste",
    Draw3DModel = "Aktiver 3D-telefonmodel, når en spiller bruger telefonen",
    AtmosTime = "Brug Atmos addons tidssystem",
    StormFoxTime = "Brug StormFox addons tidssystem",
    EmailFee = "Opkræv penge fra spilleren for at sende en e-mail-annonce",
    EmailFeeSize = "Email gebyrstørrelse",
    CameraWaterMark = "Vandmærke på fotos taget via telefonens kamera",
    ServerCurensy = "Servervaluta",
    DarkRPLog = "Aktiver DarRP admin logs i konsollen (logger for opkald, sms og e-mail)",
   
    go_back = "Gå tilbage",
    sets_new_gps = "Tilføj ny GPS-position",
   
    hint_1 = "Du har nu adgang til din tlf!",
    hint_2 = "Tryk Pil OP eller Mellemklik",
	
	phone = "Telefon",
    last_owner = "Sidste ejer",
    
    cancel = "Annuller",
    close_nosave = "Luk uden at gemme",
    
    sets_ply_cursor = "Slå mus til på telefon popup istedet for tast navigation",
    
    sets_dropphone = "Tillad for spillere at kunne smide deres telefon",
    sets_dropphone_command = "Smid telefon kommando",
    
    hint_dropphone = "For at smide din telefon skal du skrive denne kommando:",
    
    sets_givephone = "Giv spiller en telefon når vedkommende spawner",
    sets_phone_death = "Spillere mister sin telefon når vedkommende dør",
    sets_phone_death = "Spillere mister sin telefon når vedkommende leaver",
    
    dropphone_error_1 = "Du kan ikke smide din telefon lige nu",
    dropphone_error_2 = "Du har ingen telefon du kan smide",
    
    web = "Web",
    
    char_pd = "Politistationen",
    char_911 = "Hospitalet",
    char_taxi = "Taxa",
    char_dealer = "Dealer",
    char_lester = "Lester",
    	
	-- Update 1.4a +
	
	drp_support_ef = "E-mail-gebyrsystem understøttes i øjeblikket kun af DarkRP",
	
	manage_conts = "Administrer kontakter",
	cont_removed = "Kontakt fjernet!",
	sets_ply_volume = "Skift lydstyrken på brugergrænsefladen",

	-- 1.1.8+
	
	sets_ep1 = "Udvidelses pakke et indstillinger",
	["Command"] = "Kommando",
	["Smoke"] = "Røg",
	["RelWeb"] = "Mest relevante hjemmesider",
 
	-- EP1
 
	NumberOnly = "Indtast kun numre",
	Watermark = "Vandmærke",
	Currency = "Valuta",
	ShowZones = "Vis tårn radius med 3D (kun for admins)",
	TowerRangebasedNet = "Baser telefon signalet på tårn radius",
	TowerMaxRange = "Tårnets maksimum radius",
	InUnits = "Indtast nummer (Spil Enheder)",
	HP = "Indtast nummer (Liv Enheder)",
	InSeconds = "Indtast nummer i sekunder",
	DestructibleTowers = "Ødelæggelig tårne",
	TowerHealth = "Tårn liv",
	TowerRepairTime = "Tårn automatisk reparations tid",
	JammerRange = "Jammer maksimum radius",
	JammerLiveTime = "Jammer automatisk fjernelse tid",
	DestructibleJammer = "Ødelæggelig jammer",
	JammerHealth = "Jammer liv",
	SaveTower = "Gem alle tårnene på dette map",
	SpawnTower = "Placer et tårn foran dig",
	RemoveTowers = "Fjern alle tårne fra dette map",

}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
