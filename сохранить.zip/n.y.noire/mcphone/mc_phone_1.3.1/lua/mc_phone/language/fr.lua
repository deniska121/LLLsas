--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000


McPhone.Language["fr"] = {

	-- Main UI
	
	lang_name = "Français",
	settings = "Paramètres",
	contacts = "Contacts",
	texts = "Messages",
	mail = "Email",
	camera = "Appareil Photo",
	GPS = "GPS",
	enter_number = "Entrez le numéro",
	background = "Fond d'écran",
	profile = "Profil",
	ringtone = "Sonnerie",
	theme = "Theme",
	normal_mode = "Mode normal",
	sleep_mode = "Mode veille",
	silent = "Silencieux",
	advanced = "Avancé",
	close = "Fermer",
	
	new_сontact = "Contact ajouté !",
	text_copy = "Message copié !",
	my_num = "Mon numéro:",
	new_text = "Envoyer un message",
	point_reached = "Destination atteinte",
	stop_gps = "Arrêter le GPS",
	
	email_topic = "Entrez le sujet",
	email_last = "Dernière étape",
	email_fee = "Vous serez facturé %s%s pour envoyer cet email comme une publicité. Voulez-vous continuer ?",
	
	email_canceled = "Email annulé",
	email_notenough = "Fonds insuffisants !",
	
	-- Config name translation
	
	["Connecting"] = "Connexion",
	["Connected"] = "Connecté",
	["Not available"] = "Pas disponible",
	["Busy"] = "Occupé",
	["Incoming"] = "Entrant",
	
	["Theme Green"] = "Vert",
	["Theme Orange"] = "Orange",
	["Theme Blue"] = "Bleu",
	["Theme Red"] = "Rouge",
	["Theme Grey"] = "Gris",
	["Theme Purple"] = "Violet",
	["Theme Pink"] = "Rose",
	
	["None"] = "Aucun",
	["Default"] = "Défaut",
	["Blue Shards"] = "Fragments bleus",
	["Blue Angles"] = "Anges bleus",
	["Blue Circles"] = "Cercles bleus",
	["Diamonds"] = "Diamants",
	["Green Glow"] = "Lueur verte",
	["Green Shards"] = "Fragments Verts",
	["Green Squares"] = "Carrés verts",
	["Green Triangles"] = "Triangles verts",
	["Orange 8bit"] = "Orange 8bit",
	["Orange Halftone"] = "Demi-teinte orange",
	["Orange Herringbone"] = "Chevrons oranges",
	["Orange Triangles"] = "Triangles Oranges",
	["Red Triangles"] = "Triangles Rouge",
	["Purple Glow"] = "Lueur violette",
	["Purple Tartan"] = "Rose Tartan",
	
	-- Settings
	
	on = "ON",
	off = "OFF",
	key_binds = "Raccourcis clavier",
	ui_binds = "Liaisons de touches d'interface utilisateur",
	sets_save = "Sauvegarder et fermer",
	server_setts = "Paramètres du serveur",
	sa_notification = "Il s'agit de paramètres côté client, les modifications n'affecteront que vous",
	sets_mkb = "Reliures des touches de la souris :",
	sets_lmb = "Clic gauche - Touche Entrer",
	sets_rmb = "Clic droit - Bouton retour",
	sets_mmb = "Clic de la molette - Bouton d'option / Ouvrir le téléphone",
	sets_wscr = "Défilement de la molette - Naviguer sur le téléphone",
	sets_umb = "Utilisez les boutons de la souris pour contrôler le téléphone",
	sets_kupb = "Ouvrir le téléphone / Bouton haut",
	sets_kopen = "Liez mouse3 à mouse4 ou mouse5 au cas où vous en auriez besoin",
	sets_kdwnb = "Bouton bas",
	sets_klfb = "Bouton gauche",
	sets_krtb = "Bouton droit",
	sets_kcls = "Fermer le téléphone",
	sets_kbkb = "Touche retour",
	sets_kent = "Touche entrer",
	sets_kopt = "Bouton option",
	sets_reset = "Réinitialiser les paramètres par défaut",
	sets_popup = "Téléphone éphémère pour les appels entrants",
	
	sets_manage_gps = "Gérer les marqueurs GPS",
	sets_gps_upd = "Mettre à jour la position",
	sets_gps_set_name = "Définir le nom",
	sets_gps_rmv = "Retirer",
	
	sets_gps_info = "Le marqueur GPS utilisera votre position actuelle",
	
	GlobalContacts = "Le joueur peut voir tous les autres joueurs dans sa liste de contacts",
	Draw3DModel = "Activer le modèle de téléphone 3D, lorsque le joueur utilise le téléphone",
	AtmosTime = "Utiliser le système de temps de l'addon Atmos",
	StormFoxTime = "Utiliser le système de temps de l'addon StormFox",
	EmailFee = "Charge le joueur pour l'envoi d'une annonce par e-mail",
	EmailFeeSize = "Taille des frais de messagerie",
	CameraWaterMark = "Filigrane sur les photos prises via l'appareil photo du téléphone",
	ServerCurensy = "Devise du serveur",
	DarkRPLog = "Activer les journaux d'administration DarkRP dans la console (journaux d'appels, sms et e-mails)",
	
	go_back = "Retourner",
	sets_new_gps = "Ajouter une nouvelle position GPS",
	
	hint_1 = "Vous pouvez accéder à votre téléphone !",
	hint_2 = "Appuyez sur la touche HAUT ou sur la molette de la souris",
	
	phone = "Portable",
    last_owner = "Dernier propriétaire",
    
    cancel = "Annuler",
    close_nosave = "Fermer sans enregistrer",
    
    sets_ply_cursor = "Activer le curseur du téléphone 'Pop-up' au lieu de la navigation par bouton",
    
    sets_dropphone = "Autoriser les joueurs à jeter leur téléphone",
    sets_dropphone_command = "Commande utilisé pour jeter le téléphone",
    
    hint_dropphone = "Pour jeter votre téléphone, taper cette commande de tchat :",
    
    sets_givephone = "Donner de manière automatique, un téléphone au 'spawn'",
    sets_phone_death = "Le joueur perd son téléphone quand il meurt",
    sets_phone_death = "Le joueur perd son téléphone quand il se déconnecté",
    
    dropphone_error_1 = "Vous ne pouvez pas jeter votre téléphone",
    dropphone_error_2 = "Vous n'avez pas de téléphone à jeter",
    
    web = "Internet",
    
    char_pd = "Services de police",
    char_911 = "Services d'urgence",
    char_taxi = "Services de taxi",
    char_dealer = "Dealer",
    char_lester = "Lester",
		
	-- Update 1.4a +
	
	drp_support_ef = "Le système de frais de messagerie n'est pris en charge que par DarkRP pour le moment",
	
	manage_conts = "Gérer les contacts",
	cont_removed = "Contact supprimé!",
	sets_ply_volume = "Modifier le volume de l'interface utilisateur",

	-- 1.1.8 +
	
	sets_ep1 = "Extention Pack One Settings",
	["Command"] = "Commander",
	["Smoke"] = "Fumée",
	["RelWeb"] = "Sites Web les plus pertinents",

	-- EP1

	NumberOnly = "Saisissez uniquement des chiffres",
	Watermark = "Filigrane",
	Currency = "Devise",
	ShowZones = "Afficher la plage de zone de la tour dans l'espace 3D (uniquement pour les administrateurs)",
	TowerRangebasedNet = "Basez le signal du téléphone sur la portée de la tour",
	TowerMaxRange = "Portée maximale de la tour",
	InUnits = "Entrez le numéro (Unités de jeu)",
	HP = "Entrez le numéro (unités de santé)",
	InSeconds = "Entrez le nombre en secondes",
	DestructibleTowers = "Tours destructibles",
	TowerHealth = "Santé de la tour",
	TowerRepairTime = "Temps de réparation automatique de la tour",
	JammerRange = "Portée maximale du brouilleur",
	JammerLiveTime = "Heure de suppression automatique du brouilleur",
	DestructibleJammer = "Brouilleur destructible",
	JammerHealth = "Santé du brouilleur",
	SaveTower = "Enregistrer toutes les tours sur cette carte",
	SpawnTower = "faites apparaître une tour devant vous",
	RemoveTowers = "Supprimer toutes les tours de cette carte",
	
}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
