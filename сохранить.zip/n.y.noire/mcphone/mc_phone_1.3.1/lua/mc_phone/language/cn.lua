--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000


McPhone.Language["cn"] = {

	-- Main UI
	
	lang_name = "Chinese",
	settings = "设置",
	contacts = "联络",
	texts = "文本",
	mail = "邮箱",
	camera = "相机",
	GPS = "GPS",
	enter_number = "输入号码",
	background = "背景",
	profile = "个人资料",
	ringtone = "铃声",
	theme = "主题",
	normal_mode = "普通模式",
	sleep_mode = "勿扰模式",
	silent = "静音",
	advanced = "高级",
	close = "关闭",
	
	new_сontact = "联系人已添加",
	text_copy = "文本已复制！",
	my_num = "我的号码:",
	new_text = "发送信息",
	point_reached = "到达目的地",
	stop_gps = "关闭GPS",
	
	email_topic = "输入主题",
	email_last = "上一步",
	email_fee = "你将被收取%s%s的费用，因为你把这封邮件作为广告发送。你想继续吗？",
	
	email_canceled = "邮件被取消",
	email_notenough = "资金不足！",
	
	-- Config name translation
	
	["Connecting"] = "拨打中",
	["Connected"] = "已接通",
	["Not available"] = "不可用",
	["Busy"] = "忙碌",
	["Incoming"] = "来电",
	["No Signal"] = "无信号",
	
	["Theme Green"] = "绿色",
	["Theme Orange"] = "橙色",
	["Theme Blue"] = "蓝色",
	["Theme Red"] = "红石",
	["Theme Grey"] = "灰色",
	["Theme Purple"] = "紫色",
	["Theme Pink"] = "粉色",
	
	["None"] = "无",
	["Default"] = "默认",
	["Blue Shards"] = "蓝色碎片",
	["Blue Angles"] = "蓝色角",
	["Blue Circles"] = "蓝色圆圈",
	["Diamonds"] = "钻石",
	["Green Glow"] = "绿色辉光",
	["Green Shards"] = "绿色碎片",
	["Green Squares"] = "绿色方阵",
	["Green Triangles"] = "绿色三角",
	["Orange 8bit"] = "橙色八位",
	["Orange Halftone"] = "橙色半调",
	["Orange Herringbone"] = "橙色人字",
	["Orange Triangles"] = "橙色三角",
	["Red Triangles"] = "红色三角",
	["Purple Glow"] = "紫色辉光",
	["Purple Tartan"] = "紫色格子",
	["Smoke"] = "烟雾",
	
	-- Settings
	
	on = "开",
	off = "关",
	key_binds = "按键绑定",
	ui_binds = "界面键绑定",
	sets_save = "保存更改并关闭",
	server_setts = "服务器设置",
	sa_notification = "这是客户端的设置，更改只会影响你自己",
	sets_mkb = "鼠标按键绑定:",
	sets_lmb = "左键 - 回车键",
	sets_rmb = "右键 - 返回键",
	sets_mmb = "中键 - 选项键/打开手机",
	sets_wscr = "滚动滚轮 - 在手机中导航",
	sets_umb = "使用鼠标控制手机用户界面",
	sets_kupb = "打开手机/上键",
	sets_kopen = "如果需要,请将鼠标3键重新绑定到鼠标4键或鼠标5键",
	sets_kdwnb = "下键",
	sets_klfb = "左键",
	sets_krtb = "右键",
	sets_kcls = "关闭手机",
	sets_kbkb = "返回键",
	sets_kent = "回车键",
	sets_kopt = "选项键",
	sets_reset = "重置为默认值",
	sets_popup = "来电时弹出电话",
	
	sets_manage_gps = "管理GPS标记",
	sets_gps_upd = "更新位置",
	sets_gps_set_name = "设置名称",
	sets_gps_rmv = "移除",
	
	sets_gps_info = "GPS标记将使用你的当前位置",
	
	GlobalContacts = "玩家可以在他的联系人列表中看到所有的其他玩家",
	Draw3DModel = "当玩家使用手机时，启用3D手机模型",
	AtmosTime = "使用Atmos插件的时间系统。",
	StormFoxTime = "使用StormFox插件的时间系统",
	EmailFee = "对发送电子邮件广告的玩家收费",
	EmailFeeSize = "电子邮件费用",
	CameraWaterMark = "在手机用摄像头拍摄时照片加上水印",
	ServerCurensy = "服务器币种",
	DarkRPLog = "在控制台中启用DarkRP管理日志（通话、短信和电子邮件的日志）。",
	
	go_back = "返回",
	sets_new_gps = "添加新的GPS位置",
	
	hint_1 = "你可以访问你的手机!",
	hint_2 = "按上键或鼠标中键",
	
	-- Update 1.4

	phone = "手机",
	last_owner = "最后拥有者",
	cancel = "权限",
	close_nosave = "关闭而不保存",
	sets_ply_cursor = "在手机弹出时启用光标输入，而不是按钮导航。",
	sets_dropphone = "允许玩家丢弃手机",
	sets_dropphone_command = "丢弃手机指令",
	hint_dropphone = "要丢弃手机，请输入这个聊天命令：",
	sets_givephone = "出生时给玩家一部手机",
	sets_phone_death = "玩家在死亡时丢失手机",
	sets_phone_disconnect = "玩家在断线时丢失手机",
	dropphone_error_1 = "你现在不能丢弃手机",
	dropphone_error_2 = "你没有手机可丟",
	web = "网页",
	char_pd = "警察局",
	char_911 = "紧急服务",
	char_taxi = "出租车服务",
	char_dealer = "经销商",
	char_lester = "莱斯特",
	
	-- Update 1.4a +
	
	drp_support_ef = "电子邮件收费系统暂时只支持DarkRP。",
	
	manage_conts = "管理联系人",
	cont_removed = "联系人已删除！",
	sets_ply_volume = "改变用户界面的音量",

	-- Update 1.8+

	sets_ep1 = "扩展包一设置",
	["Command"] = "指令",
	["Smoke"] = "烟雾",
	["RelWeb"] = "最相关的网站",

	-- EP1

	NumberOnly = "只能输入数字",
	Watermark = "水印",
	Currency = "币种",
	ShowZones = "在游戏中显示信号塔范围(仅适用于管理员)",
	TowerRangebasedNet = "根据信号塔范围来判断电话信号",
	TowerMaxRange = "信号塔最大范围",
	InUnits = "输入数字（游戏单位）",
	HP = "输入数字（血量单位）",
	InSeconds = "以秒为单位输入数字",
	DestructibleTowers = "可破坏信号塔",
	TowerHealth = "信号塔血量",
	TowerRepairTime = "信号塔自动修复时间",
	JammerRange = "干扰器最大范围",
	JammerLiveTime = "干扰器自动移除时间",
	DestructibleJammer = "可破坏干扰器",
	JammerHealth = "干扰器血量",
	SaveTower = "保存此地图上的所有信号塔",
	SpawnTower = "在你面前生成一座信号塔",
	RemoveTowers = "移除该地图的所有信号塔",
	
}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
