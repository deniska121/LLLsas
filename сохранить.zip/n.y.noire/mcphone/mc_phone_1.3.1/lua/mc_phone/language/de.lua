--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

McPhone.Language["de"] = {

	-- Main UI
	
	lang_name = "Deutsch",
	settings = "Einstellungen",
	contacts = "Kontakte",
	texts = "Nachrichten",
	mail = "Email",
	camera = "Kamera",
	GPS = "GPS",
	enter_number = "Nummer eingeben",
	background = "Hintergrund",
	profile = "Profil",
	ringtone = "Klingelton",
	theme = "Theme",
	normal_mode = "Normaler Modus",
	sleep_mode = "Schlaf Modus",
	silent = "Lautlos",
	advanced = "Erweitert",
	close = "Schließen",
	
	new_сontact = "Kontakt hinzugefügt",
	text_copy = "Nachricht kopiert!",
	my_num = "Meine Nummer:",
	new_text = "Abschicken",
	point_reached = "Ziel erreicht",
	stop_gps = "GPS stoppen",
	
	email_topic = "Betreff eingeben",
	email_last = "Schritt zurück",
	email_fee = "Diese Email als Werbung zu versenden kostet dich %s%s. Möchtest du fortfahren?",
	
	email_canceled = "Email abgebrochen",
	email_notenough = "Nicht genug Geld!",
	
	-- Config name translation
	
	["Connecting"] = "Versuche Verbindung aufzubauen",
	["Connected"] = "Verbunden",
	["Not available"] = "Nicht verfügbar",
	["Busy"] = "Beschäftigt",
	["Incoming"] = "Eingehend",
	
	["Theme Green"] = "Grün",
	["Theme Orange"] = "Orange",
	["Theme Blue"] = "Blau",
	["Theme Red"] = "Rot",
	["Theme Grey"] = "Grau",
	["Theme Purple"] = "Violett",
	["Theme Pink"] = "Pink",
	
	["None"] = "Nichts",
	["Default"] = "Standart",
	["Blue Shards"] = "Blaue Scherben",
	["Blue Angles"] = "Blaue Winkel",
	["Blue Circles"] = "Blaue Kreise",
	["Diamonds"] = "Diamanten",
	["Green Glow"] = "Grünes Leuchten",
	["Green Shards"] = "Grüne Scherben",
	["Green Squares"] = "Grüne Quadrate",
	["Green Triangles"] = "Grüne Dreiecke",
	["Orange 8bit"] = "Orange 8bit",
	["Orange Halftone"] = "Orange Halbton",
	["Orange Herringbone"] = "Orange Fischgrätenmuster",
	["Orange Triangles"] = "Orange Dreiecke",
	["Red Triangles"] = "Rote Dreiecke",
	["Purple Glow"] = "Violettes Leuchten",
	["Purple Tartan"] = "Violettes Karo",
	
	-- Settings
	
	on = "AN",
	off = "AUS",
	key_binds = "Tastenbelegungen",
	ui_binds = "UI-Tastenbelegungen",
	sets_save = "Änderungen speichern und schließen",
	server_setts = "Server Einstellungen",
	sa_notification = "Dies sind clientseitige Einstellungen. Sie wirken sich nur auf dich aus",
	sets_mkb = "Maus-Tastenbelegungen:",
	sets_lmb = "Linksklick - Vorwärts",
	sets_rmb = "Rechtsklick - Zurück",
	sets_mmb = "Mausrad Druck - Optionen / Telefon öffnen",
	sets_wscr = "Mausrad Scrollen - Durch das Telefon navigieren",
	sets_umb = "Verwende die Maustasten um durch die Benutzeroberfläche zu navigieren",
	sets_kopen = "Binden Sie mouse3 erneut an mouse4 oder mouse5, falls Sie dies benötigen",
	sets_kupb = "Telefon öffnen / Pfeil nach oben",
	sets_kdwnb = "Pfeil nach unten",
	sets_klfb = "Pfeil nach rechts",
	sets_kcls = "Telefon Schließen",
	sets_kbkb = "Zurück Taste",
	sets_kent = "Vorwärts Taste",
	sets_kopt = "Options Taste",
	sets_reset = "Auf Standardeinstellung zurücksetzen",
	sets_popup = "Popup-Telefon für eingehende Anrufe",
	
	sets_manage_gps = "GPS-Marker verwalten",
	sets_gps_upd = "Position aktualisieren",
	sets_gps_set_name = "Name setzen",
	sets_gps_rmv = "Entfernen",
	
	sets_gps_info = "Der GPS-Marker verwendet deine aktuelle Position",
	
	GlobalContacts = "Spieler können alle anderen Spieler in ihrer Kontaktliste sehen",
	Draw3DModel = "3D Modell aktivieren, wenn Spieler das Telefon benutzen",
	AtmosTime = "Verwende das Zeitsystem von Atmos",
	StormFoxTime = "Verwende das Zeitsystem von StormFox",
	EmailFee = "Lasse Spieler für Werbung per Email zahlen",
	EmailFeeSize = "Email Gebühr",
	CameraWaterMark = "Wasserzeichen auf Bildern, die mit der Telefon kamera aufgenommen wurden",
	ServerCurensy = "Server währung",
	DarkRPLog = "Aktiviere DarkRP-Admin-Logs in der Konsole (Logs für Anrufe, SMS und Emails)",
	
	go_back = "Geh zurück",
	sets_new_gps = "Neue GPS-Position hinzufügen",
	
	hint_1 = "Du kannst dein Telefon benutzen",
	hint_2 = "Drück die Pfeiltaste oben oder das Mausrad",
	
	phone = "Telefon",
    last_owner = "Letzter Besitzer",
    
    cancel = "Abbrechen",
    close_nosave = "Schließen ohne zu speichern",
    
    sets_ply_cursor = "Aktiviere den Mauszeiger auf dem Handy anstelle der Navigation per Tastatur",
    
    sets_dropphone = "Erlaube Spielern ihr Handy fallen zu lassen",
    sets_dropphone_command = "Handy Drop Kommand",
    
    hint_dropphone = "Gebe diesen Befehl in den Chat ein, um dein Telefon fallen zu lassen:",
    
    sets_givephone = "Gib Spielern beim Spawnen ein Telefon",
    sets_phone_death = "Spieler verlieren ihr Handy, wenn sie sterben",
    sets_phone_death = "Spieler verlieren ihr Handy, wenn sie die Verbindung trennen",
    
    dropphone_error_1 = "Du kannst dein Telefon derzeit nicht fallen lassen",
    dropphone_error_2 = "Du hast kein Telefon, das du fallen lassen könntest",
    
    web = "Internet",
    
    char_pd = "Polizei",
    char_911 = "Notdienste",
    char_taxi = "Taxidienste",
    char_dealer = "Dealer",
    char_lester = "Lester",
		
	-- Update 1.4a +
	
	drp_support_ef = "Das E-Mail-Gebührensystem wird derzeit nur von DarkRP unterstützt",
	
	manage_conts = "Kontakte verwalten",
	cont_removed = "Kontakt entfernt!",
	sets_ply_volume = "Ändern Sie die Lautstärke der Benutzeroberfläche",

	-- 1.1.8+

	sets_ep1 = "Einstellungen für Erweiterungspaket 1",
	["Command"] = "Befehl",
	["Smoke"] = "Rauch",
	["RelWeb"] = "Relevanteste Websites",

	-- EP1
	
	NumberOnly = "Geben Sie nur Zahlen ein",
	Watermark = "Wasserzeichen",
	Currency = "Währung",
	ShowZones = "Turm reichweite im Spiel anzeigen (Nur für Admins)",
	TowerRangebasedNet = "Das Telefonsignal von Turmentfernung abhängig machen",
	TowerMaxRange = "Maximale Reichweite des Turms",
	InUnits = "Nummer eingeben (Spieleinheiten)",
	HP = "Nummer eingeben (Gesundheitseinheiten)",
	InSeconds = "Nummer in Sekunden eingeben",
	DestructibleTowers = "Zerstörbare Türme",
	TowerHealth = "Turmgesundheit",
	TowerRepairTime = "Autoreparaturzeit des Turms",
	JammerRange = "Störsender maximale Reichweite",
	JammerLiveTime = "Zeit zum automatischen Entfernen des Störsenders",
	DestructibleJammer = "Zerstörbarer Störsender",
	JammerHealth = "Störsender Gesundheit",
	SaveTower = "Speichern Sie alle Türme auf dieser Karte",
	SpawnTower = "Spawne einen Turm vor dir",
	RemoveTowers = "Entferne alle Türme von dieser Karte",
}
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
