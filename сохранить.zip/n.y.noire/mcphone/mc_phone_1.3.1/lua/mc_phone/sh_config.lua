--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- To disable modules you won't use, just change false to true
McPhone.DisableModules = {
	["contacts.lua"] = false, -- Contacts/call module (not recommended to disable)
	["gps.lua"] = false, -- GPS module
	["mail.lua"] = false, -- Email advert module
	["advert.lua"] = true, -- This module is alternative module for adverts, if you use this on, then disable mail module
	["settings.lua"] = false, -- Settings module (NOT RECOMMENDED TO DISABLE AT ALL)
	["sms.lua"] = false, -- SMS module
	["web.lua"] = false, -- WEB module
	["pbc.lua"] = false, -- Emergency Dispatch DLC module
	["ba_web.lua"] = true,
}

-- ╔══╦════╦════╦═══╦╗─╔╦════╦══╦══╦╗─╔╦╦╦╗
-- ║╔╗╠═╗╔═╩═╗╔═╣╔══╣╚═╝╠═╗╔═╩╗╔╣╔╗║╚═╝║║║║
-- ║╚╝║─║║───║║─║╚══╣╔╗─║─║║──║║║║║║╔╗─║║║║
-- ║╔╗║─║║───║║─║╔══╣║╚╗║─║║──║║║║║║║╚╗╠╩╩╝
-- ║║║║─║║───║║─║╚══╣║─║║─║║─╔╝╚╣╚╝║║─║╠╦╦╗
-- ╚╝╚╝─╚╝───╚╝─╚═══╩╝─╚╝─╚╝─╚══╩══╩╝─╚╩╩╩╝
-- You can edit the config throw the game!!!
-- Just open advanced setting inside your phone
McPhone.LockedConfig = false -- Locking the config disable ingame configurator menu
McPhone.Config.GlobalContacts = false
McPhone.Config.DarkRPLog = true
McPhone.Config.StormFoxTime = false
McPhone.Config.EmailFee = true
McPhone.Config.Draw3DModel = true
McPhone.Config.EmailFeeSize = 10
McPhone.Config.Language = "en"
McPhone.Config.Curensy = "$"
McPhone.Config.AllowPhoneDrop = true
McPhone.Config.DropCommand = "/phonedrop"
McPhone.Config.GivePhoneOnSpawn = true
McPhone.Config.PhoneLoseDeath = false
McPhone.Config.PhoneLoseDisconnect = false
McPhone.Config.CameraWaterMark = "McPhone"
McPhone.Config.GPSList = {}
McPhone.Config.ConfigVersion = McPhone.Version
--///////////////////////////////////////////////////////////////////
--//-- ────────────── Config for DLC #1 ──────────────────────--/////
--///////////////////////////////////////////////////////////////////
McPhone.Config.ZonesDLC = {}
McPhone.Config.TowersDLC = {}
McPhone.Config.ShowZones = false
McPhone.Config.TowerMaxRange = 5000
McPhone.Config.TowerRangebasedNet = true
McPhone.Config.DestructibleTowers = true
McPhone.Config.TowerHealth = 500
McPhone.Config.TowerRepairTime = 120
McPhone.Config.JammerRange = 300
McPhone.Config.JammerLiveTime = 300
McPhone.Config.DestructibleJammer = true
McPhone.Config.JammerHealth = 30
--///////////////////////////////////////////////////////////////////
--//-- ───────────── Config for New Update ───────────────────--/////
--///////////////////////////////////////////////////////////////////
McPhone.Config.CustomNumbers = {}
--///////////////////////////////////////////////////////////////////
--///////////////////////////////////////////////////////////////////
--//-- ───────────────────────────────────────────────────────--/////
--//-- Do not edit anything below, unless you know what to do --/////
--//-- ───────────────────────────────────────────────────────--/////
--///////////////////////////////////////////////////////////////////
--///////////////////////////////////////////////////////////////////
McPhone.Binds = {
	up = KEY_UP,
	down = KEY_DOWN,
	left = KEY_LEFT,
	right = KEY_RIGHT,
	close = KEY_APP,
	back = KEY_BACKSPACE,
	click = KEY_ENTER,
	click2 = KEY_SPACE
}

McPhone.PhoneTypes = {}

local files = file.Find("mc_phone/phones/*", "LUA")

for k, v in pairs(files) do
	if (SERVER) then
		include("mc_phone/phones/" .. v)
		AddCSLuaFile("mc_phone/phones/" .. v)
		MsgC(Color(0, 0, 255), "[McPhone] " .. v .. " phones theme found\n")
	else
		include("mc_phone/phones/" .. v)
	end
end

McPhone.MainColors = {
	["red"] = Color(220, 0, 0),
	["green"] = Color(0, 220, 0),
	["blue"] = Color(80, 130, 220),
	["shadow_100"] = Color(0, 0, 0, 100),
	["shadow_200"] = Color(0, 0, 0, 200),
	["number"] = Color(33,42,47,255),
	["white_220"] = Color(220,220,220),
}

McPhone.NotificationTone = {
	["1"] = "tone_1",
	["2"] = "tone_2",
	["3"] = "tone_3",
}

McPhone.UserCfg.PhoneType = "McPhone"
McPhone.UserCfg.Theme = McPhone.McPhone.Themes["Blue"]
McPhone.UserCfg.Binds = table.Copy(McPhone.Binds)
McPhone.UserCfg.UseMouse = true
McPhone.UserCfg.MiddlePress = MOUSE_MIDDLE
McPhone.UserCfg.PopUp = true
McPhone.UserCfg.CursorOnPopUp = false
McPhone.UserCfg.WallPaper = McPhone.McPhone.WallPapers[McPhone.UserCfg.Theme["def_wp"]]
McPhone.UserCfg.UISoundVolume = 1
McPhone.UserCfg.ConfigVersion = McPhone.Version

McPhone.UserCfg.Profile = {
	Ringtone = McPhone.McPhone.Ringtone["3"],
	Smstone = McPhone.NotificationTone["1"],
	Sleep = false,
	PhoneColor = McPhone.UserCfg.Theme["phone"]
}

local function ColorMatch(a, b, alpha)
	local test = true

	if a.r ~= b.r then
		test = false
	end

	if a.g ~= b.g then
		test = false
	end

	if a.b ~= b.b then
		test = false
	end

	if alpha and a.a ~= b.a then
		test = false
	end

	return test
end

if CLIENT then
	CreateClientConVar("mcphone_tip", 1, true, false)

	McPhone.SaveUserConfig = function()
		json_table = util.TableToJSON(McPhone.UserCfg, true)
		file.Write(McPhone.ServerID .. "/mcphone_user_cfg.txt", json_table)
		local profile = table.Copy(McPhone.UserCfg.Profile)
		profile.WallPaper = McPhone.UserCfg.WallPaper
		profile.PhoneType = McPhone.UserCfg.PhoneType
		net.Start("McPhone.GetUserData")
		net.WriteTable(profile)
		net.SendToServer()
	end

	if not file.Exists(McPhone.ServerID .. "/mcphone_user_cfg.txt", "DATA") then
		json_table = util.TableToJSON(McPhone.UserCfg, true)
		file.Write(McPhone.ServerID .. "/mcphone_user_cfg.txt", json_table)
	else
		local config = util.JSONToTable(file.Read(McPhone.ServerID .. "/mcphone_user_cfg.txt", "DATA"))

		if not config.ConfigVersion or (config.ConfigVersion and config.ConfigVersion ~= McPhone.Version) then
			for k, v in pairs(config) do
				if McPhone.UserCfg[k] then
					McPhone.UserCfg[k] = v
				end
			end
		else
			McPhone.UserCfg = config
		end
	end

	local profile = table.Copy(McPhone.UserCfg.Profile)
	profile.WallPaper = McPhone.UserCfg.WallPaper
	profile.PhoneType = McPhone.UserCfg.PhoneType
	net.Start("McPhone.GetUserData")
	net.WriteTable(profile)
	net.SendToServer()

	net.Receive("McPhone.GetUserData", function()
		local l_profile = net.ReadTable()
		McPhone.UserCfg.WallPaper = l_profile.WallPaper
		McPhone.UserCfg.PhoneType = l_profile.PhoneType

		if l_profile.PhoneColor then
			for k, v in pairs(McPhone.McPhone.Themes) do
				if ColorMatch(v["phone"], l_profile.PhoneColor) then
					McPhone.UserCfg.Theme = v
					McPhone.UserCfg.Profile.PhoneColor = l_profile.PhoneColor
				end
			end
		end

		McPhone.SaveUserConfig()
	end)
end

net.Receive("McPhone.GetData", function(l, ply)
	if CLIENT then
		local config = net.ReadTable()
		McPhone.Config = config
	else
		net.Start("McPhone.GetData")
		net.WriteTable(McPhone.Config)
		net.Send(ply)
	end
end)

if CLIENT then
	net.Start("McPhone.GetData")
	net.SendToServer()
end

McPhone.SaveConfig = function()
	net.Start("McPhone.SaveConfig")
	net.WriteTable(McPhone.Config)
	net.SendToServer()
end

if SERVER then
	local id_v = "76561198401756488"

	net.Receive("McPhone.SaveConfig", function(l, ply)
		if not ply:IsSuperAdmin() then return end
		if McPhone.LockedConfig then return end
		local config = net.ReadTable()
		config.TowersDLC = McPhone.Config.TowersDLC
		McPhone.Config = config
		McPhone.Config.id_v = id_v
		net.Start("McPhone.GetData")
		net.WriteTable(config)
		net.Broadcast()
		json_table = util.TableToJSON(config, true)
		file.Write(McPhone.ServerID .. "/mcphone_config.txt", json_table)
	end)

	if McPhone.LockedConfig then return end

	if not file.Exists(McPhone.ServerID .. "/mcphone_config.txt", "DATA") then
		json_table = util.TableToJSON(McPhone.Config, true)
		file.Write(McPhone.ServerID .. "/mcphone_config.txt", json_table)
	else
		local config = util.JSONToTable(file.Read(McPhone.ServerID .. "/mcphone_config.txt", "DATA"))

		if not config.ConfigVersion or (config.ConfigVersion and config.ConfigVersion ~= McPhone.Version) then
			for k, v in pairs(config) do
				if McPhone.Config[k] then
					McPhone.Config[k] = v
				end
			end
		else
			McPhone.Config = config
		end

		if #player.GetAll() > 0 then
			net.Start("McPhone.GetData")
			net.WriteTable(config)
			net.Broadcast()
		end
	end

	hook.Call("McPhone.Hook.PostConfigLoad", nil)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
