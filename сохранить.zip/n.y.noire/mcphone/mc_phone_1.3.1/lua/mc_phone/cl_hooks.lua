--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
local ply = LocalPlayer()
local snap = 0
local ScrW, ScrH = ScrW, ScrH
McPhone.key = 5

local function SwipeUp()
	if McPhone.UI and snap < CurTime() and (McPhone.key - 3) > 0 then
			McPhone.key = McPhone.key - 3
			snap = CurTime() + 0.2
			local but = McPhone.UI.Menu:GetItems()[McPhone.key]

			if but and not but:GetDisabled() then
				but:OnCursorEntered()
				McPhone.UI.Menu:ScrollToChild(but)
			end
	end
end

McPhone.ClosePhone = function()
	if McPhone.UI and not McPhone.UI.Closing then
		McPhone.StopCall()
		McPhone.PlaySoundUI("mc_phone/toggle.wav")
		snap = CurTime() + 1
		McPhone.UI:MoveTo(McPhone.UI:GetPos(), ScrH(), 0.2)
		McPhone.UI.Closing = CurTime() + 1
	end
	hook.Call("McPhone.Hook.ClosePhone", nil)
end

McPhone.GoBack = function()
	McPhone.StopCall()
	if not McPhone.UI then return end

	if McPhone.UI.GoBack and snap < CurTime() then
		snap = CurTime() + 0.5
		McPhone.UI.GoBack()
		local but = McPhone.UI.Menu:GetItems()[McPhone.key]

		if but and not but:GetDisabled() then
			but:OnCursorEntered()
		end

		if McPhone.UI.Menu.List then
			McPhone.key = 1
		else
			McPhone.key = 5
		end

		but = McPhone.UI.Menu:GetItems()[McPhone.key]

		if but and not but:GetDisabled() then
			but:OnCursorEntered()
		end
	elseif snap < CurTime() then
		McPhone.ClosePhone()
	end
end

McPhone.OpenMainMenu = function()
	McPhone.StopCall()
	if not McPhone.UI then return end

	if McPhone.UI.MainMenuOpen then
		McPhone.UI.MainMenuOpen()
	end

	McPhone.UI.GoBack = false
end

local function SwipeDown()
	if McPhone.UI and snap < CurTime() and (McPhone.key + 3) <= #McPhone.UI.Menu:GetItems() then
			McPhone.key = McPhone.key + 3
			snap = CurTime() + 0.2
			local but = McPhone.UI.Menu:GetItems()[McPhone.key]

			if but and not but:GetDisabled() then
				but:OnCursorEntered()
				McPhone.UI.Menu:ScrollToChild(but)
			end
	end
end

McPhone.EnterPress = function()
	if McPhone.UI and snap < CurTime() then
		snap = CurTime() + 0.5

		if McPhone.AcceptCall then
			McPhone.AcceptCall()
		end

		if McPhone.UI.Buttons.Middle[3] and not McPhone.UI.Buttons.Middle[4] then
			McPhone.UI.Buttons.Middle[3]()

			return
		end

		local but = McPhone.UI.Menu:GetItems()[McPhone.key]
		local supress

		if but and not but:GetDisabled() then
			supress = but:DoClick()
		end

		if not supress then
			McPhone.key = 1
			but = McPhone.UI.Menu:GetItems()[McPhone.key]

			if but and not but:GetDisabled() then
				but:OnCursorEntered()
			end
		end
	end
end

local function SwipeRight()
	if McPhone.UI and snap < CurTime() then
		if #McPhone.UI.Menu:GetItems() <= 1 then return end
		McPhone.key = McPhone.key + 1

		if McPhone.key > #McPhone.UI.Menu:GetItems() then
			McPhone.key = 1
		end

		snap = CurTime() + 0.2
		local but = McPhone.UI.Menu:GetItems()[McPhone.key]

		if but and not but:GetDisabled() then
			but:OnCursorEntered()
			McPhone.UI.Menu:ScrollToChild(but)
		end
	end
end

local function SwipeLeft()
	if McPhone.UI and snap < CurTime() then
		if #McPhone.UI.Menu:GetItems() <= 1 then return end
		McPhone.key = McPhone.key - 1

		if McPhone.key < 1 then
			McPhone.key = #McPhone.UI.Menu:GetItems()
		end

		snap = CurTime() + 0.2
		local but = McPhone.UI.Menu:GetItems()[McPhone.key]

		if but and not but:GetDisabled() then
			but:OnCursorEntered()
			McPhone.UI.Menu:ScrollToChild(but)
		end
	end
end

local function MiddlePress()
	if McPhone.UI.Buttons.Left[3] and snap < CurTime() then
		snap = CurTime() + 0.5
		McPhone.UI.Buttons.Left[3]()
		McPhone.key = 1
		local but = McPhone.UI.Menu:GetItems()[McPhone.key]

		if but and not but:GetDisabled() then
			but:OnCursorEntered()
		end
	end
end

hook.Add("Think", "McPhone.Think", function()

	if McPhone.OnCall and McPhone.UI and isnumber(McPhone.OnCall) and McPhone.OnCall < CurTime() then
		McPhone.OpenMainMenu()
	end

	if McPhone.UI and not McPhone.CanUsePhone(ply) then
		McPhone.ClosePhone()
		snap = CurTime() + 0.2

		return
	end

	if ply:IsTyping() then return end
	if gui.IsConsoleVisible() then return end
	if gui.MousePos() > 0 then return end
	if not ply:GetNWBool("McPhone.HasPhone") then return end

	if (input.IsKeyDown(McPhone.UserCfg.Binds.up) or (not McPhone.UI and McPhone.UserCfg.UseMouse and input.IsMouseDown(McPhone.UserCfg.MiddlePress))) and snap < CurTime() then
		if not McPhone.UI then
			McPhone.LoadAddons()
			McPhone.Open(1)
			snap = CurTime() + 0.2
		else
			if McPhone.UI and McPhone.UI.Menu then
				if McPhone.UI.Menu.List then
					SwipeLeft()
				else
					SwipeUp()
				end
			end
		end
	end

	if McPhone.UI and McPhone.UI.Menu and not McPhone.UI.Closing then
		if (input.IsKeyDown(McPhone.UserCfg.Binds.back)) and snap < CurTime() then
			McPhone.GoBack()
		end

		if (input.IsKeyDown(McPhone.UserCfg.Binds.click)) and snap < CurTime() then
			McPhone.EnterPress()
		end

		if (input.IsKeyDown(McPhone.UserCfg.Binds.right)) and snap < CurTime() then
			SwipeRight()
		end

		if (input.IsKeyDown(McPhone.UserCfg.Binds.left)) and snap < CurTime() then
			SwipeLeft()
		end

		if (input.IsKeyDown(McPhone.UserCfg.Binds.click2) or (McPhone.UserCfg.UseMouse and input.IsMouseDown(McPhone.UserCfg.MiddlePress))) and snap < CurTime() then
			MiddlePress()
		end

		if (input.IsKeyDown(McPhone.UserCfg.Binds.down)) and snap < CurTime() then
			if McPhone.UI.Menu.List then
				SwipeRight()
			else
				SwipeDown()
			end
		end
	end

	if (input.IsKeyDown(McPhone.UserCfg.Binds.close) or input.IsKeyDown(KEY_ESCAPE)) and snap < CurTime() then
		McPhone.ClosePhone()
	end
end)

local phone_types = {
	["McPhone"] = {"models/mactavish/mactavish_phone.mdl", Vector(4.2, 1.3, -2.2), Angle(-5, -8, -30)},
	["Badger"] = {"models/mactavish/bg_phone.mdl", Vector(4.5, 1, 1), Angle(-5, -8, -30)},
	["Bloom"] = {"models/mactavish/lm_phone.mdl", Vector(4.2, 0.8, 1), Angle(-5, -8, -30)},
	["payphone"] = {"models/props_trainstation/payphone_reciever001a.mdl", Vector(-10, 4.2, -16.5), Angle(-30, 90, 20)},
}

hook.Add("PostPlayerDraw", "McPhone.PostPlayerDraw", function(Ply)
	if not McPhone.Config.Draw3DModel then return end
	if not Ply:IsValid() then return end

	if Ply:GetNWInt("McPhone.Active") > 0 then
		local Source = IsValid(ovr) and ovr or Ply
		local Bone = Source:LookupBone("ValveBiped.Bip01_L_Hand")

		if not Bone then
			if Ply.McPhoneModel then
				Ply.McPhoneModel:Remove()
				Ply.McPhoneModel = nil
			end

			return
		end

		local mat = Source:GetBoneMatrix(Bone)

		if mat then
			local pos, ang = mat:GetTranslation(), mat:GetAngles()
			local phone_t = phone_types[Ply:GetNWString("McPhone.Type")] or phone_types["McPhone"]
			local color = Ply:GetNWVector("McPhone.Color")

			if Ply:GetNWInt("McPhone.Active") == 2 then
				phone_t = phone_types["payphone"]
				color = nil
			end

			local pos2 = phone_t[2]
			local angle = phone_t[3]
			local LocalPhone = Ply.McPhoneModel
			ang:RotateAroundAxis(ang:Up(), angle.y)
			ang:RotateAroundAxis(ang:Right(), angle.p)
			ang:RotateAroundAxis(ang:Forward(), angle.r)
			local model = phone_t[1]

			if not LocalPhone then
				LocalPhone = ClientsideModel(model, RENDERGROUP_OPAQUE)
				LocalPhone:SetNoDraw(true)
				Ply.McPhoneModel = LocalPhone
			end

			LocalPhone:SetPos(pos + ang:Forward() * pos2.x + ang:Right() * pos2.y + ang:Up() * pos2.z)
			LocalPhone:SetAngles(ang)
			if color then
				LocalPhone:SetColor(Color(color.x, color.z, color.y))
				render.SetColorModulation(color.x / 255, color.z / 255, color.y / 255)
			end
			LocalPhone:DrawModel()
			render.SetColorModulation(1, 1, 1)
		else
			if Ply.McPhoneModel then
				Ply.McPhoneModel:Remove()
				Ply.McPhoneModel = nil
			end
		end
	elseif Ply.McPhoneModel then
		Ply.McPhoneModel:Remove()
		Ply.McPhoneModel = nil
	end
end)

McPhone.HudNotification = function() end

McPhone.HudTip = function()
	if GetConVar("mcphone_tip"):GetInt() > 0 and ply:GetNWBool("McPhone.HasPhone") then
		local x, y = ScrW() - 350, ScrH() - 60
		draw.RoundedBox(0, x, y, 325, 55, Color(0, 0, 0, 100))
		McPhone.DrawTexturedRect(x, y, 325, 55, "gui/gradient", Color(0, 0, 0, 100))
		draw.SimpleTextOutlined(McPhone.GetPhrase("hint_1"), "McPhone.Main28", x + 10, y + 5, Color(255, 200, 100, 255), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, 255))
		draw.SimpleTextOutlined(McPhone.GetPhrase("hint_2"), "McPhone.Main20", x + 10, y + 30, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, 255))
	end
end

McPhone.HudGPS = function() end

McPhone.HudPhoneModel = function()
	for _, ent in pairs(ents.FindByClass("mc_phone*")) do
		if ent:GetPos():Distance(ply:GetPos()) < 200 then
			local alpha = math.Clamp(1 - (ply:GetPos():Distance(ent:GetPos()) / 100), 0, 1)
			local screenpos = ent:GetPos():ToScreen()
			local x, y = screenpos.x, screenpos.y - 50
			local owner = ent:GetNWString("Last Owner")
			draw.SimpleTextOutlined(McPhone.GetPhrase("phone"), "McPhone.Main28", x, y, McPhone.Alpha(ent:GetColor(), alpha * 255), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, alpha * 255))

			if owner and owner ~= "" then
				draw.SimpleTextOutlined(McPhone.GetPhrase("last_owner") .. ": " .. owner, "McPhone.Main24", x, y + 22, Color(255, 255, 255, alpha * 255), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, alpha * 255))
			end
		end
	end
end

McPhone.ToggleGPS = function(name, pos)
	if McPhone.IsGPSOn then
		McPhone.IsGPSOn = nil
		McPhone.HudGPS = function() end

		if McPhone.GPSMenuRebuild and McPhone.UI then
			McPhone.GPSMenuRebuild()
		end

		McPhone.GPSMenuRebuild = nil
	else
		if not name or not pos then return end
		McPhone.IsGPSOn = name
		local alpha = 0

		McPhone.HudGPS = function()
			local dist = ply:GetPos():Distance(pos) * 0.75 / 25.4
			local screenpos = pos:ToScreen()
			local w = ScrW()
			local x, y = screenpos.x, screenpos.y - 50

			if dist < 20 then
				x, y = Lerp(1 - dist / 20, x, w / 2), Lerp(1 - dist / 20, y, 200)
			end

			if x < w / 4 or x > w - w / 4 then
				alpha = Lerp(FrameTime() * 7, alpha, 0)

				if x < 30 then
					x = 30
				end
			else
				alpha = Lerp(FrameTime() * 7, alpha, 255)
			end

			if y < 50 then
				y = 50
			end

			if x > ScrW() - 64 then
				x = ScrW() - 64
			end

			if y > ScrH() - 64 then
				y = ScrH() - 64
			end

			McPhone.DrawTexturedRect(x - 32, y - 30, 64, 64, "mc_phone/icons/gps.png", Color(0, 0, 0, 200))
			McPhone.DrawTexturedRect(x - 32, y - 32, 64, 64, "mc_phone/icons/gps.png", Color(255, 200, 100, 255))
			draw.SimpleTextOutlined(name, "McPhone.Main32", x + 30, y - 30, Color(255, 200, 100, alpha), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, alpha))
			draw.SimpleTextOutlined(math.floor(dist) .. " m", "McPhone.Main28", x + 30, y, Color(255, 255, 255, alpha), TEXT_ALIGN_LEFT, 0, 1, Color(0, 0, 0, alpha))

			if dist < 5 then
				McPhone.ToggleGPS()
				McPhone.Notify("GPS", McPhone.GetPhrase("point_reached"), true)
			end
		end
	end
end

hook.Add("HUDPaint", "McPhone.HUDPaint", function()
	McPhone.HudNotification()
	McPhone.HudGPS()
	McPhone.HudTip()
	McPhone.HudPhoneModel()

	if McPhone.UI then
		local w, h = ScrW(), ScrH()
		local m = Matrix()
		local center = Vector( w - McPhone.UI:GetWide() - 25, h - McPhone.UI:GetTall() + 25 )

		m:Translate( center )
		m:Rotate(Angle(0, 0, 0))
		m:Scale(Vector(1, 1, 1))
		--m:Translate( -center )

		cam.PushModelMatrix( m )
			McPhone.UI:PaintManual()
		cam.PopModelMatrix()
	end
end)

local bind_block = {
	["+attack"] = true,
	["+attack2"] = true,
	["invprev"] = true,
	["invnext"] = true,
	["+jump"] = true,
}

hook.Add("PlayerBindPress", "McPhone.PlayerBindPress", function(Ply, bind, pressed)
	if McPhone.UI and not McPhone.UI.Closing then
		if gui.MousePos() > 0 then return end

		if McPhone.UI.Buttons.Left[3] and McPhone.UserCfg.Binds.click2 == KEY_SPACE then
			bind_block["+jump"] = true
		else
			bind_block["+jump"] = false
		end

		if bind_block[bind] and McPhone.UserCfg.UseMouse then
			if snap < CurTime() then
				if bind == "invprev" then
					SwipeLeft()
				end

				if bind == "invnext" then
					SwipeRight()
				end

				if bind == "+attack" then
					McPhone.EnterPress()
				end

				if bind == "+attack2" then
					McPhone.GoBack()
				end

				snap = CurTime() + 0.2
			end

			return true
		end
	end
end)

hook.Add("UpdateAnimation", "McPhone.UpdateAnimation", function(Ply)
	if not McPhone.Config.Draw3DModel then return end
	Ply.PhoneGestureWeight = Ply.PhoneGestureWeight or 0
	if (Ply:IsPlayingTaunt()) then return end

	if Ply:GetNWInt("McPhone.Active") == 1 then
		Ply.PhoneGestureWeight = math.Approach(Ply.PhoneGestureWeight, 0.29, FrameTime() * 1.5)
	elseif Ply:GetNWInt("McPhone.Active") == 2 then
		Ply.PhoneGestureWeight = math.Approach(Ply.PhoneGestureWeight, 0.6, FrameTime() * 1.5)
	else
		Ply.PhoneGestureWeight = math.Approach(Ply.PhoneGestureWeight, 0, FrameTime() * 1.5)
	end

	if (Ply.PhoneGestureWeight > 0) then
		Ply:AnimRestartGesture(GESTURE_SLOT_VCD, ACT_GMOD_IN_CHAT, true)
		Ply:AnimSetGestureWeight(GESTURE_SLOT_VCD, Ply.PhoneGestureWeight)
	end
end)
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
