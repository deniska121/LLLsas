--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
util.AddNetworkString("McPhone.CallStart")
util.AddNetworkString("McPhone.CallDeny")
util.AddNetworkString("McPhone.CallAccept")
util.AddNetworkString("McPhone.CallExtraNumber")
util.AddNetworkString("McPhone.Accept")
util.AddNetworkString("McPhone.End")
util.AddNetworkString("McPhone.Notify")
util.AddNetworkString("McPhone.PhoneStatus")
util.AddNetworkString("McPhone.GetData")
util.AddNetworkString("McPhone.SaveConfig")
util.AddNetworkString("McPhone.GetUserData")
util.AddNetworkString("McPhone.CallBuisy")
util.AddNetworkString("McPhone.CallNotAv")
util.AddNetworkString("McPhone.PayPhone")
--For Sup.Addons
util.AddNetworkString("McPhone.RelProp.BuySellProperties")
util.AddNetworkString("McPhone.GlorifiedBanking.DataRequested")
util.AddNetworkString("McPhone.GlorifiedBanking.TransferRequested")

function McPhone.CanTalk(ply, inc)
	return McPhone.CanUsePhone(ply, false, inc)
end

function McPhone.Notify(ply, title, text, snd)
	if not IsValid(ply) then return end
	net.Start("McPhone.Notify")
	net.WriteString(title)
	net.WriteString(text)
	net.WriteBool(snd)
	net.Send(ply)
end

net.Receive("McPhone.CallExtraNumber", function(l, caller)
	caller.McPhoneInCall = false

	if timer.Exists("McPhoneCall" .. caller:AccountID()) then
		timer.Remove("McPhoneCall" .. caller:AccountID())
	end
end)

net.Receive("McPhone.CallStart", function(l, caller)
	if caller.McPhoneCallDelay and caller.McPhoneCallDelay > CurTime() then
		MsgC(Color(255, 0, 0), "Spam call from " .. caller:Name() .. " | " .. caller:SteamID(), Color(255, 155, 0), " Added 5 second penalty\n")
		caller.McPhoneCallDelay = CurTime() + 5
		return
	end

	local c_type, payphone = {0,0}, false
	if caller.McPayPhone then
		c_type, payphone = {1,2}, true
	end

	if not McPhone.CanTalk(caller) then return end
	caller.McPhoneCallDelay = CurTime() + 1
	local number = net.ReadString()

	receiver = McPhone.GetByNumber(number)

	if istable(receiver) then
		if receiver.delay_func and McPhone.ExtraNumbersFunc[receiver.delay_func](caller) then
			net.Start("McPhone.CallNotAv")
				net.WriteBool(payphone)
			net.Send(caller)

			return
		end

		caller.McPhoneInCall = true
		net.Start("McPhone.CallExtraNumber")
			net.WriteTable(receiver)
			net.WriteBool(payphone)
		net.Send(caller)
		hook.Call("McPhone.Hook.ExtraNumberCalled", nil, caller, receiver)

		timer.Create("McPhoneCall" .. caller:AccountID(), 5 + receiver.delay, 1, function()
			if IsValid(caller) then
				caller.McPhoneInCall = false
			end
		end)

		return
	end

	if not IsValid(receiver) then
		net.Start("McPhone.CallNotAv")
			net.WriteBool(payphone)
		net.Send(caller)
		hook.Call("McPhone.Hook.UnsuccessCall", nil, caller, number)

		return
	end

	if not unsecsess and receiver == caller then return end

	if not unsecsess and not McPhone.CanTalk(receiver, true) then
		net.Start("McPhone.CallNotAv")
			net.WriteBool(payphone)
		net.Send(caller)
		hook.Call("McPhone.Hook.UnsuccessCall", nil, caller, number)

		return
	end

	if not unsecsess and receiver.McPhoneOnCall or receiver.McPhoneInCall or receiver.McPhoneCalling or not McPhone.CanTalk(caller) then
		net.Start("McPhone.CallBuisy")
			net.WriteBool(payphone)
		net.Send(caller)
		hook.Call("McPhone.Hook.UnsuccessCall", nil, caller, number)

		return
	end

	if receiver:IsBot() then
		receiver.McPhoneData = {
			Ringtone = "tone_" .. math.random(1, 9)
		}
	end

	if receiver.McPhoneData and receiver.McPhoneData.Ringtone then
		receiver.McPhoneSound = CreateSound(receiver, "mc_phone/ring/" .. receiver.McPhoneData.Ringtone .. ".wav")
		receiver.McPhoneSound:ChangeVolume(1, 0)
		receiver.McPhoneSound:ChangePitch(100, 0)
		receiver.McPhoneSound:Play()
	end

	receiver.McPhoneInCall = caller
	caller.McPhoneCalling = receiver

	net.Start("McPhone.CallStart")
		net.WriteString("Connecting")
		net.WriteEntity(receiver)
		net.WriteInt(c_type[1], 16)
	net.Send(caller)
	net.Start("McPhone.CallStart")
		net.WriteString("Incoming")
		net.WriteEntity(caller)
		net.WriteInt(c_type[2], 16)
	net.Send(receiver)

	if McPhone.Config.DarkRPLog and DarkRP then
		DarkRP.log("[McPhone] " .. caller:Nick() .. " (" .. caller:SteamID() .. ") called " .. receiver:Name() .. " (" .. receiver:SteamID() .. ")", Color(200, 0, 255))
	end

	hook.Call("McPhone.Hook.CallStart", nil, caller, receiver)
end)

net.Receive("McPhone.CallDeny", function(l, ply)
	if IsValid(ply.McPhoneInCall) then
		net.Start("McPhone.CallBuisy")
			net.WriteBool(ply.McPayPhone and true)
		net.Send(ply.McPhoneInCall)
		ply.McPhoneInCall.McPhoneCalling = nil

		if ply.McPhoneSound then
			ply.McPhoneSound:Stop()
			ply.McPhoneSound = nil
		end

		hook.Call("McPhone.Hook.OnCallEnd", nil, ply, ply.McPhoneInCall)
	end

	if IsValid(ply.McPhoneCalling) then
		net.Start("McPhone.End")
			net.WriteBool(ply.McPayPhone and true)
		net.Send(ply.McPhoneCalling)

		if ply.McPhoneCalling.McPhoneSound then
			ply.McPhoneCalling.McPhoneSound:Stop()
			ply.McPhoneCalling.McPhoneSound = nil
		end

		ply.McPhoneCalling.McPhoneInCall = nil
		hook.Call("McPhone.Hook.OnCallEnd", nil, ply, ply.McPhoneCalling)
	end

	if IsValid(ply.McPhoneOnCall) then
		ply.McPhoneOnCall.McPhoneOnCall = nil
		net.Start("McPhone.CallBuisy")
		net.Send(ply.McPhoneOnCall)
		hook.Call("McPhone.Hook.OnCallEnd", nil, ply, ply.McPhoneOnCall)
	end

	ply.McPhoneInCall = nil
	ply.McPhoneCalling = nil
	ply.McPhoneOnCall = nil
end)

net.Receive("McPhone.Accept", function(l, ply)
	if IsValid(ply.McPhoneInCall) then
		net.Start("McPhone.CallAccept")
		net.Send(ply.McPhoneInCall)
		net.Start("McPhone.CallAccept")
		net.Send(ply)
		ply.McPhoneOnCall = ply.McPhoneInCall
		ply.McPhoneInCall.McPhoneOnCall = ply
		ply.McPhoneInCall.McPhoneCalling = nil
		ply.McPhoneInCall = nil

		if ply.McPhoneSound then
			ply.McPhoneSound:Stop()
			ply.McPhoneSound = nil
		end

		if McPhone.Config.DarkRPLog and DarkRP then
			DarkRP.log("[McPhone] " .. ply:Nick() .. " (" .. ply:SteamID() .. ") accept call with " .. ply.McPhoneOnCall:Name() .. " (" .. ply.McPhoneOnCall:SteamID() .. ")", Color(200, 0, 255))
		end

		hook.Call("McPhone.Hook.Accept", nil, ply, ply.McPhoneOnCall)
	end
end)

net.Receive("McPhone.GetUserData", function(l, ply)
	local userdata = net.ReadTable()
	if not userdata or not IsValid(ply) then return end
	ply.McPhoneData = userdata
	local color = userdata.PhoneColor
	ply:SetNWVector("McPhone.Color", Vector(color.r, color.b, color.g))
	ply:SetNWString("McPhone.Type", userdata.PhoneType)
end)

net.Receive("McPhone.PhoneStatus", function(l, ply)
	local userdata = net.ReadInt(16)
	local update = net.ReadBool()

	if update then
		ply:SetNWInt("McPhone.Active", 0)
		timer.Simple(1, function()
			if IsValid(ply) then ply:SetNWInt("McPhone.Active", userdata) end
		end)
		return
	end

	ply:SetNWInt("McPhone.Active", userdata)
end)

local function McPhone_DropPhone(ply)
	if not IsValid(ply) then return false end

	if not ply:GetNWBool("McPhone.HasPhone") then
		McPhone.DefaultNotify(ply, 1, 4, McPhone.GetPhrase("dropphone_error_2"))
		return false
	end

	if ply.McPhoneOnCall or ply.McPhoneInCall or ply.McPhoneCalling or not McPhone.CanTalk(ply) then
		McPhone.DefaultNotify(ply, 1, 4, McPhone.GetPhrase("dropphone_error_1"))
		return false
	end

	local hook_check = hook.Call("McPhone.Hook.BlockPhoneDrop", nil, ply)
	if hook_check then return false end

	ply:SetNWBool("McPhone.HasPhone", false)

	if McPhone.Config.GivePhoneOnSpawn then
		for _, ent in pairs(ents.FindByClass("mc_phone*")) do
			if IsValid(ent) and ent.ownerid and ent.ownerid == ply:SteamID() then
				ent:Remove()
			end
		end
	end

	local phone_data = ply.McPhoneData
	if not phone_data or not McPhone[phone_data.PhoneType] or not McPhone[phone_data.PhoneType].ent then
		ply:SetNWBool("McPhone.HasPhone", true)
		McPhone.DefaultNotify(ply, 1, 4, "Phone type is invalid")
		return false
	end

	local phone = ents.Create(McPhone[phone_data.PhoneType].ent)
	if not IsValid(phone) then
		ply:SetNWBool("McPhone.HasPhone", true)
		McPhone.DefaultNotify(ply, 1, 4, "Unable to create phone")
		return false
	end

	phone:Spawn()
	phone:SetPos(ply:GetShootPos() + ply:GetAimVector() * 35)
	phone:SetColor(phone_data.PhoneColor)
	phone:SetNWString("Last Owner", ply:GetName())
	phone.profile = phone_data
	phone.ownerid = ply:SteamID()
	ply:SetPData("McPhone.HasPhone", 0)
	hook.Call("McPhone.Hook.OnPhoneDropped", nil, ply, phone)

	return true
end

hook.Add("PlayerSay", "McPhone.PlayerSay", function(ply, text)
	if McPhone.Config.AllowPhoneDrop and string.lower(text) == string.lower(McPhone.Config.DropCommand) then
		McPhone_DropPhone(ply)
		return ""
	end
end)

util.AddNetworkString("McPhone.DropPhone")
net.Receive("McPhone.DropPhone", function(_, ply)
	if McPhone.Config.AllowPhoneDrop then
		McPhone_DropPhone(ply)
	end
end)

concommand.Add("mcphone_drop", function(ply)
	if not IsValid(ply) then
		MsgC(Color(255, 170, 0), "[McPhone] mcphone_drop must be used by a player.\n")
		return
	end

	if not McPhone.Config.AllowPhoneDrop then
		MsgC(Color(255, 0, 0), "[McPhone] Phone dropping is disabled in config.\n")
		return
	end

	McPhone_DropPhone(ply)
end)

local function canHear(ply1, ply2)
	local process = false

	if McPhone.EP1 and McPhone.Config.TowerRangebasedNet then
		if (ply1.McPhoneSignal or 3) > 1 and (ply2.McPhoneSignal or 3) > 1 then
			process = true
		elseif math.random(1, 50) > 20 then
			process = true
		end
	else
		process = true
	end

	if ply1.McPhoneOnCall == ply2 and ply2.McPhoneOnCall == ply1 and process then
		return true
	end
end
hook.Add("PlayerCanHearPlayersVoice", "McPhone.PlayerCanHearPlayersVoice", canHear)

local function voiceBoxCanHear(ply1, ply2)
	local process = false

	if McPhone.EP1 and McPhone.Config.TowerRangebasedNet then
		if (ply1.McPhoneSignal or 3) > 1 and (ply2.McPhoneSignal or 3) > 1 then
			process = true
		elseif math.random(1, 50) > 20 then
			process = true
		end
	else
		process = true
	end

	if ply1.McPhoneOnCall == ply2 and ply2.McPhoneOnCall == ply1 and process then
		VoiceBox.FX.IsPhoneComm(ply1:EntIndex(), ply2:EntIndex(), not VoiceBox.FX.__PlayerCanHearPlayersVoice(ply1, ply2))
		return true
	end

	VoiceBox.FX.IsPhoneComm(ply1:EntIndex(), ply2:EntIndex(), false)
end

if VoiceBox and VoiceBox.FX then
	hook.Add("PlayerCanHearPlayersVoice", "McPhone.PlayerCanHearPlayersVoice", voiceBoxCanHear)
else
	hook.Add("VoiceBox.FX", "McPhone", function()
		hook.Add("PlayerCanHearPlayersVoice", "McPhone.PlayerCanHearPlayersVoice", voiceBoxCanHear)
	end)
end

hook.Add("PlayerSpawn", "McPhone.PlayerSpawn", function(ply)
	if not McPhone.Config.AllowPhoneDrop or McPhone.Config.GivePhoneOnSpawn then
		ply:SetNWBool("McPhone.HasPhone", true)
	else
		local has_phone = tonumber(ply:GetPData("McPhone.HasPhone", 0))

		if has_phone == 1 then
			ply:SetNWBool("McPhone.HasPhone", true)
		end
	end
end)

hook.Add("PlayerDisconnected", "McPhone.PlayerDisconnected", function(ply)
	if McPhone.Config.PhoneLoseDisconnect then
		ply:SetPData("McPhone.HasPhone", 0)
	end
end)

hook.Add("PlayerDeath", "McPhone.PlayerDeath", function(ply)
	if McPhone.Config.AllowPhoneDrop and McPhone.Config.PhoneLoseDeath then
		ply:SetPData("McPhone.HasPhone", 0)
		ply:SetNWBool("McPhone.HasPhone", false)
	end
end)
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
