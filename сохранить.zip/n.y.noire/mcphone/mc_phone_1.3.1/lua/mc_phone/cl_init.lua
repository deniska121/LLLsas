--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
local ScrW, ScrH = ScrW, ScrH
local ply = LocalPlayer()
local colors = McPhone.MainColors
local l_hint = false

local sub_clrs = {
	black_50 = Color(0, 0, 0, 50),
	red = Color(255, 0, 0),
	green_55 = Color(155, 255, 155),
	white_250 = Color(250, 250, 250),
	white_50a = Color(255, 255, 255, 50),
}

function McPhone.Open(type)
	if not McPhone.CanUsePhone(ply) then return end
	net.Start("McPhone.PhoneStatus")
		net.WriteInt(1, 16)
	net.SendToServer()

	local cnv = GetConVar("mcphone_tip")
	if cnv:GetInt() > 0 then
		cnv:SetInt(0)
	end

	if McPhone.Config.AllowPhoneDrop and not l_hint then
		McPhone.DefaultNotify(ply, 0, 10, McPhone.GetPhrase("hint_dropphone") .. " " .. McPhone.Config.DropCommand)
		l_hint = true
	end

	local phone_table = McPhone.PhoneTypes[McPhone.UserCfg.PhoneType]

	if not phone_table then
		phone_table = McPhone.PhoneTypes.McPhone
	end

	if McPhone.UI and type == 1 then return end
	McPhone.UI = vgui.Create("DFrame")
	McPhone.UI:SetSize(phone_table.size[1], phone_table.size[2])
	McPhone.UI:SetPos(ScrW() - (phone_table.size[1] + 25), ScrH())
	McPhone.UI.OriginalPos = {McPhone.UI:GetPos(), ScrH() - (phone_table.size[2] - 30)}
	McPhone.UI:SetTitle("")
	McPhone.UI:SetDraggable(true)
	McPhone.UI:ShowCloseButton(false)
	McPhone.UI.OpenedMenu = ""

	McPhone.UI.Select = function(id, panel)
		if panel then
			for k, v in pairs(McPhone.UI.Menu:GetItems()) do
				if v == panel then
					id = k
				end
			end
		end

		local hover = McPhone.UI.Menu:GetItems()[id]

		if hover then
			McPhone.key = id
			hover:OnCursorEntered(true)
			McPhone.UI.Menu:ScrollToChild(hover)
		end
	end

	McPhone.UI.Paint = function(self, w, h)
		McPhone.DrawTexturedRect(0, 0, w, h, phone_table.main_mat, color_white)
		McPhone.DrawTexturedRect(0, 0, w, h, phone_table.frame_mat, McPhone.UserCfg.Theme["phone"])
	end

	McPhone.UI:MoveTo(McPhone.UI:GetPos(), McPhone.UI.OriginalPos[2], 0.2)

	McPhone.UI.Think = function(self)
		if McPhone.UI.Closing and McPhone.UI.Closing < CurTime() then
			McPhone.UI.Closing = false
			McPhone.UI:Close()
			McPhone.UI = nil
			net.Start("McPhone.PhoneStatus")
				net.WriteInt(0, 16)
			net.SendToServer()
		end
	end

	function McPhone.UI:OnRemove()
		if McPhone.Sound then
			McPhone.Sound:Stop()
			McPhone.Sound = nil
		end

		if McPhone.UserCfg.CursorOnPopUp then
			local mx, my = gui.MousePos()

			if mx > 0 and my > 0 then
				if GAMEMODE.ShowSpare1 then
					GAMEMODE:ShowSpare1()
				else
					gui.EnableScreenClicker(false)
				end
			end
		end
	end

	McPhone.UI.Buttons = {
		Left = {nil, nil, nil},
		Middle = {nil, nil, nil},
		Right = {nil, nil, nil},
	}

	if McPhone.UserCfg.CursorOnPopUp then
		if GAMEMODE.ShowSpare1 then
			GAMEMODE:ShowSpare1()
		else
			gui.EnableScreenClicker(true)
		end

		gui.SetMousePos((ScrW() - 320) + McPhone.UI:GetWide() / 2, (ScrH() - 480) + McPhone.UI:GetTall() / 2)
	end

	local b_collor = color_white
	local o_battery = system.BatteryPower()
	McPhone.UI.Scr = vgui.Create("DPanel", McPhone.UI)
	McPhone.UI.Scr:SetPos(phone_table.scr_pos[1], phone_table.scr_pos[2])
	McPhone.UI.Scr:SetSize(256, 370)

	McPhone.UI.Scr.Paint = function(self, w, h)
		local battery = system.BatteryPower()

		if battery < 30 then
			b_collor = sub_clrs.red
		elseif battery == 255 then
			if o_battery ~= 255 then
				b_collor = sub_clrs.green_55
			end
		else
			if b_collor ~= color_white then
				b_collor = color_white
			end
		end

		if o_battery ~= battery then
			o_battery = battery
		end

		McPhone.DrawTexturedRect(0, h - 45, 256, 45, phone_table.button_bg, color_white)
		phone_table.PaintTop(w, h, battery, b_collor)

		if McPhone.Notification then
			McPhone.Notification(self, w, h)
		end
	end

	McPhone.UI.Menu = vgui.Create("DPanelList", McPhone.UI)
	McPhone.UI.Menu:SetPos(phone_table.scr_pos[1], phone_table.scr_pos[2] + 69)
	McPhone.UI.Menu:SetSize(270, 256)
	McPhone.UI.Menu:EnableHorizontal(true)
	McPhone.UI.Menu:EnableVerticalScrollbar(true)
	McPhone.UI.Menu:SetSpacing(0)
	McPhone.UI.Menu.List = false

	McPhone.UI.Menu.Paint = function(self, w, h)
		if McPhone.UI.Menu.List or w > 256 then
			draw.RoundedBox(0, 0, 0, 256, h, sub_clrs.white_250)
		end
	end

	McPhone.UI.Menu.VBar.Paint = function() end
	McPhone.UI.Menu.VBar.btnUp.Paint = function() end
	McPhone.UI.Menu.VBar.btnDown.Paint = function() end
	McPhone.UI.Menu.VBar.btnGrip.Paint = function() end

	McPhone.UI.Menu.ConvertToList = function()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.Menu:SetPos(phone_table.scr_pos[1], phone_table.scr_pos[2] + 69)
		McPhone.UI.Menu:SetSize(270, 256)
		McPhone.UI.Menu.List = true
	end

	McPhone.UI.Menu.ConvertToMenu = function()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.Menu:SetPos(phone_table.scr_pos[1] + 8, phone_table.scr_pos[2] + 77)
		McPhone.UI.Menu:SetSize(256, 240)
		McPhone.UI.Menu.List = false
	end

	local buton = vgui.Create("DButton", McPhone.UI.Scr)
	buton:SetSize(85, 45)
	buton:SetPos(0, McPhone.UI.Scr:GetTall() - 45)
	buton:SetText("")
	buton.DoClick = function(self)
		if McPhone.UI.Buttons.Left[3] then
			McPhone.UI.Buttons.Left[3]()
		end
	end
	buton.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Left[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Left[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Left[2])
			surface.DrawTexturedRect(20, 0, 45, 45)
		end
	end

	local buton2 = vgui.Create("DButton", McPhone.UI.Scr)
	buton2:SetSize(85, 45)
	buton2:SetPos(85, McPhone.UI.Scr:GetTall() - 45)
	buton2:SetText("")
	buton2.DoClick = function(self)
		if McPhone.UI.Buttons.Middle[3] then
			McPhone.UI.Buttons.Middle[3]()
		else
			McPhone.EnterPress()
		end
	end
	buton2.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Middle[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Middle[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Middle[2])
			surface.DrawTexturedRect(20, 0, 45, 45)
		end
	end

	local buton3 = vgui.Create("DButton", McPhone.UI.Scr)
	buton3:SetSize(85, 45)
	buton3:SetPos(170, McPhone.UI.Scr:GetTall() - 45)
	buton3:SetText("")
	buton3.DoClick = function(self)
		if McPhone.UI.Buttons.Right[3] then
			McPhone.UI.Buttons.Right[3]()
		else
			McPhone.GoBack()
		end
	end
	buton3.Paint = function(self, w, h)
		if McPhone.UI.Buttons.Right[1] then
			surface.SetMaterial(Material(McPhone.UI.Buttons.Right[1], "smooth"))
			surface.SetDrawColor(McPhone.UI.Buttons.Right[2])
			surface.DrawTexturedRect(20, 0, 45, 45)
		end
	end

	McPhone.UI.MainMenuOpen = function()
		McPhone.UI.Menu.ConvertToMenu()

		for id, mod in SortedPairs(McPhone.Modules) do
			if mod.CheckFunction and not mod.CheckFunction() then continue end

			phone_table.MainIcons(McPhone.UI.Menu, mod.icon, mod.name, function()
				McPhone.UI.GoBack = function()
					McPhone.UI.MainMenuOpen()
				end

				mod.openMenu()
			end, mod.number)
		end

		McPhone.UI.GoBack = false

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png", colors["green"], nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", colors["red"], nil}

		McPhone.UI.Select(5)
	end

	if type == 1 then
		McPhone.PlaySoundUI("mc_phone/toggle.wav")
		McPhone.UI.MainMenuOpen()
		McPhone.UI.Select(5)

		if McPhone.PreCache then
			McPhone.OpenCallMenu(McPhone.PreCache[1], McPhone.PreCache[2], McPhone.PreCache[3])
			McPhone.PreCache = nil
		end
	else
		McPhone.UI.GoBack = function()
			McPhone.UI.MainMenuOpen()
		end
	end
end

function McPhone.OpenCallMenu(status, contact, icon, payphone, call_bg)
	if payphone and McPhone.PayPhone and McPhone.PayPhone.UI then
		McPhone.PayPhone.UI.Update(status, contact)
		return
	end

	if not McPhone.UI then
		if McPhone.UserCfg.PopUp then
			McPhone.Open(2)
		else
			McPhone.PreCache = {status, contact, icon}

			return
		end
	end

	if not contact then
		contact = "Unknown"
	end

	if not icon or (isstring(icon) and Material(icon):IsError()) then
		icon = "mc_phone/icons/contact.png"
	end

	if not status then
		status = "Connected"
	end

	if status == "Incoming" then
		McPhone.EndTime = CurTime() + 15

		McPhone.AcceptCall = function()
			if McPhone.CallDelay and McPhone.CallDelay < CurTime() then
				net.Start("McPhone.Accept")
				net.SendToServer()
				McPhone.AcceptCall = nil
			end
		end
	end

	McPhone.UI.Menu:Clear(true)

	if McPhone.UI.NScr then
		McPhone.UI.NScr:Remove()
	end

	local phone_table = McPhone.PhoneTypes[McPhone.UserCfg.PhoneType]

	if not phone_table then
		phone_table = McPhone.PhoneTypes.McPhone
	end

	McPhone.UI.NScr = vgui.Create("DPanel", McPhone.UI)
	McPhone.UI.NScr:SetPos(phone_table.scr_pos[1], phone_table.scr_pos[2] + 25)
	McPhone.UI.NScr:SetSize(256, 300)

	McPhone.UI.NScr.Think = function()
		if McPhone.EndTime and McPhone.EndTime < CurTime() and status == "Incoming" then
			McPhone.EndTime = nil
			McPhone.GoBack()
		end
	end

	McPhone.UI.NScr.Paint = function(self, w, h)
		McPhone.DrawTexturedRect(0, 44, 256, 256, "mc_phone/wp/McPhone_logo_background.png", color_white)
		if call_bg then
			McPhone.DrawTexturedRect(0, 44, 256, 256, McPhone.GetUrlIcon(call_bg[1], call_bg[2]), color_white)
		end
		draw.RoundedBox(0, 0, 0, w, 118, color_black)
		McPhone.DrawTexturedRect(0, 0, 256, 118, "mc_phone/phone/grad.png", sub_clrs.white_50a)
		draw.SimpleTextOutlined(contact, "McPhone.Main28", 5, 15, color_white, TEXT_ALIGN_LEFT, 1, 2, sub_clrs.black_50)
		draw.SimpleTextOutlined(string.upper(McPhone.GetPhrase(status)), "McPhone.Main32", 78, 50, color_white, TEXT_ALIGN_LEFT, 1, 1, sub_clrs.black_50)

		if McPhone.AcceptedTime and status == "Connected" then
			draw.SimpleTextOutlined(string.FormattedTime(CurTime() - McPhone.AcceptedTime, "%02i:%02i"), "McPhone.Main32", 78, 80, color_white, TEXT_ALIGN_LEFT, 1, 1, sub_clrs.black_50)
		end

		if isstring(icon) then
			McPhone.DrawTexturedRect(5, 35, 64, 64, icon, color_white)
		end
	end

	McPhone.UI.NScr.Update = function(type)
		status = type

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		if status == "Connecting" or status == "Busy" or status == "Connected" or status == "Not available" or status == "No Signal" then
			McPhone.UI.Buttons.Middle = {nil, nil, nil}

			McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id11.png", colors["red"], nil}
		elseif status == "Incoming" then
			McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id17.png", colors["green"], nil}

			McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id11.png", colors["red"], nil}
		end
	end

	if not isstring(icon) then
		local avatar = vgui.Create("AvatarImage", McPhone.UI.NScr)
		avatar:SetSize(64, 64)
		avatar:SetPos(5, 35)
		avatar:SetPlayer(icon, 64)
	end

	McPhone.UI.NScr.Update(status)
end

net.Receive("McPhone.CallStart", function()
	McPhone.StopSound()

	if McPhone.UI and McPhone.UI.Closing then
		McPhone.UI.anim:Stop()
		McPhone.UI.Closing = nil
		McPhone.UI:SetPos(McPhone.UI.OriginalPos[1], McPhone.UI.OriginalPos[2])
	end

	local type = net.ReadString()
	local pl = net.ReadEntity()
	local c_type = net.ReadInt(16)
	McPhone.OnCall = pl
	if c_type == 2 then
		McPhone.OpenCallMenu(type, McPhone.GetPhrase("Public phone"))
	else
		McPhone.OpenCallMenu(type, pl:Name(), pl, c_type == 1 and true)
	end

	if type == "Connecting" then
		McPhone.PlaySound("mc_phone/tone.wav")
		McPhone.CallDelay = CurTime() + 0.2
	end

	if type == "Incoming" then
		if c_type == 2 then
			McPhone.LastNumber = McPhone.GetPhrase("Public phone")
		else
			McPhone.LastNumber = pl
			McPhone.AddContacts(pl:AccountID(), pl:Name())
		end
		McPhone.CallDelay = CurTime() + 0.5
	end
end)

net.Receive("McPhone.CallExtraNumber", function()
	McPhone.StopSound()

	if McPhone.UI and McPhone.UI.Closing then
		McPhone.UI.anim:Stop()
		McPhone.UI.Closing = nil
		McPhone.UI:SetPos(McPhone.UI.OriginalPos[1], McPhone.UI.OriginalPos[2])
	end

	local tab = net.ReadTable()
	local public_phone = net.ReadBool()
	McPhone.OnCall = tab
	McPhone.OpenCallMenu("Connecting", tab.nicename, tab.icon_call, public_phone, tab.call_bg)
	McPhone.PlaySound("mc_phone/tone.wav")

	timer.Create("McPhone.CallExtraNumber1", 5, 1, function()
		if McPhone.OnCall and istable(McPhone.OnCall) then
			McPhone.UI.NScr.Update("Connected")
			McPhone.PlaySound(tab.sound[1], tab.sound[2])
		end
	end)

	timer.Create("McPhone.CallExtraNumber2", 5 + tab.delay, 1, function()
		if McPhone.OnCall and istable(McPhone.OnCall) then
			if tab.func then
				McPhone.StopCall()
				local close = McPhone.ExtraNumbersFunc[tab.func]()

				if close then
					McPhone.ClosePhone()
				end
			else
				McPhone.CallBusy()
			end
		end
	end)
end)

net.Receive("McPhone.End", function()
	McPhone.GoBack()
end)

net.Receive("McPhone.CallBuisy", function()
	McPhone.CallBusy()
end)

net.Receive("McPhone.CallAccept", function()
	local lastcall = McPhone.LastNumber
	local public_phone = net.ReadBool()
	local avatar
	McPhone.AcceptedTime = CurTime()

	if lastcall and not isnumber(lastcall) and not isstring(lastcall) then
		avatar = lastcall
		lastcall = lastcall:Name()
	end

	McPhone.OpenCallMenu("Connected", lastcall, avatar, public_phone)
	McPhone.StopSound()
	McPhone.AddContacts(number, name)
end)

net.Receive("McPhone.CallNotAv", function()
	McPhone.OnCall = CurTime() + 15

	local public_phone = net.ReadBool()
	local lastcall = McPhone.LastNumber
	local avatar, call_bg

	if not isnumber(lastcall) and not isstring(lastcall) and IsValid(lastcall) then
		avatar = lastcall
		lastcall = lastcall:Name()
	end

	if (isnumber(lastcall) or isstring(lastcall)) and McPhone.ExtraNumbers[tostring(lastcall)] then
		local ex_n = McPhone.ExtraNumbers[tostring(lastcall)]
		lastcall = ex_n.nicename
		avatar = ex_n.icon_call
		call_bg = ex_n.call_bg
	end

	McPhone.OpenCallMenu("Connecting", lastcall, avatar, public_phone, call_bg)
	McPhone.PlaySound("mc_phone/tone.wav")

	timer.Simple(6, function()
		if McPhone.OnCall and isnumber(McPhone.OnCall) then
			if McPhone.UI then
				McPhone.UI.NScr.Update("Not available")
			elseif McPhone.PreCache then
				McPhone.PreCache[1] = "Not available"
			end
			McPhone.PlaySound("mc_phone/notav.wav")
			if McPhone.PayPhone and McPhone.PayPhone.UI then
				McPhone.PayPhone.UI:Close()
			end
		end
	end)
end)
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
