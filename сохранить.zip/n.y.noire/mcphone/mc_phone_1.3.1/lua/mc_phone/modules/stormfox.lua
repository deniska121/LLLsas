--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 12
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = "Weather"
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/weather.png"
McPhone.Modules[module_id].number = 0
local mat = Material("gui/arrow")
local round = math.Round

McPhone.Modules[module_id].openMenu = function()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	if not StormFox then return end
	if not StormFox.GetRealTime then return end
	if not StormFox.Weather then return end
	if not StormFox.Weather.GetIcon then return end
	local m_list

	function m_list()
		McPhone.UI.Menu.ConvertToList()
		local frame = vgui.Create("DPanel")
		frame:SetSize(256, 256)
		frame:SetDisabled(true)
		frame:SetAlpha(255)

		frame.Paint = function(self, w, h)
			local temp = round(StormFox.GetNetworkData("Temperature", 20), 1)
			local wind = round(StormFox.GetNetworkData("Wind", 0), 2)
			local weth = StormFox.GetWeatherType(StormFox.GetNetworkData("Weather")):GetName(temp, wind, StormFox.GetNetworkData("thunder"))
			surface.SetDrawColor(Color(63, 141, 206))
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(weth, "McPhone.Main22", 60, 5, color_white, TEXT_ALIGN_LEFT, 0)
			draw.SimpleText(Freedom and (StormFox.CelsiusToFahrenheit(round(temp, 1)) .. "°F") or (round(temp, 1) .. "°C"), "McPhone.Main22", 60, 22, color_white, TEXT_ALIGN_LEFT, 0)
			draw.SimpleText("Wind: " .. wind .. "m/s", "McPhone.Main22", 60, 40, color_white, TEXT_ALIGN_LEFT, 0)
			surface.SetDrawColor(Color(255, 255, 255))
			surface.SetMaterial(StormFox.Weather:GetIcon())
			surface.DrawTexturedRect(5, 5, 48, 48)
			local w_data = StormFox.GetNetworkData("WeekWeather", {})
			if #w_data < 1 then return end
			local wd = (w - 10) / 5
			surface.SetDrawColor(255, 255, 255, 55)

			for i = 1, 7 do
				surface.DrawLine(5, 140 + i * 10, w - 10, 140 + i * 10)
			end

			local xx = wd / 1440 * StormFox.GetTime()
			surface.DrawLine(5 + xx, 150, 5 + xx, 210)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawLine(5, 140 + 5 * 10, w - 10, 140 + 5 * 10)
			local lasty, lastx
			local ht_t = false

			for i = 1, #w_data do
				if i > 5 then break end
				ht_t = not ht_t
				local data = w_data[i]
				local x = (i - 1) * wd + 5
				local weather = (data.percent or 0) > 0.2 and data.name or "clear"
				local p = data.percent or 0

				if weather == "rain" and p > 0 then
					surface.SetDrawColor(0, 0, 255, 155)
					local xx = 5 + wd * (i - 1) + (wd / 1440 * data.trigger)
					local h = math.floor(p * 45)
					local l = wd / 1440 * (data.stoptime - data.trigger)
					surface.DrawRect(xx, 190 - h, l, h)
				end

				local temp = data.temp
				local name = StormFox.GetWeatherType(data.name):GetName(temp, data.wind, data.thunder)
				local wmat = StormFox.GetWeatherType(data.name):GetIcon(temp, data.wind, data.thunder)
				draw.SimpleText(name, "McPhone.Main16", x + wd / 2, ht_t and 65 or 80, color_white, 1, 0)
				surface.SetDrawColor(255, 255, 255)
				surface.SetMaterial(wmat)
				surface.DrawTexturedRect(x + 10, 100, 32, 32)
				surface.SetDrawColor(0, 0, 0)
				local temp_x = x + (wd / 1440 * data.trigger)
				local temp_y = 150 - data.temp * 2 + 40
				local text_tem = temp_y > 200 and 20 or 0
				surface.DrawCircle(temp_x, temp_y, 1, color_white)
				draw.SimpleTextOutlined(Freedom and (StormFox.CelsiusToFahrenheit(round(data.temp, 1)) .. "°F") or (round(data.temp, 1) .. "°C"), "McPhone.Main16", temp_x, temp_y - text_tem, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, 1, color_black)
				surface.SetMaterial(mat)
				local wind = data.wind
				surface.DrawTexturedRectRotated(x + wd / 2, h - 30, 10 + wind, 10 + wind, data.windangle)

				if Freedom then
					wind = wind * 2.236936
				end

				draw.SimpleTextOutlined(math.Round(wind, 1) .. (Freedom and "mph" or "m/s"), "McPhone.Main16", x + wd / 2, h - 20, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
				lasta = data.tempacc or 0

				if lasty then
					surface.DrawLine(temp_x, temp_y, lastx, lasty)
				else
					local oldtemp = w_data["ot"] or StormFox.GetData("Temperature", 20)
					lastx = 5
					lasty = 150 - oldtemp * 2 + 40
					surface.DrawLine(temp_x, temp_y, lastx, lasty)
				end

				lasty = temp_y
				lastx = temp_x
			end
		end

		McPhone.UI.Menu:AddItem(frame)
	end

	m_list()
end

McPhone.Modules[module_id].CheckFunction = function()
	if not StormFox then return false end

	return true
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
