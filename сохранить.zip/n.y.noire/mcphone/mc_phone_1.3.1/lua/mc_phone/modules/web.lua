--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
--if !GlorifiedBanking then return end
local module_id = 7
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = McPhone.GetPhrase("web")
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/web.png"
McPhone.Modules[module_id].number = 0

McPhone.Modules[module_id].openMenu = function()
	McPhone.OpenPhoneWebmenu()
end

McPhone.Modules[module_id].CheckFunction = function()
	if table.Count(McPhone.WebModules) < 1 then
		return false
	else
		return true
	end
end

local function DWebButtonIcons(par, x, y, icon, func, exfunc)
	icon = Material(icon, "smooth")
	local buton = vgui.Create("DButton", par)
	buton:SetSize(36, 36)
	buton:SetText("")
	buton:SetPos(x, y)
	buton.DoClick = func

	if exfunc then
		buton.Think = exfunc
	end

	buton.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, Color(100, 100, 100))
		draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(200, 200, 200))
		surface.SetMaterial(icon)

		if self.hover then
			surface.SetDrawColor(0, 0, 0, 250)
		else
			surface.SetDrawColor(0, 0, 0, 180)
		end

		surface.DrawTexturedRect(2, 2, 32, 32)
	end

	buton.OnCursorEntered = function(self)
		self.hover = true
	end

	buton.OnCursorExited = function(self)
		self.hover = false
	end
end

function McPhone.OpenPhoneWebmenu()
	if McPhone.ActiveWeb then
		McPhone.ActiveWeb:Close()
		McPhone.ActiveWeb = nil
	end

	McPhone.ActiveWeb = vgui.Create("DFrame")
	McPhone.ActiveWeb:SetSize(ScrW(), ScrH())
	McPhone.ActiveWeb:SetPos(0, 0)
	McPhone.ActiveWeb:SetTitle("")
	McPhone.ActiveWeb:SetDraggable(false)
	McPhone.ActiveWeb:MakePopup()
	McPhone.ActiveWeb:ShowCloseButton(true)

	function McPhone.ActiveWeb:OnClose()
		McPhone.ActiveWeb = nil
	end

	McPhone.ActiveWeb.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, 25, Color(0, 0, 0))
		draw.RoundedBox(0, 0, 25, w, 50, Color(200, 200, 200))
		draw.RoundedBox(0, 0, 75, w, h - 75, Color(250, 250, 250))
		McPhone.DrawTexturedRect(0, 25, w, 50, "gui/gradient_up", Color(0, 0, 0, 100))
		draw.SimpleText(McPhone.GetCurTime(), "McPhone.Main22", w / 2 - 1, 2, color_white, TEXT_ALIGN_CENTER)
	end

	McPhone.ActiveWeb.Think = function(self)
		if (input.IsKeyDown(KEY_ESCAPE)) then
			self:Remove()
			McPhone.ActiveWeb.WebAdress = nil
			McPhone.ActiveWeb = nil
		end
	end

	DWebButtonIcons(McPhone.ActiveWeb, 140, 32, "mc_phone/icons/home.png", function()
		McPhone.OpenPhoneWebmenu()
	end)

	local drme = vgui.Create("DTextEntry", McPhone.ActiveWeb)
	drme:SetText("")
	drme:SetFont("McPhone.Main32")
	drme:SetPos(200, 32)
	drme:SetValue("https://www.macfinder.info")
	drme:SetEditable(false)
	drme:SetSize(ScrW() - 250, 36)

	drme.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, Color(100, 100, 100))
		draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(200, 200, 200))
		self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end

	McPhone.ActiveWeb.WebAdress = drme

	McPhone.UpdateWeb(function(parent, w, h)
		local logo = Material("mc_phone/web/mac_finder.png", "smooth")
		local bg = Material("mc_phone/web/bg_mf.png", "noclamp")
		local bg_c = Color(255, 255, 255, 100)
		local top = vgui.Create("DPanel", parent)
		top:SetSize(0, h / 4)
		top:Dock(TOP)

		top.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(75, 140, 195))
			draw.RoundedBox(0, 0, h - 8, w, 8, Color(255, 190, 0))
			McPhone.DrawTexturedRect(w / 8 + 3, h / 8 + 3, 300, 164, logo, color_black)
			McPhone.DrawTexturedRect(w / 8, h / 8, 300, 164, logo, color_white)
		end

		local src = vgui.Create("DTextEntry", top)
		src:SetSize(w / 2.6, 50)
		src:SetPos(w / 8 + 350, h / 4 / 2 - 25)
		src:SetText("")
		src:SetFont("McPhone.Main32")
		src:SetValue("")
		src:SetEditable(true)

		src.Paint = function(self, w, h)
			draw.RoundedBox(6, 0, 0, w, h, Color(100, 100, 100))
			draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(255, 255, 255))
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))

			if self:GetValue() == "" then
				McPhone.DrawTexturedRect(9, 9, 32, 32, Material("mc_phone/icons/search.png"), Color(75, 140, 195, 200))
				draw.SimpleText("Search MacFinder...", "McPhone.Main32", 50, 9, Color(0, 0, 0, 90), TEXT_ALIGN_LEFT)
			end
		end

		local main = vgui.Create("DPanel", parent)
		main:Dock(FILL)

		main.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, color_white)
			surface.SetMaterial(bg)
			surface.SetDrawColor(bg_c)
			surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, w / 450, h / 390)
		end

		local body = vgui.Create("DPanel", main)
		body:Dock(FILL)
		body:DockMargin(w / 6, 0, w / 6, 0)
		body:DockPadding(w / 6, 0, w / 6, 0)

		body.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
			draw.RoundedBox(0, 2, 0, w - 4, h, color_white)
			draw.SimpleText(McPhone.GetPhrase("RelWeb"), "McPhone.Main38", 30, 15, color_black, TEXT_ALIGN_LEFT)
		end

		local blist = vgui.Create("DPanelList", body)
		blist:SetSize(w - (w / 6) * 2 - 60, h - h / 3)
		blist:SetPos(30, 80)
		blist.Paint = function(self, w, h) end
		blist:EnableVerticalScrollbar(true)
		blist:SetSpacing(5)

		for id, mod in pairs(McPhone.WebModules) do
			local mat = Material("mc_phone/web/presets/" .. id .. ".png", "smooth")

			if mat:IsError() then
				mat = Material("mc_phone/web/presets/none.png", "smooth")
			end

			local button = vgui.Create("DButton")
			button:SetSize(w - (w / 6) * 2 - 60, 200)
			button:SetText("")

			button.Paint = function(self, w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(200, 200, 200))
				draw.RoundedBox(0, 2, 2, w - 4, h - 4, color_white)
				McPhone.DrawTexturedRect(2, 2, 300, h - 4, mat, color_white)

				if self.hover then
					draw.SimpleText(mod.name, "McPhone.Main38", 322, 15, Color(0, 0, 255), TEXT_ALIGN_LEFT)
				else
					draw.SimpleText(mod.name, "McPhone.Main38", 322, 15, color_black, TEXT_ALIGN_LEFT)
				end

				draw.SimpleText(mod.url, "McPhone.Main24", 323, 50, color_black, TEXT_ALIGN_LEFT)
			end

			button.DoClick = function(self)
				mod.OpenWebmenu()
			end

			button.OnCursorEntered = function(self)
				self.hover = true
			end

			button.OnCursorExited = function(self)
				self.hover = false
			end

			blist:AddItem(button)
		end
	end)
end

function McPhone.UpdateWeb(func)
	if not McPhone.ActiveWeb then return end

	if McPhone.ActiveWeb.Sub then
		McPhone.ActiveWeb.Sub:Remove()
		McPhone.ActiveWeb.Sub = nil
	end

	McPhone.ActiveWeb.Sub = vgui.Create("DPanel", McPhone.ActiveWeb)
	McPhone.ActiveWeb.Sub:SetSize(ScrW(), ScrH() - 75)
	McPhone.ActiveWeb.Sub:SetPos(0, 75)

	McPhone.ActiveWeb.Sub.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(100, 100, 100))
	end

	if func then
		func(McPhone.ActiveWeb.Sub, McPhone.ActiveWeb.Sub:GetWide(), McPhone.ActiveWeb.Sub:GetTall())
	end
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
