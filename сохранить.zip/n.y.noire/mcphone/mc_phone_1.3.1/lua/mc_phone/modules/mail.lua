--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 1
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = McPhone.GetPhrase("mail")
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/mail.png"
McPhone.Modules[module_id].number = 0
McPhone.Mail = {}
-- Save resent email as local varibles
local e_topic, e_text = "", ""

McPhone.Modules[module_id].openMenu = function()

	if not McPhone.UI or not McPhone.UI.Menu then return end
	local back = McPhone.UI.GoBack
	local m_list, m_new, m_send, m_reed, m_sendmail, m_feescr

	function m_list()
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("mail")

		for k, v in SortedPairs(McPhone.Mail, true) do
			McPhone.ListTexts(McPhone.UI.Menu, k, v.Name, v.Text, v.Time, false, function()
				McPhone.UI.GoBack = function()
					m_list()
				end

				m_reed(v.Name, v.Text, k)
			end, true, true)
		end

		McPhone.UI.Buttons.Left = {
			"mc_phone/icons/buttons/id5.png", McPhone.MainColors["blue"], function()
				m_new()

				McPhone.UI.GoBack = function()
					m_list()
				end
			end
		}

		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png", McPhone.MainColors["green"], nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}

		McPhone.UI.GoBack = back
	end

	function m_reed(name, text, email)
		McPhone.Mail[email].New = false
		McPhone.UpdateMail()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.OpenedMenu = name
		local drme = vgui.Create("DTextEntry")
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetMultiline(true)
		drme:SetValue(text)
		drme:SetDisabled(true)
		drme:SetSize(256, 256)

		drme.Paint = function(self, w, h)
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end

		McPhone.UI.Menu:AddItem(drme)

		McPhone.UI.Buttons.Left = {
			"mc_phone/icons/buttons/id13.png", McPhone.MainColors["blue"], function()
				table.remove(McPhone.Mail, email)
				McPhone.UpdateMail()
				McPhone.UI.GoBack()
			end
		}

		McPhone.UI.Buttons.Middle = {nil, nil, nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	function m_new()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("email_topic")
		McPhone.UI.Menu:Clear(true)
		local frame = vgui.Create("DPanel")
		frame:SetSize(256, 256)
		frame:SetDisabled(true)
		frame.PreChasher = true
		McPhone.UI.Menu:AddItem(frame)
		local x, y = frame:LocalToScreen(0, 0)
		local panel = vgui.Create("DFrame")
		panel:SetPos(x, y)
		panel:SetSize(256, 256)
		panel:SetTitle("")
		panel:SetDraggable(false)
		panel:ShowCloseButton(false)
		panel:MakePopup()
		panel.Paint = function() end

		panel.Think = function()
			if not McPhone.UI or not McPhone.UI.Menu:GetItems()[1] or not McPhone.UI.Menu:GetItems()[1].PreChasher then
				panel:Remove()
			end

			if x < 1 then
				x, y = frame:LocalToScreen(0, 0)
				panel:SetPos(x, y)
			end
		end

		local drme = vgui.Create("DTextEntry", panel)
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetValue(e_topic)
		drme:SetMultiline(false)
		drme:SetSize(256, 256)
		drme:SetPos(0, 0)
		drme:RequestFocus()

		drme.Paint = function(self, w, h)
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end

		McPhone.UI.GoBack = function()
			m_list()
		end

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {
			"mc_phone/icons/buttons/id4.png", McPhone.MainColors["green"], function()
				if drme:GetValue() ~= "" then
					e_topic = drme:GetValue()
					m_send()

					McPhone.UI.GoBack = function()
						m_new()
					end
				end
			end
		}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	function m_send()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.OpenedMenu = e_topic
		local frame = vgui.Create("DPanel")
		frame:SetSize(256, 256)
		frame:SetDisabled(true)
		frame.Chasher = true
		McPhone.UI.Menu:AddItem(frame)
		local x, y = frame:LocalToScreen(0, 0)
		local panel = vgui.Create("DFrame")
		panel:SetPos(x, y)
		panel:SetSize(256, 256)
		panel:SetTitle("")
		panel:SetDraggable(false)
		panel:ShowCloseButton(false)
		panel:MakePopup()
		panel.Paint = function() end

		panel.Think = function()
			if not McPhone.UI or not McPhone.UI.Menu:GetItems()[1] or not McPhone.UI.Menu:GetItems()[1].Chasher then
				panel:Remove()
			end

			if x < 1 then
				x, y = frame:LocalToScreen(0, 0)
				panel:SetPos(x, y)
			end
		end

		local drme = vgui.Create("DTextEntry", panel)
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetValue(e_text)
		drme:SetMultiline(true)
		drme:SetSize(256, 256)
		drme:SetPos(0, 0)
		drme:RequestFocus()

		drme.Paint = function(self, w, h)
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {
			"mc_phone/icons/buttons/id5.png", McPhone.MainColors["green"], function()
				if drme:GetValue() ~= "" then
					e_text = drme:GetValue()

					if McPhone.Config.EmailFee and DarkRP then
						m_feescr()
						McPhone.UI.GoBack = back
					else
						m_sendmail()
					end
				end
			end
		}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	function m_feescr()
		McPhone.UI.Menu:Clear(true)
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("email_last")
		local drme = vgui.Create("DTextEntry")
		drme:SetText("")
		drme:SetFont("McPhone.Main28")
		drme:SetMultiline(true)
		drme:SetValue(McPhone.GetPhrase("email_fee", McPhone.Config.EmailFeeSize, McPhone.Config.Curensy))
		drme:SetDisabled(true)
		drme:SetSize(256, 256)

		drme.Paint = function(self, w, h)
			self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
		end

		McPhone.UI.Menu:AddItem(drme)

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {
			"mc_phone/icons/buttons/id1.png", McPhone.MainColors["green"], function()
				m_sendmail()
			end
		}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	function m_sendmail()
		net.Start("McPhone.SendMail")
		net.WriteString(e_topic)
		net.WriteString(e_text)
		net.SendToServer()
		McPhone.UI.GoBack = nil
		back()
	end

	m_list()
end

function McPhone.NewMail(name, str, player)
	if CLIENT then
		table.insert(McPhone.Mail, {
			New = true,
			Name = name,
			Text = str,
			Time = McPhone.GetCurTime()
		})

		McPhone.UpdateMail()
		McPhone.Notify(name, str, true)
	else
		net.Start("McPhone.SendMail")
		net.WriteString(name)
		net.WriteString(str)
		net.Send(player)
	end
end

if SERVER then
	util.AddNetworkString("McPhone.SendMail")

	net.Receive("McPhone.SendMail", function(l, ply)
		if ply.McPhoneLastSMS and ply.McPhoneLastSMS + 5 > CurTime() then
			McPhone.Notify(ply, "Spam Alert!", "", false)

			return
		end

		ply.McPhoneLastSMS = CurTime()

		if McPhone.EP1 and ply.McPhoneSignal < 1 then
				McPhone.Notify(ply, McPhone.GetPhrase("email_canceled"), McPhone.GetPhrase("No Signal"), true)

				return
		end

		if McPhone.Config.EmailFee and DarkRP then
			if ply:canAfford(McPhone.Config.EmailFeeSize) then
				ply:addMoney(-McPhone.Config.EmailFeeSize)
			else
				McPhone.Notify(ply, McPhone.GetPhrase("email_canceled"), McPhone.GetPhrase("email_notenough"), true)

				return
			end
		end

		local topic = net.ReadString()
		local str = net.ReadString()
		net.Start("McPhone.SendMail")
		net.WriteString(topic)
		net.WriteString(str)
		net.Send(player.GetAll())

		if McPhone.Config.DarkRPLog and DarkRP then
			DarkRP.log("[McPhone] " .. ply:Nick() .. " (" .. ply:SteamID() .. ") email advert '" .. topic .. "': " .. str, Color(255, 200, 30))
		end

		hook.Call("McPhone.Hook.SendMail", nil, ply, topic, str)
	end)
else
	net.Receive("McPhone.SendMail", function(l)
		local name = net.ReadString()
		local str = net.ReadString()
		McPhone.NewMail(name, str)
	end)

	function McPhone.UpdateMail()
		local num = 0

		for k, v in pairs(McPhone.Mail) do
			if v.New then
				num = num + 1
			end
		end

		McPhone.Modules[module_id].number = num
		json_table = util.TableToJSON(McPhone.Mail, true)
		file.Write(McPhone.ServerID .. "/mcphone_user_mail.txt", json_table)
	end

	function McPhone.GetMail()
		if not file.Exists(McPhone.ServerID .. "/mcphone_user_mail.txt", "DATA") then
			McPhone.UpdateMail()
		else
			local sms = util.JSONToTable(file.Read(McPhone.ServerID .. "/mcphone_user_mail.txt", "DATA"))
			McPhone.Mail = sms
		end
	end

	McPhone.GetMail()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
