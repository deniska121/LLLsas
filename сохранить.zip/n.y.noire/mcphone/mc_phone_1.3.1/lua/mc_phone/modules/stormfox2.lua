--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
if SERVER then return end
local module_id = 12
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = "Weather"
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/weather.png"
McPhone.Modules[module_id].number = 0

McPhone.Modules[module_id].openMenu = function()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	if not StormFox2 then return end

	McPhone.UI.Menu.ConvertToList()
	local frame = vgui.Create("DPanel")
	frame:SetSize(256, 256)
	frame:SetDisabled(true)
	frame:SetAlpha(255)

	frame.Paint = function(self, w, h)
		StormFox2.WeatherGen.DrawForecast(w,h,true, 0,0)
	end
	McPhone.UI.Menu:AddItem(frame)

end

McPhone.Modules[module_id].CheckFunction = function()
	if not StormFox2 then return false end

	return true
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
