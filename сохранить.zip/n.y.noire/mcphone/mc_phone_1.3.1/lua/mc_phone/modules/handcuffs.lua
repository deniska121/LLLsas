--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

hook.Add("McPhone.Hook.BlockPhone", "RHandcuffs.PhoneRestrain", function(ply)
	if RHandcuffsConfig and (ply.Restrained or ply:RHC_IsArrested() or (CLIENT and ply:GetNWBool("rhc_cuffed", false))) then return true end
	if RKidnapConfig and (ply.RKRestrained or (CLIENT and ply:GetNWBool("rks_restrained", false))) then return true end
end)

--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
