--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
if CLIENT and not GlorifiedBanking then return end
McPhone.WebModules["gl_bank"] = {}
McPhone.WebModules["gl_bank"].name = "Glorified Banking"
McPhone.WebModules["gl_bank"].url = "https://glorifiedbanking.com"

local function GLButton(parent, text, w, h, func, not_par)
	local button = vgui.Create("DButton", parent)
	button:SetSize(w, h)
	button:SetText("")
	button.text = text
	button.alpha = 0

	button.Paint = function(self, w, h)
		if self.hover then
			self.alpha = Lerp(FrameTime() * 7, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 7, self.alpha, 0)
		end

		draw.RoundedBox(8, 0, 0, w, h, Color(75, 140, 195))
		draw.RoundedBoxEx(8, 0, h / 2, w, h / 2, Color((self.alpha * 255), (self.alpha * 255), (self.alpha * 255), 100 - (self.alpha * 50)), false, false, true, true)
		draw.SimpleText(self.text, "McPhone.Main38", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, 1)
	end

	button.DoClick = function(self)
		func(self)
	end

	button.DoRightClick = function(self)
		func(self)
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	if not not_par then
		parent:AddItem(button)
	end

	return button
end

local function GLLogPanel(parent, texts, w, h)
	local money_color = Color(150, 0, 0)

	if texts[2] == "Deposit" then
		money_color = Color(0, 150, 0)
	end

	local font = "McPhone.Main38"
	local panel = vgui.Create("DPanel")
	panel:SetSize(w, h)
	panel.texts = texts

	panel.Paint = function(self, w, h)
		local box_color = Color(0, 0, 0, 100)
		draw.RoundedBox(8, 0, 0, w * 0.2 - 10, h, box_color)
		local tw = draw.SimpleText(self.texts[1], font, 10, h / 2, color_black, TEXT_ALIGN_LEFT, 1)

		if tw > w * 0.2 then
			font = "McPhone.Main20"
		end

		draw.RoundedBox(8, w * 0.2, 0, w * 0.2 - 10, h, box_color)
		draw.SimpleText(self.texts[2], "McPhone.Main38", w * 0.2 + 10, h / 2, color_black, TEXT_ALIGN_LEFT, 1)
		draw.RoundedBox(8, w * 0.4, 0, w * 0.3 - 10, h, box_color)
		draw.SimpleText(self.texts[3], "McPhone.Main38", w * 0.4 + 10, h / 2, color_black, TEXT_ALIGN_LEFT, 1)
		draw.RoundedBox(8, w * 0.7, 0, w - w * 0.7, h, box_color)
		draw.SimpleText(self.texts[4], "McPhone.Main38", w * 0.7 + 10, h / 2, money_color, TEXT_ALIGN_LEFT, 1)
	end

	parent:AddItem(panel)

	return panel
end

McPhone.WebModules["gl_bank"].OpenWebmenu = function()
	local ply = LocalPlayer()
	local request = 0
	if not McPhone.ActiveWeb then return end
	McPhone.ActiveWeb.WebAdress:SetValue(McPhone.WebModules["gl_bank"].url)

	McPhone.UpdateWeb(function(parent, w, h)
		local logo = Material("mc_phone/web/gl_bank.png", "smooth")
		local bg = Material("mc_phone/web/bg.png", "noclamp")
		local base = vgui.Create("DPanel", parent)
		base:SetSize(w, h)

		base.Paint = function(self, w, h)
			surface.SetMaterial(bg)
			surface.SetDrawColor(color_white)
			surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, w / 400, h / 400)
		end

		local main_text = GlorifiedBanking.i18n.GetPhrase("gbWelcomeBack", string.upper(ply:Name()))
		local panel = vgui.Create("DPanel", base)
		panel:SetSize(w - w / 3, h)
		panel:Center()

		panel.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 50))
			draw.RoundedBox(0, 2, 0, w - 4, h, Color(255, 255, 255))
			draw.RoundedBox(0, 15, 140, w - 30, 3, Color(75, 140, 195))
			draw.RoundedBox(0, 15, 160, w - 30, 75, Color(75, 140, 195))
			McPhone.DrawTexturedRect(15, 160, w - 30, 75, "gui/gradient_up", Color(0, 0, 0, 120))
			McPhone.DrawTexturedRect(21, 26, 570, 96, logo, color_black)
			McPhone.DrawTexturedRect(20, 25, 570, 96, logo, color_white)
			draw.SimpleText(main_text, "McPhone.Main38", w / 2, 197, color_white, TEXT_ALIGN_CENTER, 1)
		end

		local listed = vgui.Create("DPanelList", panel)
		listed:SetSize(w - w / 3 - 30, h - 280)
		listed:SetPos(0, 260)
		listed:CenterHorizontal()
		listed:EnableHorizontal(true)
		listed:EnableVerticalScrollbar(true)
		listed:SetSpacing(5)
		local snap = 0
		listed.Screens = {}

		listed.OpenScreen = function(id, wd, ht, sp, data, disable_h)
			if not listed.Screens[id] then return end

			if disable_h then
				listed:EnableHorizontal(false)
			else
				listed:EnableHorizontal(true)
			end

			listed:Clear(true)

			if not wd then
				wd = w - w / 3 - 30
			end

			if not ht then
				ht = h - 280
			end

			if not sp then
				sp = 5
			end

			listed:SetSize(wd, ht)
			listed:CenterHorizontal()
			listed:SetSpacing(sp)
			listed.Screens[id](data)
		end

		listed.Screens[1] = function()
			local panel = vgui.Create("DPanel")
			panel:SetSize(listed:GetWide(), 65)

			panel.Paint = function(self, w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(75, 140, 195))
				McPhone.DrawTexturedRect(0, 0, w, h, "gui/gradient_up", Color(0, 0, 0, 120))
				draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbAccountBalance", GlorifiedBanking.FormatMoney(GlorifiedBanking.GetPlayerBalance())), "McPhone.Main38", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, 1)
			end

			listed:AddItem(panel)

			GLButton(listed, GlorifiedBanking.i18n.GetPhrase("gbMenuTransfer"), listed:GetWide(), 65, function()
				listed.OpenScreen(2, nil, nil, 5, nil, true)
			end)

			GLButton(listed, GlorifiedBanking.i18n.GetPhrase("gbMenuTransactions"), listed:GetWide(), 65, function()
				if request < CurTime() then
					request = CurTime() + 3
					net.Start("McPhone.GlorifiedBanking.DataRequested")
					net.SendToServer()
				end
			end)
		end

		listed.Screens[2] = function()
			GLButton(listed, McPhone.GetPhrase("go_back"), listed:GetWide(), 50, function()
				listed.OpenScreen(1, w / 3, nil, 10)
			end)

			local player_sel, id_sel = nil, 0
			local panel = vgui.Create("DPanel")
			panel:SetSize(listed:GetWide(), listed:GetTall() - 55)
			panel.Paint = function() end
			local plist = vgui.Create("DPanelList", panel)
			plist:SetSize(panel:GetWide() / 2, panel:GetTall())
			plist:SetPos(0, 0)
			plist:EnableHorizontal(true)
			plist:EnableVerticalScrollbar()
			plist:SetSpacing(5)

			plist.Paint = function(self, w, h)
				if #self:GetItems() < 1 then
					draw.SimpleText("NO PLAYER AVAILABLE", "McPhone.Main32", w / 2, h / 2, Color(150, 0, 0, 255), TEXT_ALIGN_CENTER)
				end
			end

			local data_players = player.GetHumans()

			for k, v in pairs(data_players) do
				if v == LocalPlayer() then continue end
				local button = vgui.Create("DButton", parent)
				button:SetSize(plist:GetWide(), 50)
				button:SetText("")

				button.Paint = function(self, w, h)
					if not IsValid(v) then
						listed.OpenScreen(4, nil, nil, 1, {"Error, Player ofline!", Color(250, 0, 0)})

						return
					end

					if id_sel == k then
						draw.RoundedBox(8, 0, 0, w, h, Color(75, 140, 195))
						draw.SimpleText(v:Name(), "McPhone.Main38", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, 1)
					else
						draw.RoundedBox(8, 0, 0, w, h, Color(0, 0, 0))
						draw.RoundedBox(8, 1, 1, w - 2, h - 2, Color(255, 255, 255))
						draw.SimpleText(v:Name(), "McPhone.Main38", w / 2, h / 2, color_black, TEXT_ALIGN_CENTER, 1)
					end
				end

				button.DoClick = function(self)
					if not IsValid(v) then
						listed.OpenScreen(4, nil, nil, 1, {"Error, Player ofline!", Color(250, 0, 0)})
					end

					player_sel, id_sel = v, k
				end

				plist:AddItem(button)
			end

			local src = vgui.Create("DTextEntry", panel)
			src:SetSize(panel:GetWide() / 2 - 5, 50)
			src:SetPos(panel:GetWide() / 2 + 5, 0)
			src:SetText("")
			src:SetFont("McPhone.Main32")
			src:SetValue("")
			src:SetEditable(true)

			src.Paint = function(self, w, h)
				draw.RoundedBox(6, 0, 0, w, h, Color(100, 100, 100))
				draw.RoundedBox(6, 1, 1, w - 2, h - 2, Color(255, 255, 255))
				self:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))

				if self:GetValue() == "" then
					draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbTransactionTypeAmount"), "McPhone.Main32", 5, 9, Color(0, 0, 0, 90), TEXT_ALIGN_LEFT)
				end

				if self:GetValue() ~= "" and not tonumber(self:GetValue()) then
					draw.SimpleText("NUMBERS ONLY!", "McPhone.Main32", w - 5, 9, Color(150, 0, 0, 255), TEXT_ALIGN_RIGHT)
				end
			end

			local but = GLButton(panel, GlorifiedBanking.i18n.GetPhrase("gbMenuTransfer"), panel:GetWide() / 2 - 5, 50, function()
				if not player_sel then return end
				if src:GetValue() ~= "" and not tonumber(src:GetValue()) then return end
				net.Start("McPhone.GlorifiedBanking.TransferRequested")
				net.WriteUInt(tonumber(src:GetValue()), 32)
				net.WriteEntity(player_sel)
				net.SendToServer()
			end, true)

			but:SetPos(panel:GetWide() / 2 + 5, 55)
			listed:AddItem(panel)
		end

		listed.Screens[3] = function(data)
			GLButton(listed, McPhone.GetPhrase("go_back"), listed:GetWide(), 50, function()
				listed.OpenScreen(1, w / 3, nil, 10)
			end)

			local panel = vgui.Create("DPanel")
			panel:SetSize(listed:GetWide(), 50)

			panel.Paint = function(self, w, h)
				draw.RoundedBox(8, 0, 0, w, h, Color(75, 140, 195))
				draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbTransactionsTime"), "McPhone.Main38", 10, h / 2, color_white, TEXT_ALIGN_LEFT, 1)
				draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbTransactionsType"), "McPhone.Main38", w * 0.2 + 10, h / 2, color_white, TEXT_ALIGN_LEFT, 1)
				draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbTransactionsUsers"), "McPhone.Main38", w * 0.4 + 10, h / 2, color_white, TEXT_ALIGN_LEFT, 1)
				draw.SimpleText(GlorifiedBanking.i18n.GetPhrase("gbTransactionsTotal"), "McPhone.Main38", w * 0.7 + 10, h / 2, color_white, TEXT_ALIGN_LEFT, 1)
			end

			listed:AddItem(panel)

			for k, v in ipairs(data) do
				GLLogPanel(listed, {v.Date, v.Type, v.User or "N/A", v.Amount}, listed:GetWide(), 50)
			end
		end

		listed.Screens[4] = function(data)
			GLButton(listed, McPhone.GetPhrase("go_back"), listed:GetWide(), 50, function()
				listed.OpenScreen(1, w / 3, nil, 10)
			end)

			local panel = vgui.Create("DPanel")
			panel:SetSize(listed:GetWide(), 65)

			panel.Paint = function(self, w, h)
				draw.RoundedBox(0, 0, 0, w, h, data[2])
				McPhone.DrawTexturedRect(0, 0, w, h, "gui/gradient_up", Color(0, 0, 0, 120))
				draw.SimpleText(data[1], "McPhone.Main38", w / 2, h / 2, color_white, TEXT_ALIGN_CENTER, 1)
			end

			listed:AddItem(panel)
		end

		listed.OpenScreen(1, w / 3, nil, 10)

		net.Receive("McPhone.GlorifiedBanking.DataRequested", function()
			if McPhone.ActiveWeb and McPhone.ActiveWeb.WebAdress:GetValue() == McPhone.WebModules["gl_bank"].url then
				local data = util.JSONToTable(net.ReadLargeString())

				for k, v in ipairs(data) do
					v.Amount = GlorifiedBanking.FormatMoney(v.Amount)
					v.Date = os.date("%d/%m/%y - %H:%M", v.Date)

					if v.ReceiverSteamID then
						v.Username = v.SteamID
					end
				end

				listed.OpenScreen(3, nil, nil, 1, table.Copy(data))
			end
		end)

		net.Receive("McPhone.GlorifiedBanking.TransferRequested", function()
			local msg = net.ReadString() or "error"
			local error_msg = net.ReadString()

			if error_msg and error_msg == "error" then
				error_msg = Color(150, 0, 0)
			else
				error_msg = Color(0, 150, 0)
			end

			listed.OpenScreen(4, nil, nil, 1, {msg, error_msg})
		end)
	end)
end

if SERVER then
	timer.Simple(5, function()
		if not GlorifiedBanking then return end

		local function PlayerAuthChecks(ply)
			return not (not ply:IsValid() or ply:IsBot() or not ply:IsFullyAuthenticated() or not ply:IsConnected())
		end

		local function ValidationChecks(ply, balance)
			return not GlorifiedBanking.LockdownEnabled or not balance or balance == nil or balance < 0 or not PlayerAuthChecks(ply)
		end

		net.Receive("McPhone.GlorifiedBanking.TransferRequested", function(len, ply)
			local amount = net.ReadUInt(32)
			if not ValidationChecks(ply, amount) then return end
			local receiver = net.ReadEntity()
			if not PlayerAuthChecks(receiver) then return end

			if amount <= 0 then
				net.Start("McPhone.GlorifiedBanking.TransferRequested")
				net.WriteString(GlorifiedBanking.i18n.GetPhrase("gbInvalidAmount"))
				net.WriteString("error")
				net.Send(ply)

				return
			end

			if not GlorifiedBanking.CanPlayerAfford(ply, amount) then
				net.Start("McPhone.GlorifiedBanking.TransferRequested")
				net.WriteString(GlorifiedBanking.i18n.GetPhrase("gbCannotAfford"))
				net.WriteString("error")
				net.Send(ply)

				return
			end

			GlorifiedBanking.TransferAmount(ply, receiver, amount)
			net.Start("McPhone.GlorifiedBanking.TransferRequested")
			net.WriteString(GlorifiedBanking.i18n.GetPhrase("gbCashTransferred", GlorifiedBanking.FormatMoney(amount), receiver:Name()))
			net.Send(ply)
			GlorifiedBanking.Notify(receiver, NOTIFY_GENERIC, 5, GlorifiedBanking.i18n.GetPhrase("gbCashTransferReceive", ply:Name(), GlorifiedBanking.FormatMoney(amount)))
		end)

		net.Receive("McPhone.GlorifiedBanking.DataRequested", function(len, ply)
			GlorifiedBanking.SQL.Query("SELECT * FROM `gb_logs` WHERE `SteamID` = '" .. ply:SteamID() .. "' OR `ReceiverSteamID` = '" .. ply:SteamID() .. "' ORDER BY `Date` DESC LIMIT 10", function(queryResult)
				timer.Simple(.5, function()
					net.Start("McPhone.GlorifiedBanking.DataRequested")
					net.WriteLargeString(util.TableToJSON(queryResult))
					net.Send(ply)
				end)
			end)
		end)
	end)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
