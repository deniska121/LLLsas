--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 3
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = McPhone.GetPhrase("GPS")
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/gps.png"

McPhone.Modules[module_id].openMenu = function()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	local m_list, m_active

	function m_list()
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("GPS")

		local gps = McPhone.Config.GPSList[game.GetMap()] or {}
		local rpsgps = McPhone.RPSGPSList and McPhone.RPSGPSList[game.GetMap()] or {}

		for k, v in SortedPairs(gps, false) do
			McPhone.ListNoIcons(McPhone.UI.Menu, k, function()
				McPhone.ToggleGPS(k, v)

				McPhone.GPSMenuRebuild = function()
					m_list()
				end

				m_active()
			end, true)
		end

		for k, v in SortedPairs(rpsgps, false) do
			McPhone.ListNoIcons(McPhone.UI.Menu, k, function()
				McPhone.ToggleGPS(k, v)

				McPhone.GPSMenuRebuild = function()
					m_list()
				end

				m_active()
			end, true)
		end

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id4.png", McPhone.MainColors["green"], nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	function m_active()
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = McPhone.IsGPSOn

		McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/buttons/id15.png", McPhone.GetPhrase("stop_gps"), false, function()
			McPhone.ToggleGPS()
		end, true)
	end

	if McPhone.IsGPSOn then
		m_active()
	else
		m_list()
	end
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
