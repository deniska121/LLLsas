--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 5
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = McPhone.GetPhrase("contacts")
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/cont.png"

McPhone.Modules[module_id].openMenu = function()
	local ply = LocalPlayer()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	local back = McPhone.UI.GoBack
	local m_list, m_number, m_manage

	function m_list()
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("contacts")
		local num = ply:AccountID()
		num = tostring(num)
		num = string.sub(num, 1, 1) .. "-" .. string.sub(num, 2, 4) .. "-" .. string.sub(num, 5, 6) .. "-" .. string.sub(num, 7, 10)

		McPhone.ListSimple(McPhone.UI.Menu, McPhone.GetPhrase("my_num"), num, "mc_phone/icons/buttons/id14.png", function()
			SetClipboardText(ply:AccountID())
			McPhone.Notify(McPhone.GetPhrase("text_copy"))
		end, true)

		if not McPhone.Config.GlobalContacts then
			McPhone.ListIcons(McPhone.UI.Menu, "mc_phone/icons/buttons/id3.png", McPhone.GetPhrase("manage_conts"), false, function()
				m_manage()
				McPhone.UI.GoBack = m_list
			end)
		end

		if McPhone.ExtraNumbers then
			for k, v in pairs(McPhone.ExtraNumbers) do
				if not v.addtocontacts then continue end
				McPhone.ListIcons(McPhone.UI.Menu, v.icon, v.nicename, false, function()
					local number = k
					McPhone.LastNumber = number
					local lastcall = number

					if lastcall then
						McPhone.LastNumber = lastcall
					end

					net.Start("McPhone.CallStart")
					net.WriteString(number)
					net.SendToServer()
				end)
			end
		end

		if McPhone.Config.GlobalContacts then
			for k, pl in pairs(player.GetAll()) do
				if ply == pl then continue end

				McPhone.ListIcons(McPhone.UI.Menu, pl, pl:Name(), false, function()
					local number = pl:AccountID()

					if pl:IsBot() then
						number = "268#" .. pl:UserID()
					end

					McPhone.LastNumber = number
					local lastcall = McPhone.GetByNumber(number)

					if lastcall then
						McPhone.LastNumber = lastcall
					end

					net.Start("McPhone.CallStart")
					net.WriteString(number)
					net.SendToServer()
				end)
			end
		else
			for k, v in pairs(McPhone.Contacts) do
				local pl = McPhone.GetByNumber(k)

				if pl and IsValid(pl) then
					McPhone.ListIcons(McPhone.UI.Menu, pl, pl:Name(), false, function()
						local number = k

						if pl:IsBot() then
							number = "268#" .. pl:UserID()
						end

						McPhone.LastNumber = number
						local lastcall = McPhone.GetByNumber(number)

						if lastcall then
							McPhone.LastNumber = lastcall
						end

						net.Start("McPhone.CallStart")
						net.WriteString(number)
						net.SendToServer()
					end)
				else
					McPhone.ListIcons(McPhone.UI.Menu, {"mc_phone/icons/contact.png", true}, v, false, function()
						local number = k
						McPhone.LastNumber = number
						net.Start("McPhone.CallStart")
						net.WriteString(number)
						net.SendToServer()
					end)
				end
			end
		end

		McPhone.UI.Buttons.Left = {
			"mc_phone/icons/buttons/id10.png", McPhone.MainColors["blue"], function()
				McPhone.UI.OpenedMenu = McPhone.GetPhrase("enter_number")
				m_number()
				McPhone.UI.GoBack = m_list
			end
		}

		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id17.png", McPhone.MainColors["green"], nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}

		McPhone.UI.GoBack = back
	end

	function m_manage()
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = McPhone.GetPhrase("manage_conts")

		for k, v in pairs(McPhone.Contacts) do
			local pl = McPhone.GetByNumber(k)

			if pl and IsValid(pl) then
				McPhone.ListIcons(McPhone.UI.Menu, pl, pl:Name(), false, function()
					McPhone.RemoveContacts(k)
					McPhone.GetContacts()
					m_manage()
				end)
			else
				McPhone.ListIcons(McPhone.UI.Menu, {"mc_phone/icons/contact.png", true}, v, false, function()
					McPhone.RemoveContacts(k)
					McPhone.GetContacts()
					m_manage()
				end)
			end
		end

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {"mc_phone/icons/buttons/id13.png", McPhone.MainColors["green"], nil}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}

		McPhone.UI.GoBack = back
	end

	function m_number()
		McPhone.UI.Menu.ConvertToMenu()
		local phone_table = McPhone.PhoneTypes[McPhone.UserCfg.PhoneType]

		if not phone_table then
			phone_table = McPhone.PhoneTypes.McPhone
		end

		McPhone.UI.Menu:SetSize(270, 256)
		McPhone.UI.Menu:SetPos(phone_table.scr_pos[1], phone_table.scr_pos[2] + 69)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "1", nil, nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "2", "ABC", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 86, "3", "DEF", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "4", "GHI", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "5", "JKL", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 86, "6", "MNO", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "7", "PQRS", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "8", "TUV", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 86, "9", "WXYZ", nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "*", nil, nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 85, "0", nil, nil)
		McPhone.NumberIcons(McPhone.UI.Menu, 86, "#", nil, nil)

		McPhone.UI.Buttons.Left = {
			"mc_phone/icons/buttons/id17.png", McPhone.MainColors["blue"], function()
				local number = McPhone.UI.OpenedMenu
				if number == McPhone.GetPhrase("enter_number") then return end
				McPhone.LastNumber = number
				local lastcall = McPhone.GetByNumber(number)

				if IsValid(lastcall) and lastcall ~= ply then
					McPhone.LastNumber = lastcall
					McPhone.AddContacts(number, lastcall:Name())
				end

				net.Start("McPhone.CallStart")
				net.WriteString(number)
				net.SendToServer()
			end
		}

		McPhone.UI.Buttons.Middle = {
			"mc_phone/icons/buttons/id4.png", McPhone.MainColors["green"], function()
				local number = McPhone.UI.OpenedMenu
				if number == McPhone.GetPhrase("enter_number") then return false end
				if McPhone.ExtraNumbers[number] then return false end
				if McPhone.Contacts[number] then return false end
				local lastcall = McPhone.GetByNumber(number)

				if IsValid(lastcall) and lastcall ~= ply then
					lastcall = lastcall:Name()
				else
					lastcall = number
				end

				McPhone.AddContacts(number, lastcall, true)

				return false
			end,
			true
		}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	m_list()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
