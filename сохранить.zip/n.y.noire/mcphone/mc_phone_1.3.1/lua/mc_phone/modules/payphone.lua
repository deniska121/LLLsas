--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

McPhone.PayPhone = McPhone.PayPhone or {}
if SERVER then return end
local NewFont = surface.CreateFont

NewFont("McPhone.LCD", {
	font = "Electronica-Normal",
	extended = true,
	size = 38,
	antialias = true,
	weight = 500
})

NewFont("McPhone.Hand", {
	font = "d_CCMatinee Idol",
	extended = true,
	size = 30,
	antialias = true,
	weight = 500
})

NewFont("McPhone.Payphone", {
	font = "The Capt",
	extended = true,
	size = 38,
	antialias = true,
	weight = 500
})

NewFont("McPhone.PayphoneS", {
	font = "The Capt",
	extended = true,
	size = 20,
	antialias = true,
	weight = 0
})

NewFont("McPhone.PayphoneB", {
	font = "The Capt",
	extended = true,
	size = 50,
	antialias = true,
	weight = 300
})

local function PayPhone_ListIcons(parent, text, func)
	local buton = vgui.Create("DButton")
	buton.check = check
	buton:SetSize(256, 30)
	buton:SetText("")
	buton.text_pos = 0
	buton.text_dir = CurTime() + 2

	buton.DoClick = function(self)
		McPhone.PlaySoundUI("mcphone/button_payphone.wav")

		if func then
			func(self)
		end
	end

	buton.Paint = function(self, w, h)
		if self.hover then
			draw.RoundedBox(0, 0, h - 3, w, 3, McPhone.MainColors.shadow_200)
		else
			draw.RoundedBox(0, 0, h - 3, w, 3, McPhone.MainColors.shadow_100)
		end

		draw.SimpleText(text, "McPhone.Hand", 5, 5, color_black, TEXT_ALIGN_LEFT)
	end

	buton.OnCursorEntered = function(self, mute)
		self.hover = true
	end

	buton.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(buton)

	return buton
end

function McPhone.PayPhone.Menu(pay_ent)
	local ply = LocalPlayer()
	if not McPhone.CanUsePhone(ply, true) or McPhone.UI or McPhone.PayPhone.UI then
		net.Start("McPhone.PayPhone")
		net.WriteEntity(pay_ent)
		net.SendToServer()

		return
	end

	net.Start("McPhone.PhoneStatus")
	net.WriteInt(2, 16)
	net.SendToServer()
	local number = McPhone.GetPhrase("enter_number")
	local text_pos = 0
	local text_dir, no_message
	local disable_buts = false
	local mat = Material("mc_phone/phone/payphone.png", "smooth")
	McPhone.PayPhone.UI = vgui.Create("DFrame")
	McPhone.PayPhone.UI:SetSize(600, 800)
	McPhone.PayPhone.UI:Center()
	McPhone.PayPhone.UI:SetTitle("")
	McPhone.PayPhone.UI:SetDraggable(false)
	McPhone.PayPhone.UI:MakePopup()
	McPhone.PayPhone.UI:ShowCloseButton(false)

	McPhone.PayPhone.UI.Paint = function(self, w, h)
		McPhone.DrawTexturedRect(0, 0, w, h, mat, color_white)
		draw.SimpleText("Double click '*' to remove number", "McPhone.PayphoneS", 55, 550, color_black, TEXT_ALIGN_LEFT)
		draw.SimpleText("Call Fee:", "McPhone.Payphone", 55, 580, color_black, TEXT_ALIGN_LEFT)
		draw.SimpleText("$2.10", "McPhone.PayphoneB", 55, 620, color_black, TEXT_ALIGN_LEFT)
	end

	McPhone.PayPhone.UI.Think = function(self)
		if McPhone.UI or McPhone.PreCache then
			no_message = true
			McPhone.PayPhone.UI:Close()
		end

		if not McPhone.CanUsePhone(ply, true) or not pay_ent or not IsValid(pay_ent) then
			McPhone.PayPhone.UI:Close()
		end

		if pay_ent and IsValid(pay_ent) and pay_ent:GetPos():DistToSqr(ply:GetPos()) > 5005 then
			McPhone.PayPhone.UI:Close()
		end
	end

	function McPhone.PayPhone.UI:OnRemove()
		McPhone.PayPhone.UI = nil

		if not McPhone.UI and not McPhone.PreCache then
			McPhone.StopCall()
		end

		net.Start("McPhone.PayPhone")
		net.WriteEntity(pay_ent)
		net.SendToServer()

		if not no_message and McPhone.Sound then
			McPhone.Sound:Stop()
			McPhone.Sound = nil
		end

		if not no_message or (no_message and not McPhone.UI) then
			net.Start("McPhone.PhoneStatus")
			net.WriteInt(0, 16)
			net.SendToServer()
		else
			net.Start("McPhone.PhoneStatus")
			net.WriteInt(1, 16)
			net.WriteBool(true)
			net.SendToServer()
		end
	end

	McPhone.PayPhone.UI.Update = function(status)
		if status == "Busy" or status == "No Signal" then
			timer.Simple(3, function()
				if McPhone.PayPhone.UI then
					number = McPhone.GetPhrase("enter_number")
					disable_buts = false
				end
			end)
		end

		number = string.upper(McPhone.GetPhrase(status))
		disable_buts = true
	end

	local contacts = vgui.Create("DPanelList", McPhone.PayPhone.UI)
	contacts:SetPos(317, 143)
	contacts:SetSize(265, 365)
	contacts:EnableHorizontal(false)
	contacts:EnableVerticalScrollbar()
	contacts:SetSpacing(0)
	contacts.Paint = function(self, w, h) end
	local m_manage

	function m_manage()
		contacts:Clear(true)

		for k, v in pairs(McPhone.Contacts) do
			local pl = McPhone.GetByNumber(k)

			PayPhone_ListIcons(contacts, (pl and IsValid(pl)) and pl:Name() or v, function()
				number = k
				McPhone.LastNumber = number
				net.Start("McPhone.CallStart")
				net.WriteString(number)
				net.SendToServer()
			end)
		end
	end

	m_manage()

	local button_list = {
		{
			text = "",
			x = 536,
			y = 16,
			func = function()
				McPhone.PayPhone.UI:Close()
			end
		},
		{
			text = "",
			x = 10,
			y = 117,
			func = function()
				if number == McPhone.GetPhrase("enter_number") then return end
				McPhone.LastNumber = number
				local lastcall = McPhone.GetByNumber(number)

				if IsValid(lastcall) and lastcall ~= ply then
					McPhone.LastNumber = lastcall
					McPhone.AddContacts(number, lastcall:Name())
				end

				net.Start("McPhone.CallStart")
				net.WriteString(number)
				net.SendToServer()
			end
		},
		{
			text = "1",
			x = 55,
			y = 209
		},
		{
			text = "2",
			x = 134,
			y = 209
		},
		{
			text = "3",
			x = 214,
			y = 209
		},
		{
			text = "4",
			x = 55,
			y = 290
		},
		{
			text = "5",
			x = 134,
			y = 290
		},
		{
			text = "6",
			x = 214,
			y = 290
		},
		{
			text = "7",
			x = 55,
			y = 370
		},
		{
			text = "8",
			x = 134,
			y = 370
		},
		{
			text = "9",
			x = 214,
			y = 370
		},
		{
			text = "*",
			x = 55,
			y = 453
		},
		{
			text = "0",
			x = 134,
			y = 453
		},
		{
			text = "#",
			x = 214,
			y = 453
		},
	}

	for k, v in pairs(button_list) do
		local buton = vgui.Create("DButton", McPhone.PayPhone.UI)
		buton:SetSize(60, 60)
		buton:SetPos(v.x, v.y)
		buton:SetText("")

		buton.DoClick = function(self)
			if disable_buts and not v.func then return end

			if not snd then
				McPhone.PlaySoundUI("mcphone/but_press.wav")
			end

			if not v.func then
				if number == McPhone.GetPhrase("enter_number") then
					number = v.text
				else
					number = number .. v.text
				end

				return
			end

			v.func(self)
		end

		if v.text == "*" and not disable_buts then
			buton.DoDoubleClick = function(self)
				number = McPhone.GetPhrase("enter_number")
			end
		end

		buton.spaser = 0

		buton.Paint = function(s, w, h)
			draw.SimpleText(v.text, "McPhone.Payphone", w / 2 + 2, h / 2 - 20, color_black, TEXT_ALIGN_CENTER)
		end
	end

	local panel = vgui.Create("DPanel", McPhone.PayPhone.UI)
	panel:SetPos(67, 122)
	panel:SetSize(200, 50)

	panel.Paint = function(self, w, h)
		local text = number
		surface.SetFont("McPhone.LCD")
		local tw = surface.GetTextSize(text)

		if tw > w then
			if text_dir and isnumber(text_dir) and text_dir < CurTime() then
				text_dir = nil
			end

			if text_pos > w - tw - 50 and not text_dir then
				text_pos = math.Approach(text_pos, w - tw - 50, FrameTime() * 70)
			else
				if text_pos >= 10 and not isnumber(text_dir) then
					text_dir = CurTime() + 2
				else
					text_pos = math.Approach(text_pos, 10, FrameTime() * 70)
				end

				if not text_dir then
					text_dir = true
				end
			end

			draw.SimpleText(text, "McPhone.LCD", text_pos, 10, color_black, TEXT_ALIGN_LEFT, 2)
		else
			draw.SimpleText(text, "McPhone.LCD", w / 2, 10, color_black, TEXT_ALIGN_CENTER, 2)
		end
	end
end

net.Receive("McPhone.PayPhone", function(msg)
	local ent = net.ReadEntity()

	if ent and IsValid(ent) then
		McPhone.PayPhone.Menu(ent)
	end
end)

hook.Add("McPhone.Hook.ClosePhone", "McPhone.PayPhone.ClosePhone", function(ply)
	if McPhone.PayPhone and McPhone.PayPhone.UI then
		McPhone.PayPhone.UI:Close()
	end
end)
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
