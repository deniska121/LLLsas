--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 11
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = "PBC"
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/pbc.png"
McPhone.Modules[module_id].number = 0

McPhone.Modules[module_id].openMenu = function()
	if not EmergencyDispatch then 
		McPhone.ClosePhone()
		return false
	end

	if not EmergencyDispatch.PoliceJobs[team.GetName(LocalPlayer():Team())] then
		McPhone.ClosePhone()
		return false
	end

	-- Проверяем существование функции CreateBodycamStudio
	if not EmergencyResponse_DLC_PoliceEquipmentGear or not EmergencyResponse_DLC_PoliceEquipmentGear.CreateBodycamStudio then
		McPhone.ClosePhone()
		return false
	end

	EmergencyResponse_DLC_PoliceEquipmentGear:CreateBodycamStudio(ScrW(), ScrH(), 0, 0)
	McPhone.ClosePhone()
end

McPhone.Modules[module_id].CheckFunction = function()
	if not EmergencyDispatch then return false end
	if not EmergencyDispatch.PoliceJobs[team.GetName(LocalPlayer():Team())] then return false end
	
	-- Также проверяем доступность функции CreateBodycamStudio
	if not EmergencyResponse_DLC_PoliceEquipmentGear or not EmergencyResponse_DLC_PoliceEquipmentGear.CreateBodycamStudio then
		return false
	end

	return true
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000