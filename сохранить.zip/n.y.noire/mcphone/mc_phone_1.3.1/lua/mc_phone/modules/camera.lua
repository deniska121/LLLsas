--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
local module_id = 4
McPhone.Modules[module_id] = {}
McPhone.Modules[module_id].name = McPhone.GetPhrase("camera")
McPhone.Modules[module_id].icon = "mc_phone/icons/main_menu/cam.png"

McPhone.Modules[module_id].openMenu = function()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	local m_list

	function m_list()
		McPhone.UI.Menu.ConvertToList()
		local frame = vgui.Create("DPanel")
		frame:SetSize(256, 256)
		frame:SetDisabled(true)

		frame.Paint = function(self, w, h)
			local origin = LocalPlayer():GetShootPos()
			local angles = LocalPlayer():EyeAngles()
			local x, y = self:LocalToScreen(0, 0)
			y = y - 44
			h = h + 44
			cam.Start2D()
			local CamData = {}
			CamData.angles = angles
			CamData.origin = origin
			CamData.x = x
			CamData.y = y
			CamData.drawviewmodel = false
			CamData.drawhud = false
			CamData.offcenter = false
			CamData.dopostprocess = false
			CamData.w = w
			CamData.h = h
			render.RenderView(CamData)
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawLine(x + w / 3, y, x + w / 3, y + h)
			surface.DrawLine(x + (w / 3) * 2, y, x + (w / 3) * 2, y + h)
			surface.DrawLine(x, y + h / 3, x + w, y + h / 3)
			surface.DrawLine(x, y + (h / 3) * 2, x + w, y + (h / 3) * 2)
			cam.End2D()
		end

		McPhone.UI.Menu:AddItem(frame)

		McPhone.UI.Buttons.Left = {nil, nil, nil}

		McPhone.UI.Buttons.Middle = {
			"mc_phone/icons/buttons/id4.png", McPhone.MainColors["green"], function()
				if McPhone.camera then return end
				McPhone.UI:SetVisible(false)
				McPhone.camera = vgui.Create("DFrame")
				McPhone.camera:SetSize(ScrW(), ScrH())
				McPhone.camera:SetPos(0, 0)
				McPhone.camera:SetTitle("")
				McPhone.camera:SetDraggable(false)
				McPhone.camera:ShowCloseButton(false)

				McPhone.camera.Paint = function(self, w, h)
					local origin = LocalPlayer():GetShootPos()
					local angles = LocalPlayer():EyeAngles()
					cam.Start2D()
					local CamData = {}
					CamData.angles = angles
					CamData.origin = origin
					CamData.drawviewmodel = false
					CamData.x = 0
					CamData.y = 0
					CamData.drawhud = false
					CamData.w = ScrW()
					CamData.h = ScrH()
					render.RenderView(CamData)
					cam.End2D()
					draw.SimpleText(McPhone.Config.CameraWaterMark, "McPhone.Main38", ScrW() - 9, ScrH() - 54, Color(0, 0, 0, 190), TEXT_ALIGN_RIGHT)
					draw.SimpleText(McPhone.Config.CameraWaterMark, "McPhone.Main38", ScrW() - 10, ScrH() - 55, Color(255, 255, 255), TEXT_ALIGN_RIGHT)
				end

				LocalPlayer():ConCommand("screenshot")

				timer.Simple(1, function()
					McPhone.UI:SetVisible(true)
					McPhone.camera:Remove()
					McPhone.camera = nil
				end)
			end
		}

		McPhone.UI.Buttons.Right = {"mc_phone/icons/buttons/id15.png", McPhone.MainColors["red"], nil}
	end

	m_list()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
