--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
if SERVER or not Realistic_Properties then return end

McPhone.WebModules["rl_pr"] = {}
McPhone.WebModules["rl_pr"].name = "Realistic Properties"
McPhone.WebModules["rl_pr"].url = "https://realistic-properties.com"


McPhone.WebModules["rl_pr"].OpenWebmenu = function()
	McPhone.ActiveWeb:Close()
	McPhone.ActiveWeb = nil
	Realistic_Properties.OpenMenu(0, 0, ScrW(), ScrH())
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
