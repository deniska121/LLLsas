--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
local files = file.Find("mc_phone/language/*", "LUA")

for k, v in pairs(files) do
    if (SERVER) then
        include("mc_phone/language/" .. v)
        AddCSLuaFile("mc_phone/language/" .. v)
        MsgC(Color(0, 0, 255), "[McPhone] " .. v .. " language found\n")
    else
        include("mc_phone/language/" .. v)
    end
end

function McPhone.GetPhrase(name, ...)
    local lang = McPhone.Language[McPhone.Config.Language] or McPhone.Language["en"]
    local prase = lang[name]

    if not prase then
        prase = McPhone.Language["en"][name]
    end

    if not prase then return name end

    return string.format(prase, ...)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
