--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- ╔═╗╔═╦═══╗╔═══╦╗────────────--
-- ║║╚╝║║╔═╗║║╔═╗║║────────────--
-- ║╔╗╔╗║║─╚╝║╚═╝║╚═╦══╦═╗╔══╗ --
-- ║║║║║║║─╔╗║╔══╣╔╗║╔╗║╔╗╣║═╣ --
-- ║║║║║║╚═╝║║║──║║║║╚╝║║║║║═╣ --
-- ╚╝╚╝╚╩═══╝╚╝──╚╝╚╩══╩╝╚╩══╝ --
-- ───── By Mactavish ─────────--
-- ────────────────────────────--
-- DO NOT EDIT ANYTHING HERE, UNLESS YOU KNOW WHAT YOU ARE DOING
-- Here you can create easter eggs :)
function McPhone.CanUsePhone(ply, is_payphone, incoming)
	if not IsValid(ply) then return false end
	if not ply:Alive() or not ply:GetNWBool("McPhone.HasPhone") then return false end

	-- Z-City fake/death ragdoll state: the player cannot access the phone.
	local fakeRagdoll = ply.FakeRagdoll
	local nwFake = ply:GetNWEntity("FakeRagdoll")
	local deathRagdoll = ply:GetNWEntity("RagdollDeath")
	if IsValid(fakeRagdoll) or IsValid(nwFake) or IsValid(deathRagdoll) then return false end
	if DarkRP and ply:getDarkRPVar("Arrested") then return false end
	if SERVER and is_payphone and ply.McPhoneData and ply.McPhoneData.Sleep then return false end

	if not is_payphone then
		return not hook.Call("McPhone.Hook.BlockPhone", nil, ply, incoming)
	else
		return not hook.Call("McPhone.Hook.BlockPayPhone", nil, ply)
	end
end

McPhone.ExtraNumbers = {}

McPhone.ExtraNumbers["88005553535"] = {
	delay = 12,
	icon = "nope.png",
	nicename = "8-800-555-35-35!",
	sound = {"http://macnco.one/sounds/88005553535.mp3", true},
}

McPhone.ExtraNumbers["1990"] = {
	delay = 60,
	icon = "nope.png",
	nicename = "Big Bill Hell's Cars",
	sound = {"http://macnco.one/sounds/big_bill.mp3", true},
}

McPhone.ExtraNumbersFunc = {}

function McPhone.GetCurTime()
	local time = "00:00"
	time = os.date("%H:%M", os.time())

	if McPhone.Config.StormFoxTime and (StormFox or StormFox2) then
		time = StormFox and StormFox.GetRealTime(nil, false) or (StormFox2.Time.TimeToString( StormFox2.Time.Get(), false) )
	end

	return time
end

function McPhone.GetByNumber(number)
	if McPhone.ExtraNumbers[number] then return McPhone.ExtraNumbers[number] end

	if string.Explode("#", number)[1] == "268" then
		return Player(tonumber(string.Explode("#", number)[2]))
	else
		return player.GetByAccountID(tonumber(number))
	end

	return false
end

function McPhone.DefaultNotify(ply, type, time, message)
	if SERVER then
		if DarkRP then
			DarkRP.notify(ply, type, time, message)
		elseif ix then
			ix.util.Notify(message, ply)
		else
			ply:ChatPrint(message)
		end
	else
		if GAMEMODE.AddNotify then
			GAMEMODE:AddNotify(message, type, time)
		elseif ix then
			ix.util.Notify(message)
		else
			ply:ChatPrint(message)
		end
	end
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
