--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000


-- Services https://www.gmodstore.com/market/view/services-request-and-respond-replace-advert
if not CONFIG_SERVICES then return end
local function LoadServices()
	local i = 0

	for k, v in pairs(CONFIG_SERVICES.Settings) do
		McPhone.ExtraNumbers["10" .. i] = {
			delay = 2,
			icon = {v.icon, true},
			icon_call = v.icon,
			nicename = k,
			addtocontacts = true,
			sound = {"http://macnco.one/sounds/hello.wav", true},
			func = "10" .. i,
			delay_func = "SERVICES" .. k,
		}

		McPhone.ExtraNumbersFunc["10" .. i] = function()
			if not McPhone.UI or not McPhone.UI.Menu then return end
			local back = McPhone.UI.GoBack
			McPhone.UI.Menu.ConvertToList()
			McPhone.UI.OpenedMenu = v.Description
			local price = v.price

			if price < 1 then
				price = "Free"
			else
				price = DarkRP.formatMoney(price)
			end

			McPhone.ListSimple(McPhone.UI.Menu, price, "Online: " .. v.plyOnline, v.icon, function()
				ServicesCall(k, v.icon, LocalPlayer():GetPos())
				back()
			end, true)

			McPhone.SetKey(1, true)
		end

		if SERVER then
			hook.Remove("PlayerSay", "servicesCommand")

			McPhone.ExtraNumbersFunc["SERVICES" .. k] = function(sender)
				if sender.calling and CurTime() - 60 < sender.calling then
					return true
				end
				return true
			end
		end

		i = i + 1
	end
end

if SERVER then
	timer.Simple(5, function()
		LoadServices()
	end)
else
	LoadServices()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
