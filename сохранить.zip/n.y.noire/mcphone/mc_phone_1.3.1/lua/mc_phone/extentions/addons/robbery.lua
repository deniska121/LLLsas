--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- Advanced Robbery https://www.gmodstore.com/market/view/advanced-jewelry-robbery-another-way-to-earn-money-illegally
if not AdvancedRobbery then return end

McPhone.ExtraNumbers["9523877"] = {
	delay = 5.5,
	icon = {"mc_phone/icons/contact.png", true},
	icon_call = "mc_phone/icons/contact.png",
	nicename = McPhone.GetPhrase("char_dealer"),
	addtocontacts = true,
	sound = {"http://macnco.one/sounds/dealer.wav", true},
	func = nil,
	delay_func = "AdvancedRobbery_del",
}

if SERVER then
	McPhone.ExtraNumbersFunc["AdvancedRobbery_del"] = function(caller)
		AdvancedRobbery.NPCInfos = AdvancedRobbery.NPCInfos or {
			free = true,
			pos = Vector(0, 0, 0),
			lastCall = -AdvancedRobbery.Config.TimeBetween2CallNPC,
			caller = NULL,
		}

		local stop = false

		if AdvancedRobbery_IsRobber(caller) and AdvancedRobbery.NPCInfos.free and CurTime() - AdvancedRobbery.NPCInfos.lastCall > AdvancedRobbery.Config.TimeBetween2CallNPC then
			timer.Simple(7, function()
				if caller and IsValid(caller) then
					AdvancedRobbery.CreateNPC(caller)
				end
			end)
		else
			stop = true
		end

		return stop
	end
end

--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
