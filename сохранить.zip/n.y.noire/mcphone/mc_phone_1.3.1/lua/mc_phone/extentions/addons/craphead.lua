--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

if CH_TowTruck then
	McPhone.ExtraNumbers["5557090"] = {
		delay = 3,
		icon = {"mc_phone/icons/contacts/char_mechanic.png", true},
		icon_call = "mc_phone/icons/contacts/char_mechanic.png",
		nicename = CH_TowTruck.Config.Lang["Tow Service"][CH_TowTruck.Config.Language],
		addtocontacts = true,
		sound = {"vo/coast/odessa/nlo_cub_hello.wav", false},
		func = "5557090",
	}

	McPhone.ExtraNumbersFunc["5557090"] = function()

		if not McPhone.UI or not McPhone.UI.Menu then return end
		local back = McPhone.UI.GoBack
		McPhone.UI.Menu.ConvertToList()
		McPhone.UI.OpenedMenu = CH_TowTruck.Config.Lang["Tow Service"][CH_TowTruck.Config.Language]

		McPhone.ListSimple(McPhone.UI.Menu, McPhone.GetPhrase("RequestTow"), "", "mc_phone/icons/settings/id_5.png", function()
			net.Start("CH_TowTruck_CallTowService")
			net.SendToServer()
			back()
		end, true)

		McPhone.ListSimple(McPhone.UI.Menu, McPhone.GetPhrase("CallTower"), "", "mc_phone/icons/buttons/id17.png", function()
			back()
			for k, tower in ipairs(player.GetAll()) do
				if not tower:CH_TOW_IsTower() or not tower:Alive() or not McPhone.CanUsePhone(tower, nil, true) then continue end
				net.Start("McPhone.CallStart")
				net.WriteString(tower:AccountID())
				net.SendToServer()
			end
		end, true)

		McPhone.SetKey(1, true)
	end

	hook.Remove("OnPlayerChat", "CH_TowTruck.PlayerChatCommands")
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
