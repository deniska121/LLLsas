--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- SlownLS Taxi https://www.gmodstore.com/market/view/slownls-taxi-an-advanced-taxi-system
if SlownLS and SlownLS.Taxi then
	McPhone.ExtraNumbers["031824"] = {
		delay = 3,
		icon = {"mc_phone/icons/contacts/char_taxi.png", true},
		icon_call = "mc_phone/icons/contacts/char_taxi.png",
		nicename = McPhone.GetPhrase("char_taxi"),
		addtocontacts = true,
		sound = {"http://macnco.one/sounds/taxi/" .. math.random(1, 3) .. ".wav", true},
		func = "031824",
		delay_func = "031824_del",
	}

	McPhone.ExtraNumbersFunc["031824"] = function(pPlayer)
		SlownLS.Taxi:Call()

		return true
	end

	McPhone.ExtraNumbersFunc["031824_del"] = function(caller)
		if SlownLS.Taxi:HasJob(caller) then return true, SlownLS.Taxi:Notify(caller, SlownLS.Taxi:GetLanguage("player_can"), SlownLS.Taxi:GetColor("red")) end
		if caller:Taxi_HasRequest() then return true, SlownLS.Taxi:Notify(caller, SlownLS.Taxi:GetLanguage("already_request"), SlownLS.Taxi:GetColor("red")) end

		return false
	end

	if SERVER then
		hook.Remove("PlayerSay", "SlownLS:Taxi:Player:Say")
	end
end

-- SlownLS Hitman https://www.gmodstore.com/market/view/slownls-hitman-an-advanced-hitman-system
if SlownLS and SlownLS.Hitman then
	McPhone.ExtraNumbers["031825"] = {
		delay = 2,
		icon = {"mc_phone/icons/contacts/char_lester.png", true},
		icon_call = "mc_phone/icons/contacts/char_lester.png",
		nicename = McPhone.GetPhrase("Hitman"),
		addtocontacts = true,
		sound = {"http://macnco.one/sounds/hello.wav", true},
		func = "031825",
		delay_func = "031825",
	}

	McPhone.ExtraNumbersFunc["031825"] = function() return true end

	if SERVER then
		McPhone.ExtraNumbersFunc["031825"] = function(ply)
			if (SlownLS.Hitman.Config.BlackList[team.GetName(ply:Team())]) then return true end

			timer.Simple(7, function()
				SlownLS.Hitman:sendEvent("open_phone", {
					ent = nil
				}, ply)
			end)

			return false
		end
	end
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
