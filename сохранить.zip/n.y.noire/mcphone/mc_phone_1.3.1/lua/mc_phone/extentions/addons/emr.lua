-- Emergency Response https://www.gmodstore.com/market/view/6890
if not EmergencyResponse then return end

McPhone.ExtraNumbers["911"] = {
	delay = 3,
	icon = {"mc_phone/icons/contacts/char_call911.png", true},
	icon_call = "mc_phone/icons/contacts/char_call911.png",
	nicename = McPhone.GetPhrase("char_911"),
	addtocontacts = true,
	sound = {"http://macnco.one/sounds/911.wav", true},
	func = "911",
	delay_func = "911_check",
}

McPhone.ExtraNumbersFunc["911"] = function()
	if not McPhone.UI or not McPhone.UI.Menu then return end
	local back = McPhone.UI.GoBack
	McPhone.UI.Menu.ConvertToList()
	McPhone.UI.OpenedMenu = McPhone.GetPhrase("char_911")

	-- Исправленные пути к языковым строкам
	local policeText = EmergencyDispatch and EmergencyDispatch.Lang and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang] and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang].victimderma_LawEnforcement or "Law Enforcement"
	local emsText = EmergencyDispatch and EmergencyDispatch.Lang and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang] and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang].victimderma_EMS or "EMS"
	local fireText = EmergencyDispatch and EmergencyDispatch.Lang and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang] and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang].victimderma_Firefighters or "Firefighters"
	
	local introText = EmergencyDispatch and EmergencyDispatch.Lang and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang] and EmergencyDispatch.Lang[EmergencyDispatch.BaseLang].victimderma_TextIntro_Available or "Available: "

	McPhone.ListSimple(McPhone.UI.Menu, policeText, introText .. EmergencyResponse:GetPlayersInJob(EmergencyDispatch.PoliceJobs), "mc_phone/icons/settings/id_3.png", function()
		EmergencyResponse:VictimSendEmergency(EmergencyResponse:GetClientEmergency(policeText))
		back()
	end, true)

	McPhone.ListSimple(McPhone.UI.Menu, emsText, introText .. EmergencyResponse:GetPlayersInJob(EmergencyDispatch.MedicJobs), "mc_phone/icons/buttons/id16.png", function()
		EmergencyResponse:VictimSendEmergency(EmergencyResponse:GetClientEmergency(emsText))
		back()
	end, true)

	McPhone.ListSimple(McPhone.UI.Menu, fireText, introText .. EmergencyResponse:GetPlayersInJob(EmergencyDispatch.FirefightersJobs), "mc_phone/icons/buttons/id12.png", function()
		EmergencyResponse:VictimSendEmergency(EmergencyResponse:GetClientEmergency(fireText))
		back()
	end, true)

	McPhone.SetKey(1, true)
end

if SERVER then
	hook.Remove("PlayerSay", "EmergencyResponse:VictimInterface:PlayerSay")

	McPhone.ExtraNumbersFunc["911_check"] = function()
		local nUse = cookie.GetNumber("_cooldownDelayNextUse", 0)
		local nTime = os.time()
		local stop = false

		if not EmergencyDispatch.InstantEmergencyCall then
			if nTime < nUse then
				stop = true
			end

			cookie.Set("_cooldownDelayNextUse", nTime + EmergencyDispatch.DispatchCallouts.CallCooldown)
		end

		return stop
	end
end