--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

if not FleodonServices then return end

local flServicesList = {}

if SERVER then
	util.AddNetworkString("McPhone.FleodonServices.ListForPhone")

	net.Receive("McPhone.FleodonServices.ListForPhone", function(sLen, pPlayer)
		net.Start("McPhone.FleodonServices.ListForPhone")
		net.WriteString(util.TableToJSON(FleodonServices.DATAServices))
		net.Send(pPlayer)
		flServicesList = FleodonServices.DATAServices

		for k, v in pairs(flServicesList) do
			McPhone.ExtraNumbers[k] = {
				delay = 2,
				icon = {"https://i.imgur.com/iYqLJm9.png", true, true},
				icon_call = "mc_phone/icons/contacts/char_chat_call.png",
				nicename = v.Name,
				call_bg = {v.Image, true},
				addtocontacts = true,
				sound = {"http://macnco.one/sounds/hello.wav", true},
				func = k,
			}

			McPhone.ExtraNumbersFunc[k] = function() end
		end
	end)
end

if CLIENT then
	net.Start("McPhone.FleodonServices.ListForPhone")
	net.SendToServer()

	net.Receive("McPhone.FleodonServices.ListForPhone", function()
		local strJSON = net.ReadString()
		flServicesList = util.JSONToTable(strJSON)

		for k, v in pairs(flServicesList) do
			McPhone.ExtraNumbers[k] = {
				delay = 2,
				icon = {"https://i.imgur.com/iYqLJm9.png", true, true},
				icon_call = "mc_phone/icons/contacts/char_chat_call.png",
				call_bg = {v.Image, true},
				nicename = v.Name,
				addtocontacts = true,
				sound = {"http://macnco.one/sounds/hello.wav", true},
				func = k,
			}

			McPhone.ExtraNumbersFunc[k] = function()
				FleodonServices:ContactService(nil, nil, v, 0, 0, true)

				return true
			end
		end
	end)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
