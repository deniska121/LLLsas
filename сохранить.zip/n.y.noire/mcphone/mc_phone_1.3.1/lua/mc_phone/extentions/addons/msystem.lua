--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- Mechanical System https://www.gmodstore.com/market/view/mechanical-system
if not MSystem then return end

McPhone.ExtraNumbers["9527090"] = {
	delay = 3,
	icon = {"mc_phone/icons/contacts/char_mechanic.png", true},
	icon_call = "mc_phone/icons/contacts/char_mechanic.png",
	nicename = MSystem:GetConfig("NPCHead", "title"),
	addtocontacts = true,
	sound = {"vo/coast/odessa/nlo_cub_hello.wav", false},
	func = "9527090",
}

McPhone.ExtraNumbersFunc["9527090"] = function()
	MSystem:NetStart("SendRequest")

	return true
end

hook.Remove("OnPlayerChat", "MSystem.Player:OnPlayerChat")

if SERVER then
	hook.Add("MSystem:Fine:Sent", "McPhone.MSystem:Fine:Sent", function(p1, p2, price)
		net.Start("McPhone.SendMail")
		net.WriteString(MSystem:GetConfig("NPCHead", "title"))
		net.WriteString(MSystem:GetLang("towFine.received") .. ". " .. MSystem:GetLang("vgui.price") .. " : " .. DarkRP.formatMoney(price))
		net.Send(p2)
	end)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
