--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

-- Advanced Police Mod https://www.gmodstore.com/market/view/advanced-police-mod
if not VS_PoliceMod then return end

McPhone.ExtraNumbers["102"] = {
	delay = 3,
	icon = {"mc_phone/icons/contacts/add_police.png", true},
	icon_call = "mc_phone/icons/contacts/add_police.png",
	nicename = McPhone.GetPhrase("char_pd"),
	addtocontacts = true,
	sound = {"http://macnco.one/sounds/police.wav", true},
	func = "102",
}

McPhone.ExtraNumbersFunc["102"] = function()
	VS_PoliceMod:DisplayHelpCallMenu()
	return true
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
