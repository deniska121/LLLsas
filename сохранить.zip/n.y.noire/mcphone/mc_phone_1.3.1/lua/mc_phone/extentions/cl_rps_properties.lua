-- Realistic Properties -> MC Phone GPS integration
-- Keeps RPS-owned GPS markers separate from MC Phone's permanent GPS config.

McPhone.RPSGPSList = McPhone.RPSGPSList or {}

local function RPSGPSMap()
    local map = game.GetMap()
    McPhone.RPSGPSList[map] = McPhone.RPSGPSList[map] or {}
    return McPhone.RPSGPSList[map]
end

local function RPSGPSClear()
    McPhone.RPSGPSList[game.GetMap()] = {}

    if McPhone.IsGPSOn and string.StartWith(tostring(McPhone.IsGPSOn), "RPS | ") then
        McPhone.ToggleGPS()
    end

    if McPhone.GPSMenuRebuild then
        McPhone.GPSMenuRebuild()
    end
end

local function RPSGPSApply(points)
    if not istable(points) then
        points = {}
    end

    local map = RPSGPSMap()
    table.Empty(map)

    for _, point in ipairs(points) do
        if istable(point) and isstring(point.name) and point.name ~= "" and isvector(point.pos) then
            map["RPS | " .. point.name] = point.pos
        end
    end

    if McPhone.IsGPSOn and string.StartWith(tostring(McPhone.IsGPSOn), "RPS | ") then
        if map[McPhone.IsGPSOn] == nil then
            McPhone.ToggleGPS()
        end
    end

    if McPhone.GPSMenuRebuild then
        McPhone.GPSMenuRebuild()
    end
end

net.Receive("RealisticProperties:MCPhoneGPSSync", function()
    local count = net.ReadUInt(8)
    local points = {}

    for i = 1, count do
        points[i] = {
            name = net.ReadString(),
            pos = net.ReadVector()
        }
    end

    RPSGPSApply(points)
end)

hook.Add("InitPostEntity", "McPhone.RealisticPropertiesGPSReady", function()
    if McPhone.RPSGPSList[game.GetMap()] == nil then
        McPhone.RPSGPSList[game.GetMap()] = {}
    end
end)
