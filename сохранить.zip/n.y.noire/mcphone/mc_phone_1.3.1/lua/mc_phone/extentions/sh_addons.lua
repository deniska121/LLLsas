--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

function McPhone.LoadAddons()
	local f = file.Find("mc_phone/extentions/addons/*", "LUA")

	for k, v in pairs(f) do
		include("mc_phone/extentions/addons/" .. v)
		if SERVER then AddCSLuaFile("mc_phone/extentions/addons/" .. v) end
	end
end

if SERVER then
	hook.Add("PostGamemodeLoaded", "McPhone.LoadAddons", function()
		McPhone.LoadAddons()
	end)
end

if GAMEMODE then
	McPhone.LoadAddons()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
