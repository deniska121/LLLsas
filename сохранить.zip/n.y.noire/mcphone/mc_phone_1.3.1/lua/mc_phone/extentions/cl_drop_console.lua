concommand.Add("mcphone_drop", function()
	net.Start("McPhone.DropPhone")
	net.SendToServer()
end)
