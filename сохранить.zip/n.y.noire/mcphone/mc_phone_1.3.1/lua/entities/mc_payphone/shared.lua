--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "PayPhone"
ENT.Author = "Mactavish"
ENT.Category = "McPhone"
ENT.Spawnable = false
ENT.AdminOnly = true
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "StatIdle")
end

if CLIENT then
	function ENT:Think()
		if self:GetStatIdle() then
			local Pos = self:LocalToWorld(Vector(0.062500, 0.343750, 0.125000))
			local Ang = self:LocalToWorldAngles(Angle(0.621, -1.593, -0.033))

			if not self.SubModel then
				self.SubModel = ents.CreateClientProp()
				self.SubModel:SetModel("models/props_trainstation/payphone_reciever001a.mdl")
				self.SubModel:SetAngles(Ang)
				self.SubModel:SetPos(Pos)
				self.SubModel:SetParent(self)
				self.SubModel:Spawn()
			end

			if IsValid(self.SubModel) then
				self.SubModel:SetAngles(Ang)
				self.SubModel:SetPos(Pos)
				self.SubModel:SetParent(self)
			end
		else
			if IsValid(self.SubModel) then
				self.SubModel:Remove()
				self.SubModel = nil
			end
		end
	end

	function ENT:OnRemove()
		if IsValid(self.SubModel) then
			self.SubModel:Remove()
		end
	end

	return
end

function ENT:Initialize()
	self:SetModel("models/props_trainstation/payphone001a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetMaterial("models/payphone")
	self.IsPayPhone = true
	--local phys = self:GetPhysicsObject()
	--phys:Wake()
	self:SetStatIdle(true)
end

net.Receive("McPhone.PayPhone", function(ln, ply)
	local ent = net.ReadEntity()

	if ent and IsValid(ent) and ent.IsPayPhone then
		ent:SetStatIdle(true)
		ply.McPayPhone = nil
		ent:EmitSound("mc_phone/payphone_out.wav")
	end
end)

function ENT:Use(ply)
	if ((self.nextUse or 0) < CurTime()) then
		self.nextUse = CurTime() + 1
	else
		return
	end

	if not self:GetStatIdle() then return end
	if ply:GetNWInt("McPhone.Active") > 0 then return end
	if not McPhone.CanUsePhone(ply, true) then return end
	if self:GetPos():DistToSqr(ply:GetPos()) > 5000 then return end
	self:SetStatIdle(false)
	ply.McPayPhone = self
	self:EmitSound("mc_phone/payphone_in.wav")
	net.Start("McPhone.PayPhone")
	net.WriteEntity(self)
	net.Send(ply)
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000





