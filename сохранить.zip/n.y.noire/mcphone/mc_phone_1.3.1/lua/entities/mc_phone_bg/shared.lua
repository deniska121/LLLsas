--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000

AddCSLuaFile()
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Badger Phone"
ENT.Author = "Mactavish"
ENT.Category = "McPhone"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.AdminSpawnable = false
if CLIENT then return end

function ENT:Initialize()
	self:SetModel("models/mactavish/bg_phone.mdl")
	self:SetColor(Color(20, 140, 30))
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetNWString("Last Owner", "")
	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.profile = {
		Ringtone = McPhone.Badger.Ringtone["8"],
		Smstone = McPhone.NotificationTone["2"],
		Sleep = false,
		PhoneColor = Color(20, 140, 30),
		WallPaper = "phone_wallpaper_badgerdefault.png",
		PhoneType = "Badger"
	}
end

function ENT:Use(ply)
	if ply.usedphone and ply.usedphone > CurTime() then return end
	ply.usedphone = CurTime() + 1

	if ply:GetNWBool("McPhone.HasPhone") then
		McPhone.DefaultNotify(ply, 1, 4, "You have a phone")

		return
	end

	local hook_check = hook.Call("McPhone.Hook.BlockPhonePickup", nil, ply)
	if hook_check then return end
	ply:SetNWBool("McPhone.HasPhone", true)
	ply:SetPData("McPhone.HasPhone", 1)

	if self.profile then
		net.Start("McPhone.GetUserData")
		net.WriteTable(self.profile)
		net.Send(ply)
	end

	hook.Call("McPhone.Hook.OnPhonePicked", nil, ply, self)
	self:Remove()
end
--leak by matveicher
--vk group - https://vk.com/gmodffdev
--steam - https://steamcommunity.com/profiles/76561198968457747/
--ds server - https://discord.gg/V329W7Ce8g
--ds - matveicher#2000
