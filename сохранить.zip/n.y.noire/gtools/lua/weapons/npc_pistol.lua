-- "addons\\gtools\\lua\\weapons\\npc_pistol.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()
SWEP.Category = "NPC Weapons"
SWEP.Author = "MacTavish"
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.Instructions = ""
SWEP.ViewModel = ""
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"
SWEP.Spawnable = false
SWEP.AdminSpawnable = false
SWEP.Primary.ClipSize = 18 -- Size of a clip
SWEP.Primary.DefaultClip = 18 -- Default number of bullets in a clip
SWEP.Primary.Automatic = true -- Automatic/Semi Auto
SWEP.Primary.Ammo = "SMG1"
SWEP.Primary.Damage = 10
SWEP.Primary.Delay = 0.1
SWEP.Primary.Penetrate = 10
SWEP.Primary.NumShots = 1
SWEP.Primary.Sound = Sound("MW19_GLOCK.Fire")

if CLIENT then
	SWEP.PrintName = "NPC Pistol"
	SWEP.Slot = 2
	SWEP.SlotPos = 2
end

function SWEP:SetupDataTables()
	self:NetworkVar("Int", 0, "GunType")
end

SWEP.Weight = 30
SWEP.AutoSwitchTo = true
SWEP.AutoSwitchFrom = true

SWEP.SpawnVars = {
	[1] = {"models/weapons/w_pist_glock18.mdl", Sound("MW19_GLOCK.Fire"), 27, 13},
	[2] = {"models/weapons/w_pist_p228.mdl", Sound("MW19_P320.Fire"), 23, 15},
	[3] = {"models/weapons/w_pist_elite_single.mdl", Sound("MW19_M9.Fire"), 23, 15}
}

function SWEP:Initialize()
	self:SetWeaponHoldType("pistol")

	if SERVER then
		self:GetOwner():Fire("DisableWeaponPickup")
		self:GetOwner():SetKeyValue("spawnflags", "256")
		self:SetGunType(math.random(#self.SpawnVars))
	end

	timer.Simple(1, function()
		if not IsValid(self) then return end
		local wt = self.SpawnVars[self:GetGunType()]
		self.Primary.Sound = wt[2]
		self.Primary.Damage = wt[3]
		self.Primary.ClipSize = wt[4]
		self.Primary.DefaultClip = wt[4] + 10
		self.WorldModel = wt[1]
		if not IsValid(self:GetOwner()) then return end
		self:GetOwner().DeadGun = wt[1]
	end)
end

function SWEP:PrimaryAttack()
	if self:GetNextPrimaryFire() > CurTime() then return end

	if self:Clip1() <= 10 then
		self:NpcReload()
		return
	end

	self:EmitSound(self.Primary.Sound, 120)
	local ef = EffectData()
	ef:SetEntity(self)
	ef:SetAttachment(1)
	util.Effect("MuzzleFlash", ef)

	self:TakePrimaryAmmo(1)
	if self:GetOwner():GetEnemy() == nil then return end
	if not self:GetOwner():GetEnemy() then return end
	local att = self:GetAttachment(1)
	if not att then att = self:GetOwner() end
	local posTgt = self:GetOwner():GetEnemy():LocalToWorld(self:GetOwner():GetEnemy():OBBCenter())
	local angAcc = (posTgt - att.Pos):Angle()
	local bullet = {}
	bullet.Num = self.Primary.NumberofShots --The number of shots fired
	bullet.Src = self:GetOwner():GetShootPos() --Gets where the bullet comes from
	bullet.Dir = Angle(math.ApproachAngle(att.Ang.p, angAcc.p, 45), math.ApproachAngle(att.Ang.y, angAcc.y, 35), 0):Forward()
	bullet.Tracer = 0

	local ac = (4 - self:GetOwner():GetCurrentWeaponProficiency()) * 0.1 + math.Rand(0.01, 0.08)
	bullet.Spread = Vector(ac, ac, ac)

	bullet.Damage = self.Primary.Damage
	bullet.AmmoType = self.Primary.Ammo
	self:GetOwner():FireBullets(bullet)
end


function SWEP:NpcReload()
	--if not self:IsValid() or not self:GetOwner():IsValid() then return end
	--self:SetNextPrimaryFire(CurTime() + 2)
	self:GetOwner():SetSchedule(SCHED_COWER)
	self:GetOwner():ResetSequence( "pose_standing_01" )
	--self:GetOwner():SetSchedule(SCHED_RELOAD)
	self:DefaultReload(ACT_RELOAD_PISTOL_LOW)
	self:SetClip1(self.Primary.ClipSize)
end

function SWEP:NPCShoot_Primary(ShootPos, ShootDir)
	if (not self:IsValid()) or (not self:GetOwner():IsValid()) then return end
	self:PrimaryAttack()
end

function SWEP:GetNPCBurstSettings()
	return 2, 3, self.Primary.Delay
end

if SERVER then
	AccessorFunc(SWEP, "fNPCMinBurst", "NPCMinBurst")
	AccessorFunc(SWEP, "fNPCMaxBurst", "NPCMaxBurst")
	AccessorFunc(SWEP, "fNPCFireRate", "NPCFireRate")
	AccessorFunc(SWEP, "fNPCMinRestTime", "NPCMinRest")
	AccessorFunc(SWEP, "fNPCMaxRestTime", "NPCMaxRest")

	function SWEP:OnDrop()
		self:Remove()
	end
end