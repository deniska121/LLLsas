-- "addons\\a_config_gmodla\\lua\\city_extentions\\sh_materials.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
SW = SW or {}

local replace_mats = {
	["tools/toolsnodraw"] = "phoenix_storms/trains/track_plateside",
	["unioncity/misc/pd_wallsticker"] = "replace/pdsticker2",
	["unioncity2/decals/courtstuff"] = "replace/courtstuff",
	["models/uc2/propper/gas_station_logo"] = "replace/gas_station_logo",
	["models/uc2/propper/gas_station_prices"] = "replace/gas_station_prices",
	["models/uc2/props_rooftop/billboard_a"] = "replace/billboard_a",
	["models/uc2/props_rooftop/billboard_b"] = "replace/billboard_b",
	["models/uc2/props_rooftop/billboard_e"] = "replace/billboard_e",
	["models/uc2/props_rooftop/billboard_c"] = "replace/billboard_c",
	["models/uc2/props_rooftop/billboard_h"] = "replace/billboard_h",
	["models/uc2/props_rooftop/billboard_g"] = "replace/billboard_g",
	["models/uc2/props_rooftop/billboard_f"] = "replace/billboard_f",
	["models/uc2/props_fastfood/kitchen03"] = "replace/kitchen03",
	["models/uc2/props_stores/magazinerack"] = "gbskins/magazinerack",
	["models/uc2/propper/votebane"] = "replace/votebane",
	["models/uc2/propper/standingbill02"] = "replace/standingbill02",
	["models/props/commercial/cigarettedisplay"] = "replace/cigarettedisplay",
	["models/noirrebuild/signimpound/impoundsign"] = "replace/impoundsign",
	["models/props_stores/candyboxes"] = "replace/candyboxes",
	--fall
	-- ["models/uc2/props_foliage/distant_trees"] = "replace/snow/distant_trees",
	-- ["models/uc2/props_skybox/distant_trees"] = "replace/snow/distant_trees",
	--["models/uc2/props_unioncity/ground_detail"] = "replace/snow/ground_detail",
	--["models/domitibingen/italiancypressneedles_rt_1"] = "replace/snow/italiancypressneedles_rt_1",
}

local second_mats = {
	["unioncity2/floors/parkdirttograss"] = "nature/forest_dirt_02",
}

local color_mats = {}

local mod_mat = {
	["unioncity2/floors/checkered_floor"] = function(mat)
		mat = Material(mat)
		mat:SetVector("$reflectivity", Vector(1,1,1))
	end
}

SW.Leaves = SW.Leaves or {}
SW.Sound = nil
SW.VolumeMultiplier = 1
SW.SoundVolume = 0
SW.SkyboxVisible = false
SW.IsOutsideFrame = false
SW.Frame = 0

if CLIENT then
	local CubemapMats
	local rot = 0

	local function ChangeSkyTexture(skybox)
		CubemapMats = {Material(skybox .. "ft"), Material(skybox .. "rt"), Material(skybox .. "bk"), Material(skybox .. "lf"), Material(skybox .. "up"), Material(skybox .. "dn"),}

		local rt = GetRenderTarget("skybox_foggation_renderation", ScrW(), ScrH())
		render.PushRenderTarget(rt)
		render.Clear(0, 0, 0, 0)
		cam.Start2D()
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(CubemapMats[1])
		surface.DrawTexturedRect(0, 0, ScrW() * 0.25, ScrH())
		surface.SetMaterial(CubemapMats[2])
		surface.DrawTexturedRect(ScrW() * 0.25, 0, ScrW() * 0.25, ScrH())
		surface.SetMaterial(CubemapMats[3])
		surface.DrawTexturedRect(ScrW() * 0.5, 0, ScrW() * 0.25, ScrH())
		surface.SetMaterial(CubemapMats[4])
		surface.DrawTexturedRect(ScrW() * 0.75, 0, ScrW() * 0.25, ScrH())
		cam.End2D()
		render.CapturePixels()
		render.PopRenderTarget()
	end

	local sblist = {
		{"skybox/sky_fema_hdr", -130},
		{"skybox/sky_benzyn_hdr", 0},
		{"skybox/sky_day03_04_hdr", 45},
		{"skybox/sky_day01_01_hdr", -60},
		{"skybox/sky_day02_06_hdr", 160},
		{"skybox/sky_day02_07_hdr", 210},
	}

	local size = 16
	local matr = Matrix()
	local sky = 1
	local rainfx = false

	local function RaplaceTextures()
		for k, v in pairs(mod_mat) do v(k) end

		for k, v in pairs(replace_mats) do
			local mat = Material(k)
			mat:SetTexture("$basetexture", v)

			if second_mats[k] then
				mat:SetTexture("$basetexture2", second_mats[k] or "")
			end

			if color_mats[k] then
				mat:SetVector("$color2", color_mats[k])
			end
		end

		sky = GetGlobalVar("Sky_Box", 1)

		if sky > 0 and sblist[sky] then
			ChangeSkyTexture(sblist[sky][1])
			rot = sblist[sky][2]
		end
	end

	if GAMEMODE then
		RaplaceTextures()
	end

	hook.Add("InitPostEntity", "second_mats_replacer", function()
		RaplaceTextures()

		timer.Simple(10, function()
			RaplaceTextures()
		end)

		timer.Simple(60, function()
			RaplaceTextures()
		end)
	end)

	hook.Add("PostDraw2DSkyBox", "SkyRandomizer", function()
		if not CubemapMats then return end
		matr:SetAngles(Angle(0, rot, 0))
		matr:SetTranslation(EyePos())
		cam.Start3D(EyePos(), RenderAngles())
		cam.PushModelMatrix(matr)
		render.OverrideDepthEnable(false, true)
		render.SetMaterial(CubemapMats[1])
		render.DrawQuadEasy(Vector(1, 0, 0) * size, Vector(-1, 0, 0), size * 2, size * 2, color_white, 180)
		render.SetMaterial(CubemapMats[4])
		render.DrawQuadEasy(Vector(0, -1, 0) * size, Vector(0, 1, 0), size * 2, size * 2, color_white, 180)
		render.SetMaterial(CubemapMats[3])
		render.DrawQuadEasy(Vector(-1, 0, 0) * size, Vector(1, 0, 0), size * 2, size * 2, color_white, 180)
		render.SetMaterial(CubemapMats[2])
		render.DrawQuadEasy(Vector(0, 1, 0) * size, Vector(0, -1, 0), size * 2, size * 2, color_white, 180)
		render.SetMaterial(CubemapMats[5])
		render.DrawQuadEasy(Vector(0, 0, 1) * size, Vector(0, 0, -1), size * 2, size * 2, color_white, 270)
		render.SetMaterial(CubemapMats[6])
		render.DrawQuadEasy(Vector(0, 0, -1) * size, Vector(0, 0, 1), size * 2, size * 2, color_white, 90)
		render.OverrideDepthEnable(false, false)
		cam.PopModelMatrix()
		cam.End3D()
	end)

	-- local tab = {
	-- 	["$pp_colour_addr"] = 0,
	-- 	["$pp_colour_addg"] = 0,
	-- 	["$pp_colour_addb"] = 0,
	-- 	["$pp_colour_brightness"] = -0.07,
	-- 	["$pp_colour_contrast"] = 1,
	-- 	["$pp_colour_colour"] = 1,
	-- 	["$pp_colour_mulr"] = 0,
	-- 	["$pp_colour_mulg"] = 0,
	-- 	["$pp_colour_mulb"] = 0
	-- }

	local snow_sky = {
		-- [1] = true,
		-- [8] = true,
	}

	local skyeffects = {
		-- [3] = function()
		-- 	DrawBloom(0, 0.3, 3.6, 1.8, 1, 1.32, 1, 0.5, 0.01)
		-- end,
		-- [4] = function()
		-- 	DrawBloom(0, 0.12, 5, 11.28, 2, 3.27, 1, 1, 1)
		-- end,
		-- [5] = function()
		-- 	DrawBloom(0, 0.12, 5, 11.28, 2, 3.27, 1, 1, 1)
		-- end,
		-- [6] = function()
		-- 	DrawBloom(0.28, 0.75, 5, 11.28, 1, 3.17, 0.05, 0.07, 0.13)
		-- end,
		-- [7] = function()
		-- 	if not DarkRP.IsOutside(EyePos()) and tab["$pp_colour_brightness"] < 0 then
		-- 		tab["$pp_colour_brightness"] = Lerp(FrameTime() * 2, tab["$pp_colour_brightness"], 0)
		-- 	elseif tab["$pp_colour_brightness"] > -0.07 then
		-- 		tab["$pp_colour_brightness"] = Lerp(FrameTime() * 2, tab["$pp_colour_brightness"], -0.07)
		-- 	end

		-- 	DrawColorModify(tab)
		-- 	DrawBloom(0.34, 0.12, 5, 5, 14, 1, 1, 1, 1)
		-- end,
		[1] = function()
			DrawBloom(0, 0.12, 5, 11.28, 2, 3.27, 1, 1, 1)
		end,
		[2] = function()
			DrawBloom(0, 0.17, 3.6, 1.8, 1, 1.32, 0.9, 0.57, 0.01)
		end,
	}

	hook.Add("RenderScreenspaceEffects", "SkyRandomizer", function()
		if skyeffects[sky] then
			skyeffects[sky]()
		end
	end)

	CreateClientConVar("fall_rain", "1", true, false)

	CreateClientConVar("fall_maxleaves", "3", true, false)
	CreateClientConVar("fall_timer", "10", true, false)

	timer.Remove("PlayerBreath", 5, 0, function()
		for _,ent in ipairs(player.GetAll()) do
			if not IsValid(ent) or not DarkRP.InRange(ent, LocalPlayer(), 300) then return end

			timer.Simple(math.Rand(0, 2), function()
				if not IsValid(ent) or not ent:Alive() or ent:getDarkRPVar("unconscious") or ent:WaterLevel() > 0 or not DarkRP.IsOutside(ent:GetPos()) then return end
				if ent:GetMoveType() == MOVETYPE_NOCLIP or IsValid(ent.pk_pill_ent) then return end

				local i = ent:LookupAttachment("mouth")
				if not i then return end
				local att = ent:GetAttachment(i)
				if not att then return end
				local pos, ang = att.Pos, att.Ang

				if not ent.hookah_ef then
					ent.hookah_ef = ParticleEmitter(ent:GetPos())
				end

				if ent.hookah_ef then
					local particle = ent.hookah_ef:Add("particle/particle_smokegrenade", pos)
					particle:SetVelocity(ang:Forward() * 5)
					particle:SetDieTime(math.Rand(2,3))
					particle:SetStartAlpha(77)
					particle:SetEndAlpha(0)
					particle:SetColor(255, 255, 255)
					particle:SetStartSize(math.random(1,2))
					particle:SetEndSize(math.random(3,6))
					particle:SetRoll(math.Rand(0, 360))
					particle:SetAirResistance(90)
					particle:SetGravity(VectorRand() * 2 + ang:Forward() * math.random(3,5))
				end
			end)
		end
	end)

	timer.Remove("SW.Snow", 1, 0, function()
		if not snow_sky[sky] then return end
		if not rainfx then rainfx = true end

		if (LocalPlayer():GetViewEntity() == LocalPlayer()) then
			local s = hook.Call("CalcView", GAMEMODE, LocalPlayer(), LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), 75)
			SW.ViewPos = s.origin
			SW.ViewAng = s.angles
		else
			SW.ViewPos = LocalPlayer():GetViewEntity():GetPos()
			SW.ViewAng = LocalPlayer():GetViewEntity():GetAngles()
		end

		if (not SW.ViewPos or not SW.ViewAng) then
			SW.ViewPos = LocalPlayer():EyePos()
			SW.ViewAng = LocalPlayer():EyeAngles()
		end

		SW.Emitter2D = ParticleEmitter(SW.ViewPos)
		SW.Emitter3D = ParticleEmitter(SW.ViewPos, true)

		local drop = EffectData()
		drop:SetOrigin(SW.ViewPos)
		util.Effect("sw_snow", drop)
	end)

	local fog = 155

	hook.Add("SetupWorldFog", "SW.SetupWorldFog", function()
		if not rainfx or (CURRENT_TERRITORY and CURRENT_TERRITORY.nozone) then return end
		render.FogMode(MATERIAL_FOG_LINEAR)
		-- render.FogStart(100)
		-- render.FogEnd(5250)
		render.FogStart(0)
		render.FogEnd(3250)
		render.FogMaxDensity(.3)
		render.FogColor(fog, fog, fog)
		return true
	end)

	hook.Add("SetupSkyboxFog", "SW.SetupSkyboxFog", function()
		if not rainfx or (CURRENT_TERRITORY and CURRENT_TERRITORY.nozone) then return end
		render.FogMode(MATERIAL_FOG_LINEAR)
		render.FogStart(0)
		--render.FogEnd(300)
		render.FogEnd(1)
		render.FogMaxDensity(.3)
		render.FogColor(fog, fog, fog)
		return true
	end)

end