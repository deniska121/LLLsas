-- "addons\\a_config_gmodla\\lua\\clprops\\club.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local scene = {
	{
		pos = Vector(-7742.125, 6419.375, 256.46881103516),
		mdl = "models/unioncity3/props_misc/vinyl_crates.mdl",
		ang = Angle(-0.010999999940395, -2.867399930954, -0.082400001585484),
		smt = {},
		bgr = {
			[0] = 0,
		},
	},
}

table.Add(client_list, scene)