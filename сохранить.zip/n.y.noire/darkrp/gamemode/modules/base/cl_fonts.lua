-- "gamemodes\\darkrp\\gamemode\\modules\\base\\cl_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local surface_CreateFont = surface.CreateFont
local SW = ScrW()

surface_CreateFont("InfoH2", {
	font = "Arial",
	size = 32,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Noire.Big", {
	font = "Snowstorm Kraft",
	size = 72,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Noire.32", {
	font = "Snowstorm Kraft",
	size = 32,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("GmodLA.Hand", {
	font = "MADE GoodTime Script",
	size = SW / 40,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("GmodLA.HandSM", {
	font = "MADE GoodTime Script",
	size = SW / 50,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("MoneyF", {
	font = "Loaded",
	size = 28,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Moster.24", {
	font = "DS Moster",
	size = 24,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Moster.28", {
	font = "DS Moster",
	size = 28,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Moster.36", {
	font = "DS Moster",
	size = 36,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("LogoMain", {
	font = "Five",
	size = 32,
	weight = 100,
	antialias = true,
	extended = true,
})

surface_CreateFont("Banff.H1", {
	font = "Banff",
	size = 55,
	weight = 700,
	antialias = true,
	extended = true,
})

surface_CreateFont("SlideR.H1", {
	font = "SlideR",
	size = 32,
	weight = 700,
	antialias = true,
	extended = true,
})

surface_CreateFont("Tahoma.B", {
	font = "Tahoma",
	size = 18,
	weight = 300,
	antialias = true,
	extended = true,
})

surface_CreateFont("Tahoma.16", {
	font = "Tahoma",
	size = 16,
	weight = 300,
	antialias = true,
	extended = true,
})

surface_CreateFont("Pixel.M", {
	font = "Pixelzone",
	size = 90,
	weight = 300,
	antialias = true,
	extended = true,
})

surface_CreateFont("Pixel.S", {
	font = "Pixelzone",
	size = 55,
	weight = 300,
	antialias = true,
	extended = true,
})

surface_CreateFont("Bravo.Main", {
	font = "BravoSC",
	size = 32,
	weight = 300,
	antialias = true,
	extended = true,
})