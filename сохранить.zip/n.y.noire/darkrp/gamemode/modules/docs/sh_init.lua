-- "gamemodes\\darkrp\\gamemode\\modules\\docs\\sh_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
DarkRP.News = {}