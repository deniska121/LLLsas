-- "gamemodes\\darkrp\\entities\\entities\\mailbox\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Почта"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.ShowOnHud = true