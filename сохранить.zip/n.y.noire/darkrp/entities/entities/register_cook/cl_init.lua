-- "gamemodes\\darkrp\\entities\\entities\\register_cook\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

ENT.colors = {
	Color(233,158,19),
	Color(216,89,4),
	Color(231,128,9),
	Color(235,151,55),
}

function ENT:Think()
	self:NextThink(CurTime())

	return true
end