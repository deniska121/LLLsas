-- "gamemodes\\darkrp\\entities\\entities\\register_screen\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Касса"
ENT.Author = "Mactavish"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.ShowOnHud = true

function ENT:SetupDataTables()
	self:NetworkVar("Entity",0,"owning_ent")
	self:NetworkVar("Entity",1,"base_ent")
end