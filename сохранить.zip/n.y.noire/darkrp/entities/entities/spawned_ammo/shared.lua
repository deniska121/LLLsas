-- "gamemodes\\darkrp\\entities\\entities\\spawned_ammo\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Ammo"
ENT.Author = "Mactavish"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "owning_ent")
	self:NetworkVar("String",0,"eclass")
	self:NetworkVar("Int",0,"Ammo")
end