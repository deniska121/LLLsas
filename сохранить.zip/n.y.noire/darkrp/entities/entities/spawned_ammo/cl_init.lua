-- "gamemodes\\darkrp\\entities\\entities\\spawned_ammo\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")