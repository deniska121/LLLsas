-- "gamemodes\\darkrp\\entities\\entities\\register_gun\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

ENT.colors = {
	Color(19,119,233),
	Color(20,102,196),
	Color(0,62,121),
	Color(55,127,235),
}

function ENT:Think()
	self:NextThink(CurTime())

	return true
end