-- "gamemodes\\darkrp\\entities\\entities\\spawned_shipment\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Shipment"
ENT.Author = "philxyz"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity", 0, "owning_ent")
	self:NetworkVar("Bool",0,"Deploy")
	self:NetworkVar("String",0,"DeployModel")
	self:NetworkVar("String",1,"eclass")
end