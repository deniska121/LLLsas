-- "gamemodes\\darkrp\\entities\\entities\\recycle_bin\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Draw()
	self:DrawModel()

end