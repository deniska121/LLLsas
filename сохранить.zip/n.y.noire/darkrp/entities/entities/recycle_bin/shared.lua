-- "gamemodes\\darkrp\\entities\\entities\\recycle_bin\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Мусорка"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Float",0,"Space")
	self:NetworkVar("String",0,"StorageName")
end