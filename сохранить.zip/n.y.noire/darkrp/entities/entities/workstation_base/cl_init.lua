-- "gamemodes\\darkrp\\entities\\entities\\workstation_base\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Think()
	local CT = CurTime()

	if self:GetPos():DistToSqr(LocalPlayer():GetPos()) > 500000 then
		self:PauseSounds()
		return
	end

	if self:GetCrafting() and not self:GetStopCraft() then
		if not self.nexteffect or self.nexteffect < CT then
			self.nexteffect = CT + 0.2
			if not IsValid(self.sound) then
				self:StartCraftingSound()
			else
				self:ContinueSounds()
				self.sound:SetPos(self:GetPos())
			end
		end
	else
		self:StopCraftingSound()
	end

	self:NextThink(CT)
	return true
end

function ENT:StopSounds()
	if IsValid(self.sound) then
		self.sound:Stop()
		self.sound = nil
	end
end

function ENT:PauseSounds()
	if IsValid(self.sound) and self.sound:GetState() ~= 2 then
		self.sound:Pause()
	end
end

function ENT:ContinueSounds()
	if IsValid(self.sound) and (self.sound:GetState() == 2 or self.sound:GetState() == 0) then
		self.sound:Play()
	end
end

function ENT:StopCraftingSound()
	if IsValid(self.sound) then
		self.sound:Stop()
		self.sound = nil
	end
end

function ENT:StartCraftingSound()
	local item = self.BluePrints[self:GetCraftingItem()]
	if not item or not item.sound then return end
	sound.PlayFile( "sound/" .. item.sound, "3d noplay noblock", function( station, errCode, errStr )
		if IsValid( station ) then
			station:EnableLooping(true)
			station:SetPos(self:GetPos())
			station:Play()
			station:SetVolume(0.5)
			station:Set3DCone( 360, 360, 0 )
			self.sound = station
		end
	end)
end

function ENT:ClearModels()
	if not self.models then return end
	for k,v in pairs(self.models) do
		if not IsValid(v) then continue end
		v:Remove()
	end
end

function ENT:OnRemove()
	self:StopSounds()
	self:ClearModels()
end