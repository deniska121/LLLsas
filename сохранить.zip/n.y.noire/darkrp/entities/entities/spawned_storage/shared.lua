-- "gamemodes\\darkrp\\entities\\entities\\spawned_storage\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Коробка"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity",0,"owning_ent")
	self:NetworkVar("Float",0,"Space")
	self:NetworkVar("String",0,"StorageName")
end