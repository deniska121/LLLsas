-- "gamemodes\\darkrp\\entities\\entities\\spawned_atm\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "ATM"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false