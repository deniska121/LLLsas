-- "gamemodes\\darkrp\\entities\\entities\\workstation_guns\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")