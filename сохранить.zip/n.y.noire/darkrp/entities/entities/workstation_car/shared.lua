-- "gamemodes\\darkrp\\entities\\entities\\workstation_car\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Подъемный кран"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.CanPack = true
ENT.ShowOnHud = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity",0,"owning_ent")
	self:NetworkVar("Entity",1,"screen")
end

ENT.CarPartMult = {
	parts_hull   = 0.002,
	parts_engine = 0.0035,
	parts_glass  = 0.0008,
}