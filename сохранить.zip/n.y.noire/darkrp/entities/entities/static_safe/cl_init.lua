-- "gamemodes\\darkrp\\entities\\entities\\static_safe\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

function ENT:Draw()
	self:DrawModel()
end

function ENT:Think()
	self:NextThink(CurTime())

	return true
end