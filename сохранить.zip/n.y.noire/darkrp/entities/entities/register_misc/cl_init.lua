-- "gamemodes\\darkrp\\entities\\entities\\register_misc\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
include("shared.lua")

ENT.colors = {
	Color(145,177,59),
	Color(71,112,33),
	Color(155,189,7),
	Color(150,185,84),
}

function ENT:Think()
	self:NextThink(CurTime())

	return true
end