-- "gamemodes\\darkrp\\entities\\entities\\register_misc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Касса (разное)"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.CanPack = true
ENT.ShowOnHud = true

function ENT:SetupDataTables()
	self:NetworkVar("Entity",0,"owning_ent")
	self:NetworkVar("Entity",1,"screen")
	self:NetworkVar("Float",0,"CustomPrice")
	self:NetworkVar("Float",1,"Space")
	self:NetworkVar("String",0,"StorageName")
end

ENT.SellTypes = {
	[INV_FOOD] = true,
	[INV_JUNK] = true,
	[INV_ENTITY] = true,
}