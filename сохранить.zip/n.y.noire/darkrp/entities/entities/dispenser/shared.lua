-- "gamemodes\\darkrp\\entities\\entities\\dispenser\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Раздатчик"
ENT.Author = "Mactavish"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.AutomaticFrameAdvance = true

function ENT:Think()
	self:NextThink(CurTime())

	return true
end