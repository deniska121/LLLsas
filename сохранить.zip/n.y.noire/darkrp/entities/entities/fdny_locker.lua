-- "gamemodes\\darkrp\\entities\\entities\\fdny_locker.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Шкафчик"
ENT.Author = "Mactavish"
ENT.Spawnable = true

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/props_train_station/clothes_locker_01.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:DrawShadow(false)
		local phys = self:GetPhysicsObject()
		phys:Wake()
	end

	function ENT:Use(ply)
		if not IsValid(ply) or ply:Team() ~= 14 or not DarkRP.IsHoldingKeys(ply) then return end
		if DarkRP.UseDelay(ply, 4) then return end

		self:EmitSound("doors/door_metal_thin_open1.wav")

		ply:SetDarkRPVar("rice_anim_n", "pickup")
		ply:SetDarkRPVar("rice_anim", CurTime() + 3)
		DarkRP.UIEffect(nil, "plyAnimSetCycle", {ply:UserID()})
		timer.Simple(1.3, function()
			if not IsValid(ply) or ply:Team() ~= 14 then return end

			if (ply:getDarkRPVar("armorVest") and ply:getDarkRPVar("armorVest") == 3)  then
				ply:EmitSound("viper/weapons/akilo47/wfoly_ar_akilo47_reload_empty_twist.ogg")
				ply:StripWeapon("fire_extinguisher")
				ply:StripWeapon("weapon_axe")
				MCR.SetSCBA(ply, false)
			else
				ply:EmitSound("viper/weapons/akilo47/wfoly_ar_akilo47_reload_empty_twist.ogg")
				MCR.SetSCBA(ply, true)
				local wep = ply:Give("fire_extinguisher")
				wep.GivenByTeam = true

				local rank = MRS.GetPlyRank(ply, "FDNY")

				if rank > 3 then
					local w = ply:Give("weapon_axe")
					w.GivenByTeam = true
				end
			end

			ply:SetDarkRPVar("rice_anim_n", "")
			DarkRP.UIEffect(nil, "anim_keys", {type = "usekeys", ply = ply:UserID()})
		end)
	end
end