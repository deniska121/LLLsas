-- "gamemodes\\darkrp\\entities\\entities\\spawned_food\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Еда"
ENT.Author = "Mactavish"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Entity",1,"owning_ent")
	self:NetworkVar("String",1,"eclass")
	self:NetworkVar("Int",0,"uses")
end