-- "gamemodes\\darkrp\\entities\\weapons\\med_kit.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
AddCSLuaFile()
SWEP.PrintName = "Аптечка"
SWEP.Author = "Mactavish"
SWEP.Purpose = "Heal people with your primary attack, or yourself with the secondary."
SWEP.Slot = 4
SWEP.SlotPos = 3
SWEP.Spawnable = true
SWEP.ViewModel = Model("models/weapons/c_medkit.mdl")
SWEP.WorldModel = Model("models/w_models/weapons/w_eq_medkit.mdl")
SWEP.ViewModelFOV = 54
SWEP.UseHands = true
SWEP.DrawCrosshair = false
SWEP.Primary.ClipSize = 50
SWEP.Primary.DefaultClip = 50
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"
SWEP.MaxAmmo = 50 -- Maxumum ammo

SWEP.ShowWorldModel = false
SWEP.ViewModelBoneMods = {
	["medkit_bone"] = { scale = Vector(0.009, 0.009, 0.009), pos = Vector(0, 0, 0), angle = Angle(0, 0, 0) }
}
SWEP.VElements = {
	["model"] = { type = "Model", model = "models/w_models/weapons/w_eq_medkit.mdl", bone = "medkit_bone", rel = "", pos = Vector(-4.921, 0.312, -1.691), angle = Angle(-86.319, 0, 0), size = Vector(1, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/w_models/eq_medkit/w_eq_medkit2", skin = 0, bodygroup = {} }
}
SWEP.WElements = {
	["model"] = { type = "Model", model = "models/w_models/weapons/w_eq_medkit.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(3.295, 1.128, 0), angle = Angle(4.052, 14.89, 100.022), size = Vector(0.656, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "models/w_models/eq_medkit/w_eq_medkit2", skin = 0, bodygroup = {} }
}

function SWEP:Initialize()
	self:SetHoldType("slam")

	if CLIENT then
		self.VElements = table.FullCopy(self.VElements)
		self.WElements = table.FullCopy(self.WElements)
		self.ViewModelBoneMods = table.FullCopy(self.ViewModelBoneMods)
		self:CreateModels(self.VElements)
		self:CreateModels(self.WElements)

		if IsValid(self:GetOwner()) then
			local vm = self:GetOwner():GetViewModel()

			if IsValid(vm) then
				self:ResetBonePositions(vm)

				if (self.ShowViewModel == nil or self.ShowViewModel) then
					vm:SetColor(color_white)
				else
					vm:SetColor(Color(255, 255, 255, 1))
					vm:SetMaterial("null")
				end
			end
		end

		return
	end

	timer.Create("medkit_ammo" .. self:EntIndex(), 5, 0, function()
		if (self:Clip1() < self.MaxAmmo) then
			self:SetClip1(math.min(self:Clip1() + 1, self.MaxAmmo))
		end
	end)
end

function SWEP:PrimaryAttack()
	if (CLIENT) then
		MES.OpenMenuCheck()
	end

	self:SetNextPrimaryFire(CurTime() + 1)
end

function SWEP:SecondaryAttack()
	if (CLIENT) then
		MES.OpenMenuApply()
	end

	self:SetNextSecondaryFire(CurTime() + 1)
end

function SWEP:OnRemove()
	timer.Stop("medkit_ammo" .. self:EntIndex())
	timer.Stop("weapon_idle" .. self:EntIndex())
	self:Holster()
end

function SWEP:Holster()
	if CLIENT and IsValid(self:GetOwner()) then
		local vm = self:GetOwner():GetViewModel()

		if IsValid(vm) then
			self:ResetBonePositions(vm)
		end
	end

	return true
end

function SWEP:CustomAmmoDisplay()
	self.AmmoDisplay = self.AmmoDisplay or {}
	self.AmmoDisplay.Draw = true
	self.AmmoDisplay.PrimaryClip = self:Clip1()

	return self.AmmoDisplay
end

if SERVER then return end


local clrs = {
	m = Color(255, 255, 255, 200),
	s = Color(127, 127, 127, 150),
	d = Color(0, 0, 0, 20),
	r = Color(255, 0, 0),
}

function SWEP:DrawHUD()
	if self:GetOwner():getDarkRPVar("unconscious") then return end
	local x, y = ScrW() / 2, ScrH() * 0.8
	local sp = draw.SimpleTextOutlined("Осмотреть человека", "MSDFont.20", x, y + 3, clrs.m, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, clrs.d)
	MSD.DrawKey(x - sp / 2 - 55, y, "ЛКМ", 155)
	sp = draw.SimpleTextOutlined("Применить аптечку", "MSDFont.20", x, y + 33, clrs.m, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, clrs.d)
	MSD.DrawKey(x - sp / 2 - 55, y + 30, "ПКМ", 155)
end

SWEP.vRenderOrder = nil

function SWEP:ViewModelDrawn()
	if self:GetOwner():getDarkRPVar("unconscious") or self:GetOwner():getDarkRPVar("HandCuffed") then return end
	local vm = self:GetOwner():GetViewModel()
	if not IsValid(vm) then return end
	if (not self.VElements) then return end
	self:UpdateBonePositions(vm)

	if (not self.vRenderOrder) then
		self.vRenderOrder = {}

		for k, v in pairs(self.VElements) do
			if (v.type == "Model") then
				table.insert(self.vRenderOrder, 1, k)
			elseif (v.type == "Sprite" or v.type == "Quad") then
				table.insert(self.vRenderOrder, k)
			end
		end
	end

	for k, name in ipairs(self.vRenderOrder) do
		local v = self.VElements[name]

		if (not v) then
			self.vRenderOrder = nil
			break
		end

		if (v.hide) then continue end
		local model = v.modelEnt
		local sprite = v.spriteMaterial
		if (not v.bone) then continue end
		local pos, ang = self:GetBoneOrientation(self.VElements, v, vm)
		if (not pos) then continue end

		if (v.type == "Model" and IsValid(model)) then
			model:SetPos(pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z)
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			model:SetAngles(ang)
			--model:SetModelScale(v.size)
			local matrix = Matrix()
			matrix:Scale(v.size)
			model:EnableMatrix("RenderMultiply", matrix)

			if (v.material == "") then
				model:SetMaterial("")
			elseif (model:GetMaterial() ~= v.material) then
				model:SetMaterial(v.material)
			end

			if (v.skin and v.skin ~= model:GetSkin()) then
				model:SetSkin(v.skin)
			end

			if (v.bodygroup) then
				for i, o in pairs(v.bodygroup) do
					if (model:GetBodygroup(i) ~= o) then
						model:SetBodygroup(i, o)
					end
				end
			end

			if (v.surpresslightning) then
				render.SuppressEngineLighting(true)
			end

			render.SetColorModulation(v.color.r / 255, v.color.g / 255, v.color.b / 255)
			render.SetBlend(v.color.a / 255)
			model:DrawModel()
			render.SetBlend(1)
			render.SetColorModulation(1, 1, 1)

			if (v.surpresslightning) then
				render.SuppressEngineLighting(false)
			end
		elseif (v.type == "Sprite" and sprite) then
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			render.SetMaterial(sprite)
			render.DrawSprite(drawpos, v.size.x, v.size.y, v.color)
		elseif (v.type == "Quad" and v.draw_func) then
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			cam.Start3D2D(drawpos, ang, v.size)
			v.draw_func(self)
			cam.End3D2D()
		end
	end
end

SWEP.wRenderOrder = nil
SWEP.ShowWorldModel = false

function SWEP:DrawWorldModel()
	if self:GetOwner():getDarkRPVar("unconscious") or self:GetOwner():getDarkRPVar("HandCuffed") then return end
	if (not self.WElements) then return end

	if (not self.wRenderOrder) then
		self.wRenderOrder = {}

		for k, v in pairs(self.WElements) do
			if (v.type == "Model") then
				table.insert(self.wRenderOrder, 1, k)
			elseif (v.type == "Sprite" or v.type == "Quad") then
				table.insert(self.wRenderOrder, k)
			end
		end
	end

	if (IsValid(self:GetOwner())) then
		bone_ent = self:GetOwner()
	else
		-- when the weapon is dropped
		bone_ent = self
	end

	for k, name in pairs(self.wRenderOrder) do
		local v = self.WElements[name]

		if (not v) then
			self.wRenderOrder = nil
			break
		end

		if (v.hide) then continue end
		local pos, ang

		if (v.bone) then
			pos, ang = self:GetBoneOrientation(self.WElements, v, bone_ent)
		else
			pos, ang = self:GetBoneOrientation(self.WElements, v, bone_ent, "ValveBiped.Bip01_R_Hand")
		end

		if (not pos) then continue end
		local model = v.modelEnt
		local sprite = v.spriteMaterial

		if (v.type == "Model" and IsValid(model)) then
			model:SetPos(pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z)
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			model:SetAngles(ang)
			--model:SetModelScale(v.size)
			local matrix = Matrix()
			matrix:Scale(v.size)
			model:EnableMatrix("RenderMultiply", matrix)

			if (v.material == "") then
				model:SetMaterial("")
			elseif (model:GetMaterial() ~= v.material) then
				model:SetMaterial(v.material)
			end

			if (v.skin and v.skin ~= model:GetSkin()) then
				model:SetSkin(v.skin)
			end

			if (v.bodygroup) then
				for i, o in pairs(v.bodygroup) do
					if (model:GetBodygroup(i) ~= o) then
						model:SetBodygroup(i, o)
					end
				end
			end

			if (v.surpresslightning) then
				render.SuppressEngineLighting(true)
			end

			render.SetColorModulation(v.color.r / 255, v.color.g / 255, v.color.b / 255)
			render.SetBlend(v.color.a / 255)
			model:DrawModel()
			render.SetBlend(1)
			render.SetColorModulation(1, 1, 1)

			if (v.surpresslightning) then
				render.SuppressEngineLighting(false)
			end
		elseif (v.type == "Sprite" and sprite) then
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			render.SetMaterial(sprite)
			render.DrawSprite(drawpos, v.size.x, v.size.y, v.color)
		elseif (v.type == "Quad" and v.draw_func) then
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			cam.Start3D2D(drawpos, ang, v.size)
			v.draw_func(self)
			cam.End3D2D()
		end
	end
end

function SWEP:GetBoneOrientation(basetab, tab, ent, bone_override)
	local bone, pos, ang

	if (tab.rel and tab.rel ~= "") then
		local v = basetab[tab.rel]
		if (not v) then return end
		-- Technically, if there exists an element with the same name as a bone
		-- you can get in an infinite loop. Let's just hope nobody's that stupid.
		pos, ang = self:GetBoneOrientation(basetab, v, ent)
		if (not pos) then return end
		pos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
		ang:RotateAroundAxis(ang:Up(), v.angle.y)
		ang:RotateAroundAxis(ang:Right(), v.angle.p)
		ang:RotateAroundAxis(ang:Forward(), v.angle.r)
	else
		bone = ent:LookupBone(bone_override or tab.bone)
		if (not bone) then return end
		pos, ang = Vector(0, 0, 0), Angle(0, 0, 0)
		local m = ent:GetBoneMatrix(bone)

		if (m) then
			pos, ang = m:GetTranslation(), m:GetAngles()
		end

		if (IsValid(self:GetOwner()) and self:GetOwner():IsPlayer() and ent == self:GetOwner():GetViewModel() and self.ViewModelFlip) then
			ang.r = -ang.r -- Fixes mirrored models
		end
	end

	return pos, ang
end

function SWEP:CreateModels(tab)
	if (not tab) then return end

	-- Create the clientside models here because Garry says we can't do it in the render hook
	for k, v in pairs(tab) do
		if (v.type == "Model" and v.model and v.model ~= "" and (not IsValid(v.modelEnt) or v.createdModel ~= v.model) and string.find(v.model, ".mdl") and file.Exists(v.model, "GAME")) then
			v.modelEnt = ClientsideModel(v.model, RENDERGROUP_OTHER)

			if (IsValid(v.modelEnt)) then
				v.modelEnt:SetPos(self:GetPos())
				v.modelEnt:SetAngles(self:GetAngles())
				v.modelEnt:SetParent(self)
				v.modelEnt:SetNoDraw(true)
				v.createdModel = v.model
			else
				v.modelEnt = nil
			end
		elseif (v.type == "Sprite" and v.sprite and v.sprite ~= "" and (not v.spriteMaterial or v.createdSprite ~= v.sprite) and file.Exists("materials/" .. v.sprite .. ".vmt", "GAME")) then
			local name = v.sprite .. "-"

			local params = {
				["$basetexture"] = v.sprite
			}

			-- make sure we create a unique name based on the selected options
			local tocheck = {"nocull", "additive", "vertexalpha", "vertexcolor", "ignorez"}

			for i, j in pairs(tocheck) do
				if (v[j]) then
					params["$" .. j] = 1
					name = name .. "1"
				else
					name = name .. "0"
				end
			end

			v.createdSprite = v.sprite
			v.spriteMaterial = CreateMaterial(name, "UnlitGeneric", params)
		end
	end
end

local allbones
local hasGarryFixedBoneScalingYet = false

function SWEP:UpdateBonePositions(vm)
	if self.ViewModelBoneMods then
		if (not vm:GetBoneCount()) then return end
		-- !! WORKAROUND !! //
		-- We need to check all model names :/
		local loopthrough = self.ViewModelBoneMods

		if (not hasGarryFixedBoneScalingYet) then
			allbones = {}

			for i = 0, vm:GetBoneCount() do
				local bonename = vm:GetBoneName(i)

				if (self.ViewModelBoneMods[bonename]) then
					allbones[bonename] = self.ViewModelBoneMods[bonename]
				else
					allbones[bonename] = {
						scale = Vector(1, 1, 1),
						pos = Vector(0, 0, 0),
						angle = Angle(0, 0, 0)
					}
				end
			end

			loopthrough = allbones
		end

		-- !! ----------- !! //
		for k, v in pairs(loopthrough) do
			local bone = vm:LookupBone(k)
			if (not bone) then continue end
			-- !! WORKAROUND !! //
			local s = Vector(v.scale.x, v.scale.y, v.scale.z)
			local p = Vector(v.pos.x, v.pos.y, v.pos.z)
			local ms = Vector(1, 1, 1)

			if (not hasGarryFixedBoneScalingYet) then
				local cur = vm:GetBoneParent(bone)

				while (cur >= 0) do
					local pscale = loopthrough[vm:GetBoneName(cur)].scale
					ms = ms * pscale
					cur = vm:GetBoneParent(cur)
				end
			end

			s = s * ms

			-- !! ----------- !! //
			if vm:GetManipulateBoneScale(bone) ~= s then
				vm:ManipulateBoneScale(bone, s)
			end

			if vm:GetManipulateBoneAngles(bone) ~= v.angle then
				vm:ManipulateBoneAngles(bone, v.angle)
			end

			if vm:GetManipulateBonePosition(bone) ~= p then
				vm:ManipulateBonePosition(bone, p)
			end
		end
	else
		self:ResetBonePositions(vm)
	end
end

function SWEP:ResetBonePositions(vm)
	if (not vm:GetBoneCount()) then return end

	for i = 0, vm:GetBoneCount() do
		vm:ManipulateBoneScale(i, Vector(1, 1, 1))
		vm:ManipulateBoneAngles(i, Angle(0, 0, 0))
		vm:ManipulateBonePosition(i, Vector(0, 0, 0))
	end
end