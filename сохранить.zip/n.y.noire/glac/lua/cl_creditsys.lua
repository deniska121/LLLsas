-- "addons\\glac\\lua\\cl_creditsys.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- Notification function
function CSNotify(ply, str, duration, notifytype)
	if (notifytype == "Error") then
		notification.AddLegacy(str, NOTIFY_ERROR, duration)
	elseif (notifytype == "Generic") then
		notification.AddLegacy(str, NOTIFY_GENERIC, duration)
	end
end

i_credits = 0

net.Receive("ply_SetCredits", function(length)
	local amount = net.ReadInt(32)
	i_credits  = amount
end)

net.Receive("csnotify", function()
	local notifytype = net.ReadString()

	if (notifytype == "Error") then
		notification.AddLegacy(net.ReadString(), NOTIFY_ERROR, net.ReadInt(16))
	elseif (notifytype == "Generic") then
		notification.AddLegacy(net.ReadString(), NOTIFY_GENERIC, net.ReadInt(16))
	end
end)