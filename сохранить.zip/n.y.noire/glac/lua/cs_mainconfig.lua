-- "addons\\glac\\lua\\cs_mainconfig.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal

local caseid3_drop = {
	{
		Name = "Лёгкий бронежилет x3",
		icon = Material("gmodla/icons/armor2.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 55,
		OnPurFunction = function(ply)
			local item = {
				class = "armor",
				name = "Лёгкий бронежилет",
				model = "models/tnb/items/wintercoat.mdl",
				material = "gbskins/armor2",
				weight = 2.5,
				dt = {
					eclass = "armor"
				},
			}

			for i = 1,3 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "Сигара x5",
		icon = Material("gmodla/icons/sigar.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 50,
		OnPurFunction = function(ply)
			local item = {
				class = "sigar",
				name = "Сигара",
				model = "models/env/decor/ashtray/sigar02.mdl",
				weight = 0.05,
				dt = {
					eclass = "sigar"
				},
			}

			for i = 1,5 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "Сварочная маска",
		icon = Material("gmodla/icons/welding_mask.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 300,
		OnPurFunction = function(ply)
			local item = {
				class = "weldingmask",
				name = "Сварочная маска",
				model = "models/ez2models/humans/group03b/welding_mask.mdl",
				weight = 1,
				dt = {
					eclass = "weldingmask"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Баллистический Шлем",
		icon = Material("gmodla/icons/camo_swat.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 300,
		OnPurFunction = function(ply)
			local item = {
				class = "helmet",
				name = "Баллистический Шлем",
				model = "models/helmets/camo_swat.mdl",
				weight = 1,
				dt = {
					eclass = "helmet"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Каска x2",
		icon = Material("gmodla/icons/worker_helmet.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 50,
		OnPurFunction = function(ply)
			local item = {
				class = "hardhat",
				name = "Каска",
				model = "models/items/worker_helmet.mdl",
				weight = 0.5,
				dt = {
					eclass = "hardhat"
				},
			}

			for i = 1,2 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "Бонг",
		icon = Material("gmodla/icons/bottle.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 220,
		OnPurFunction = function(ply)
			local item = {
				class = "bong",
				name = "Бонг",
				model = "models/henry/gta sa/gmod/objects/bottle/bottle.mdl",
				dt = {
					eclass = "bong"
				},
			}


			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Премиум зажигалка x3",
		icon = Material("gmodla/icons/lighter.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 250,
		OnPurFunction = function(ply)
			local item = {
				class = "lighter",
				name = "Премиум зажигалка",
				model = "models/weapons/w_lighter.mdl",
				material = "models/weapons/v_lighter/lighter" .. math.random(2,7),
				weight	=	0.08,
				dt = {
					eclass = "lighter"
				},
			}

			for i = 1,3 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "БумБокс",
		icon = Material("gmodla/icons/boombox_02.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 100,
		OnPurFunction = function(ply)
			local item = {
				class = "boombox",
				name = "БумБокс",
				model = "models/physics_props/electronics/boombox_02.mdl",
				weight = 5.2,
				dt = {
					eclass = "boombox"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "БумБокс",
		icon =  Material("gmodla/icons/boombox_01.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 120,
		OnPurFunction = function(ply)
			local item = {
				class = "boombox",
				name = "БумБокс",
				model = "models/physics_props/electronics/boombox_01.mdl",
				weight = 5.2,
				dt = {
					eclass = "boombox"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Радио",
		icon = Material("gmodla/icons/boombox_03.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 60,
		OnPurFunction = function(ply)
			local item = {
				class = "radio",
				name = "Радио",
				model = "models/physics_props/electronics/boombox_03.mdl",
				weight = 0.5,
				dt = {
					eclass = "radio"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Радио",
		icon = Material("gmodla/icons/radio.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 65,
		OnPurFunction = function(ply)
			local item = {
				class = "radio",
				name = "Радио",
				model = "models/props/cs_office/radio.mdl",
				weight = 0.5,
				dt = {
					eclass = "radio"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Радио (от машины)",
		icon = Material("gmodla/icons/reciever01d.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 100,
		OnPurFunction = function(ply)
			local item = {
				class = "car_radio",
				name = "Радио (от машины)",
				model = "models/props_lab/reciever01d.mdl",
				weight = 0.5,
				dt = {
					eclass = "car_radio"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Телефон x2",
		icon = Material("gmodla/icons/cellphone-5.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 70,
		OnPurFunction = function(ply)
			local item = {
				["class"] = "phone_bj",
				["color"] = color_white,
				["dt"] = {["eclass"] = "phone_bj"},
				["model"] = "models/props_electronics/cellphone-5.mdl",
				["name"] = "Телефон",
				["phone_type"] = 7,
				["ud"] = {
					["PhoneColor"] = color_white,
					["PhoneType"] = "Beijing",
					["Ringtone"] = "cell/redsun.mp3",
					["Sleep"] = false,
					["WallPaper"] = "bch/1.png",
				},
				["weight"] = 0.1
			}

			for i = 1,2 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "NOSTALGY PHONE x2",
		icon = Material("gmodla/icons/camphone.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 70,
		OnPurFunction = function(ply)
			local item = {
				["class"] = "phone_n",
				["color"] = color_white,
				["dt"] = {["eclass"] = "phone_n"},
				["model"] = "models/cityrp/camphone.mdl",
				["name"] = "Телефон",
				["phone_type"] = 6,
				["ud"] = {
					["PhoneColor"] = color_white,
					["PhoneType"] = "Nocla",
					["Ringtone"] = "cell/tone_1.wav",
					["Sleep"] = false,
					["WallPaper"] = "n/1.png",
				},
				["weight"] = 0.1
			}

			for i = 1,2 do
				ply:AddBankItem(INV_JUNK, item)
			end
		end,
	},
	{
		Name = "FUTURE PHONE",
		icon = Material("gmodla/inv/phone_lm.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 500,
		OnPurFunction = function(ply)
			local item = {
				["class"] = "phone_lm",
				["color"] = color_white,
				["dt"] = {["eclass"] = "phone_lm"},
				["model"] = "models/mactavish/lm_phone.mdl",
				["name"] = "Телефон",
				["phone_type"] = 3,
				["ud"] = {
					["PhoneColor"] = color_white,
					["PhoneType"] = "Bloom",
					["Ringtone"] = "tone_4.wav",
					["Sleep"] = false,
					["WallPaper"] = "",
				},
				["weight"] = 0.1
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Таблетки",
		icon = Material("gmodla/icons/pills.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 310,
		OnPurFunction = function(ply)
			local item = {
				class = "pills8",
				name = "Таблетки LS4",
				model = "models/pills.mdl",
				weight = 0.1,
				dt = {
					eclass = "pills8"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Шапочка из фольги",
		icon = Material("gmodla/icons/foilhat.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 300,
		OnPurFunction = function(ply)
			local item = {
				class = "foilhat",
				name = "Шапочка из фольги",
				model = "models/tnb/items/beanie.mdl",
				weight = 0.01,
				material = "cityrp/foil",
				dt = {
					eclass = "foilhat"
				},
			}

			ply:AddBankItem(INV_JUNK, item)
		end,
	},
	{
		Name = "Молоток x2",
		icon = Material("gmodla/icons/hammer.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 150,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_hammer",
				model = "models/weapons/tfa_nmrih/w_tool_barricade.mdl",
				dt = {
					eclass = "mlw_hammer"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Труба x2",
		icon = Material("gmodla/icons/pipe.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 150,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_pipe",
				model = "models/weapons/tfa_nmrih/w_me_pipe_lead.mdl",
				weight = 0.7,
				dt = {
					eclass = "mlw_pipe"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Мачете x2",
		icon = Material("gmodla/icons/machete.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 200,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_machete",
				model = "models/weapons/tfa_nmrih/w_me_machete.mdl",
				weight = 1.1,
				dt = {
					eclass = "mlw_machete"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Клюшка x2",
		icon = Material("gmodla/icons/golfclub.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 150,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_club",
				model = "models/weapons/melee/w_golfclub.mdl",
				weight = 1.2,
				dt = {
					eclass = "mlw_club"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Кувалда",
		icon = Material("gmodla/icons/sledge.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 200,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_sledge",
				model = "models/weapons/tfa_nmrih/w_me_sledge.mdl",
				weight = 5.2,
				dt = {
					eclass = "mlw_sledge"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Лопата",
		icon = Material("gmodla/icons/spade.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 200,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_spade",
				model = "models/weapons/tfa_nmrih/w_me_spade.mdl",
				weight = 2.2,
				dt = {
					eclass = "mlw_spade"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
	{
		Name = "Пожарный топор",
		icon = Material("gmodla/icons/axe.png", "smooth"),
		desc = "",
		details = "",
		Category = "misc",
		Price = 200,
		OnPurFunction = function(ply)
			local item = {
				class = "mlw_fireaxe",
				model = "models/weapons/tfa_nmrih/w_me_axe_fire.mdl",
				weight = 4.1,
				dt = {
					eclass = "mlw_fireaxe"
				},
			}

			ply:AddBankItem(INV_WEAPON, item)
		end,
	},
}

local function loadD()
	CreditShop_Config.UseSQL = false
	CreditShop_Config.SaveStatsTime = 60

	CreditShop_Items["episode_1_premium"] = {
		Name = "Премиум пропуск - Эпизод первый",
		icon = Material("gmodla/f4/stuff/pass.png", "smooth"),
		desc = "",
		details = "",
		Category = "Other",
		Price = 1000,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored then return true end

			return not ply.MQSdata.Stored["episode_1_premium"]
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "episode_1_premium", true)
		end,
	}

	CreditShop_Items["episode_1_unlock"] = {
		Name = "TEST",
		icon = Material("gmodla/f4/stuff/restore.png", "smooth"),
		desc = "",
		details = "Компенсирует кредиты за удалённые из игры предметы.",
		Category = "OtherNon",
		Price = 0,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored or not ply.MQSdata.Stored.skins then return false end

			return true
		end,
		OnPurFunction = function(ply, item)

		end,
	}

	CreditShop_Items["token"] = {
		Name = "Токен для смены персонажа",
		icon = Material("gmodla/f4/stuff/pass.png", "smooth"),
		desc = "",
		details = "Позволяет вам пересоздать любого уже существующего персонажа.",
		Category = "Other",
		Price = 100,
		--Old_Price = 100,
		OGPrice = 200,
		OnPurFunction = function(ply, item)
			local ct = MQS.GetDataStored(ply, "mcr_change") or 0
			MQS.SetNWStoredData(ply, "mcr_change", math.max(ct, 0) + 1)
		end,
	}

	CreditShop_Items["carslots"] = {
		Name = "Слот на расширение гаража",
		icon = Material("gmodla/f4/stuff/garage.png", "smooth"),
		desc = "",
		details = "Позволяет вам расширить гараж на 1 дополнительное место. Каждый последующий токен увеличивается в стоимости.",
		Category = "Other",
		Price = 200,
		priceUpdater = function(ply)
			local ct = MQS.GetDataStored(ply, "car_slots") or 0
			return math.max(200 + ct * 25, 200)
		end,
		OnPurFunction = function(ply, item)
			local ct = MQS.GetDataStored(ply, "car_slots") or 0
			MQS.SetNWStoredData(ply, "car_slots", math.max(ct, 0) + 1)
		end,
	}

	CreditShop_Items["token2"] = {
		Name = "Токен снятия блокировки до 90 дней",
		icon = Material("gmodla/f4/stuff/pass.png", "smooth"),
		desc = "",
		details = "Снятие блокировки таким образом возможно только со сроком до 90 дней. Снятие блокировки за кредиты не отменяет ваши проступки. За последующие нарушения вы можете получить двойное наказание без предупреждения. 1 день = 50 кредитов.",
		Category = "Other",
		Price = 1200,
		priceUpdater = function(ply)
			local time = ply:getDarkRPVar("BANNED") or 7776000
			time = time - os.time()
			time = math.Round(time / 86400)
			return math.Clamp(time * 50, 50, 5000)
		end,
		check = function(ply)
			if not ply:getDarkRPVar("BANNED") then return false end
			if CLIENT then return true end
			if not sAdmin.bans[ply:SteamID64()] then return false end
			local time = tonumber(sAdmin.bans[ply:SteamID64()].expiration)

			if not time or time == 0 or time - os.time() > 7776000 then return false end

			return true
		end,
		OnPurFunction = function(ply, item)
			sAdmin.unban(ply:SteamID64())

			Discord.Log("request", {content = "<@&1180491439378010145>", username = ply:Name(), embeds = {{
				url = "http://steamid.macnco.one/?q=" .. ply:SteamID64(),
				title = ply:SteamName(),
				description = "Покупка разбана",
				color = 0xFF9300
			}}})

			ply:Kick("Токен активирован")
		end,
	}

	CreditShop_Items["d_packrat1"] = {
		Name = "Турист",
		icon = SERVER and "" or Material("gmodla/f4/packs/tourist.png", "smooth"),
		icon_size = {700, 1000},
		desc = "старт в новом городе",
		details = "Набор включает в себя: $50.000, бейсболку туриста, и сувенирную футболку.",
		Category = "Pack",
		Price = 1000,
		--Old_Price = 1000,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored then return true end

			return not ply.MQSdata.Stored["d_packrat1"]
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrat1", 1)
			ply:addMoney(50000)
		end,
	}

	CreditShop_Items["d_packrat4"] = {
		Name = "Англичанин",
		icon = SERVER and "" or Material("gmodla/f4/packs/englishman.png", "smooth"),
		icon_size = {700, 1000},
		desc = "джентльменский набор",
		details = "Набор включает в себя: набор мужских джемперов, две плоские кепки, и две клюшки. Оружие выдаётся единоразово.",
		Category = "Pack",
		Price = 2000,
		--Old_Price = 2000,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored then return true end

			return not ply.MQSdata.Stored["d_packrat4"]
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrat4", 1)
			local give = {
				class = "mlw_club",
				name = "Клюшка",
				model = "models/weapons/melee/w_golfclub.mdl",
				dt = {
					eclass = "mlw_club",
				},
			}
			ply:AddBankItem(INV_WEAPON, give)
			ply:AddBankItem(INV_WEAPON, give)
		end,
	}

	CreditShop_Items["d_packrat5"] = {
		Name = "Американская мечта",
		icon = SERVER and "" or Material("gmodla/f4/packs/dream.png", "smooth"),
		icon_size = {700, 1000},
		desc = "..в глазах приезжего",
		details = "Набор включает в себя: $500.000, комплект уникальных курток, и машину \"2004 Victoria\" с дополнительным слотом в гараж.",
		Category = "Pack",
		Price = 4000,
		--Old_Price = 4000,
		check = function(ply) return not ply.MQSdata.Stored["d_packrat5"] end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrat5", 1)

			local ct = MQS.GetDataStored(ply, "car_slots") or 0
			MQS.SetNWStoredData(ply, "car_slots", math.max(ct, 0) + 1)

			ply:addMoney(500000)
			McCD.AddCar(ply, "sim_fphys_l4d_crownvic")
		end,
	}

	CreditShop_Items["d_packrat6"] = {
		Name = "Амбиции",
		icon = SERVER and "" or Material("gmodla/f4/packs/nissan.png", "smooth"),
		icon_size = {700, 1000},
		desc = "с ними всё получится",
		details = "Набор включает в себя: рубашку малибу, солнцезащитные очки, и машину \"99 Nissan Skyline\" с дополнительным слотом в гараж.",
		Category = "Pack",
		Price = 7000,
		--Old_Price = 7000,
		check = function(ply) return not ply.MQSdata.Stored["d_packrat6"] end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrat6", 1)

			local ct = MQS.GetDataStored(ply, "car_slots") or 0
			MQS.SetNWStoredData(ply, "car_slots", math.max(ct, 0) + 1)

			McCD.AddCar(ply, "r34_simfphys")
		end,
	}

	CreditShop_Items["d_packrat7"] = {
		Name = "Мафиосо",
		icon = SERVER and "" or Material("gmodla/f4/packs/mafia.png", "smooth"),
		icon_size = {700, 1000},
		desc = "возврат в 50-е",
		details = "Набор включает в себя: два автомата M1928 Thompson с барабанными магазинами и скином, строгий заказной костюм, шляпу \"Федора\", и уникальную машину \"53 Pontiac Chieftain\" с дополнительным слотом в гараж. Оружие выдаётся единоразово.",
		Category = "Pack",
		Price = 7000,
		--Old_Price = 7000,
		check = function(ply) return not ply.MQSdata.Stored["d_packrat7"] end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrat7", 1)

			local ct = MQS.GetDataStored(ply, "car_slots") or 0
			MQS.SetNWStoredData(ply, "car_slots", math.max(ct, 0) + 1)

			McCD.AddCar(ply, "simfphys_potomac_indian")

			local give = {
				["DefaultMag"] = "thom_50",
				["att_saved"] = {
					{
						["Slot"] = 1,
						["m_Index"] = "vm_thotel_mag_00"
					},
					{
						["Slot"] = 2,
						["m_Index"] = "vm_thotel_stock_hv_00"
					},
					{
						["Slot"] = 3,
						["m_Index"] = "vm_sm_thotel_angled_00"
					},
					{
						["Slot"] = 4,
						["m_Index"] = "vm_thotel_barrel_l_00"
					},
					{
						["Slot"] = 5,
						["m_Index"] = "vm_thotel_irons_s_00"
					}
				},
				["class"] = "mwb_thompson",
				["clip1"] = 50,
				["clip2"] = -1,
				["dt"] = {
					["eclass"] = "mwb_thompson",
				},
				["gunstate"] = 1,
				["model"] = "models/easy/vg/weapons/w_thotel.mdl",
				["name"] = "M1928 Thompson",
				["weight"] = 5.4,
			}
			ply:AddBankItem(INV_WEAPON, give)
			ply:AddBankItem(INV_WEAPON, give)
		end,
	}

	CreditShop_Items["d_blueblood"] = {
		Name = "Голубая кровь",
		icon = SERVER and "" or Material("gmodla/f4/packs/blueblood.png", "smooth"),
		icon_size = {700, 1000},
		desc = "честь, учтивость, справедливость",
		details = "Набор включает в себя: две тематические футболки и одну толстовку, синюю бейсболку, и ствол из нержавеющей стали на пистолет Glock 17.",
		Category = "Pack",
		Price = 1500,
		--Old_Price = 1500,
		check = function(ply) return not ply.MQSdata.Stored["d_blueblood"] end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_blueblood", 1)
		end,
	}

	CreditShop_Items["d_packbluecolar"] = {
		Name = "Аппер Код",
		icon = SERVER and "" or Material("gmodla/f4/packs/uppercode.png", "smooth"),
		icon_size = {700, 1000},
		desc = "городской секрет",
		details = "Набор с рабочей, \"мужской\" направленностью, включает в себя: жилет, две шапки, две светоотражающие куртки, и восемь тематических комплектов одежды.",
		Category = "Pack",
		Price = 1500,
		--Old_Price = 1500,
		check = function(ply) return not ply.MQSdata.Stored["d_packbluecolar"] end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packbluecolar", 1)
		end,
	}

	CreditShop_Items["clear_cars"] = {
		Name = "Автолюбитель",
		icon = SERVER and "" or Material("gmodla/f4/packs/carz.png", "smooth"),
		icon_size = {700, 1000},
		desc = "новый взгляд на старые ценности",
		details = "Набор включает в себя: три автомобильных радио; чистое покрытие для: 69 Roadrunner, 69 Charger, 78 Ford, 82 Hatchback, 84 Fleetwood, 85 Mercedes W123, 95 Buick, 2001 Blazer, 2004 Victoria, и 2004 Ram.",
		Category = "Pack",
		Price = 1100,
		--Old_Price = 1100,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored then return true end

			return not ply.MQSdata.Stored["clear_cars"]
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "clear_cars", 1)
			local give = {
				class = "car_radio",
				name = "Радио (от машины)",
				model = "models/props_lab/reciever01d.mdl",
				dt = {
					eclass = "car_radio",
				},
			}
			ply:AddBankItem(INV_JUNK, give)
			ply:AddBankItem(INV_JUNK, give)
			ply:AddBankItem(INV_JUNK, give)
		end,
	}

	CreditShop_Items["d_fishy"] = {
		Name = "Быстрый бизнес",
		icon = SERVER and "" or Material("gmodla/f4/packs/fishy.png", "smooth"),
		icon_size = {700, 1000},
		desc = "почти фитнес",
		details = "Набор включает в себя: пять импортных телефонов, комплект спортивных поло, и однотонную бейсболку с двумя видами ношения.",
		Category = "Pack",
		Price = 600,
		--Old_Price = 600,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored then return true end

			return not ply.MQSdata.Stored["d_fishy"]
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_fishy", 1)
			local give = {
				["class"] = "phone_bj",
				["color"] = color_white,
				["dt"] = {["eclass"] = "phone_bj"},
				["model"] = "models/props_electronics/cellphone-5.mdl",
				["name"] = "Телефон",
				["phone_type"] = 7,
				["ud"] = {
					["PhoneColor"] = color_white,
					["PhoneType"] = "Beijing",
					["Ringtone"] = "cell/redsun.mp3",
					["Sleep"] = false,
					["WallPaper"] = "bch/1.png",
				},
				["weight"] = 0.1
			}
			for i = 1,5 do
				ply:AddBankItem(INV_JUNK, give)
			end
		end,
	}

	CreditShop_Items["packrathlwn"] = {
		Name = "Фамильярность",
		icon = SERVER and "" or Material("gmodla/f4/packs/hlwn.png", "smooth"),
		icon_size = {700, 1000},
		desc = "Ночь опасна.. возьми это с собой",
		details = "Набор включает в себя: $10.000, бейсболку бренд, и две кепки сантехника. Набор лимитирован - финальный день разблокировки 5 ноября",
		Category = "Pack",
		Price = 700,
		check = function(ply)
			return false
		end,
		OnPurFunction = function(ply, item)
			MQS.SetNWStoredData(ply, "d_packrathlwn", 1)
			ply:addMoney(10000)
		end,
	}

	CreditShop_Items["money"] = {
		Name = "$2.500",
		icon = Material("gmodla/f4/stuff/money_a.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 35,
		OnPurFunction = function(ply, item)
			ply:addMoney(2500)
		end,
	}

	CreditShop_Items["money1"] = {
		Name = "$7.000",
		icon = Material("gmodla/f4/stuff/money_s.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 70,
		OnPurFunction = function(ply, item)
			ply:addMoney(7000)
		end,
	}

	CreditShop_Items["money2"] = {
		Name = "$25.000",
		icon = Material("gmodla/f4/stuff/onemoney.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 200,
		OnPurFunction = function(ply, item)
			ply:addMoney(25000)
		end,
	}

	CreditShop_Items["money3"] = {
		Name = "$50.000",
		icon = Material("gmodla/f4/stuff/twomoney.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 350,
		OnPurFunction = function(ply, item)
			ply:addMoney(50000)
		end,
	}

	CreditShop_Items["money4"] = {
		Name = "$100.000",
		icon = Material("gmodla/f4/stuff/threemoney.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 650,
		OnPurFunction = function(ply, item)
			ply:addMoney(100000)
		end,
	}

	CreditShop_Items["money4.1"] = {
		Name = "$250.000",
		icon = Material("gmodla/f4/stuff/money_p.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 1500,
		OnPurFunction = function(ply, item)
			ply:addMoney(250000)
		end,
	}

	CreditShop_Items["money5"] = {
		Name = "$500.000",
		icon = Material("gmodla/f4/stuff/fourmoney.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 2920,
		OnPurFunction = function(ply, item)
			ply:addMoney(500000)
		end,
	}

	CreditShop_Items["money6"] = {
		Name = "$1.000.000",
		icon = Material("gmodla/f4/stuff/fivemoney.png", "smooth"),
		desc = "игровой валюты",
		details = "",
		Category = "Money",
		Price = 5000,
		OnPurFunction = function(ply, item)
			ply:addMoney(1000000)
		end,
	}

	CreditShop_Items["case_id1"] = {
		Name = "Манетрон",
		is_case = "case_id1",
		icon = SERVER and "" or Material("gmodla/f4/poster/muni1.png", "smooth"),
		icon_size = {700, 1000},
		desc = "игровая валюта",
		details = "Получи шанс выиграть от $2.500 до $500.000 игровой валюты",
		Category = "Cases",
		Price = 250,
	}

	CreditShop_Items["case_id2"] = {
		Name = "Врум-Врум",
		is_case = "case_id2",
		icon = SERVER and "" or Material("gmodla/f4/poster/carz1.png", "smooth"),
		icon_size = {700, 1000},
		desc = "машины",
		details = "Получи шанс выиграть почти любую машину из автосалона или одну из 3-х уникальных машин",
		Category = "Cases",
		check = function(ply)
			local cars = SERVER and ply:LoadCars() or (CarInventory or {})
			local maxcars = 5 + (MQS.GetDataStored(ply, "car_slots") or 0)
			if cars and #cars >= maxcars then
				if SERVER then DarkRP.notify(ply, 1, 4, "У вас достигнут лимит свободного места в личном гараже, " .. #cars .. " из " .. maxcars .. " машин!") end
				return false
			end
			return true
		end,
		Price = 1000,
	}

	CreditShop_Items["case_id3"] = {
		Name = "Находка",
		is_case = "case_id3",
		icon = SERVER and "" or Material("gmodla/f4/poster/stuff.png", "smooth"),
		icon_size = {700, 1000},
		desc = "уникальные предметы",
		details = "Получи шанс выиграть уникальные предметы",
		Category = "Cases",
		Price = 100,
	}

	local VehicleList = list.Get("simfphys_vehicles")
	CreditShop_Cases["case_id2"] = {}
	CreditShop_Cases["case_id3"] = {}

	for k, v in pairs(caseid3_drop) do
		local id = k .. "drop"
		CreditShop_Items[id] = v
		table.insert(CreditShop_Cases["case_id3"], {
			tbl = id,
			drop = k,
			chance = 501 - v.Price
		})
	end

	for k, v in pairs(McCD.Cars) do
		if v.nocase then continue end
		local veh = VehicleList[k]
		local pr = v.donate and v.price or math.Round(v.price / 200)

		CreditShop_Items[k] = {
			Name = v.name,
			icon = {veh.Model, 120, k, v.fweels},
			desc = "",
			details = "",
			Category = "cars",
			Price = pr,
			OnPurFunction = function(ply, item)
				McCD.AddCar(ply, k)
			end,
		}

		local ch = 9100 - pr

		if pr < 2000 then
			ch = ch * 3
		end

		table.insert(CreditShop_Cases["case_id2"], {
			tbl = k,
			chance = ch
		})
	end

	CreditShop_Cases["case_id1"] = {
		{
			tbl = "money",
			chance = 200
		},
		{
			tbl = "money1",
			chance = 175
		},
		{
			tbl = "money2",
			chance = 150
		},
		{
			tbl = "money3",
			chance = 100
		},
		{
			tbl = "money4",
			chance = 50
		},
		{
			tbl = "money4.1",
			chance = 50
		},
		{
			tbl = "money5",
			chance = 1
		},
	}

	local skins_restore = {
		["skin_ak_v21"] = 399,
		["skin_ak_supra"] = 299,
		["skin_ak_revol"] = 499,
		["skin_m4_thund"] = 299,
		["skin_m4_zip"] = 499,
		["skin_m4_oper"] = 349,
		["skin_m4_xrk"] = 999,
		["skin_scar_adder"] = 349,
		["skin_mp5_strap"] = 399,
		["skin_uzi_blow"] = 249,
		["skin_rem_eject"] = 249,
		["skin_rem_itha"] = 249,
		["skin_p320_quiet"] = 99,
		["skin_p320_slick"] = 179,
		["skin_glock_urban"] = 149,
		["skin_glock_task"] = 99,
		["skin_m9_guard"] = 149,
		["skin_m9_raf"] = 179,
		["skin_m1911_jav"] = 199,
		["skin_m1911_old"] = 449,
		["skin_walter"] = 249,
	}

	CreditShop_Items["token_restore"] = {
		Name = "Восстановление покупок",
		icon = Material("gmodla/f4/stuff/restore.png", "smooth"),
		desc = "",
		details = "Компенсирует кредиты за удалённые из игры предметы.",
		Category = "Other",
		Price = 0,
		check = function(ply)
			if not ply.MQSdata or not ply.MQSdata.Stored or not ply.MQSdata.Stored.skins then return false end

			return true
		end,
		OnPurFunction = function(ply, item)
			if not ply.MQSdata or not ply.MQSdata.Stored or not ply.MQSdata.Stored.skins then return end

			local price = 0

			for k, _ in pairs(ply.MQSdata.Stored.skins) do
				if skins_restore[k] then
					price = price + skins_restore[k]
				end
			end

			ply:AddCredits(price)
			MQS.SetNWStoredData(ply, "skins", nil)
		end,
	}

	CreditShop_Packs = {}

	for k,v in pairs(CreditShop_Items) do
		if v.Category == "Pack" then
			CreditShop_Packs[v.key] = table.Copy(v)
		end
	end

	if CLIENT then
		CreditShop_Items["case_id2"].DropSort = function(menu,k,v,drop)
			local hv, lv

			for a,f in pairs(drop) do
				local car = McCD.Cars[f.tbl]
				f.name = car.name
				f.ext = ""
				if car.nobuy then
					f.ext = "\nУникальная"
					f.chance = 1
				end
			end

			table.sort(drop, function(a, b)
				if not hv or hv > a.chance then hv = a.chance end
				if not lv or lv < a.chance then lv = a.chance end
				return a.chance > b.chance
			end)

			local av = math.Round(210 / (lv - hv), 3)

			MSD.InfoHeader(menu.canvas, "Содержание")

			for a,f in pairs(drop) do
				MSD.DropIcon(menu.canvas, Material("entities/" .. f.tbl .. ".png", "smooth"), 10, HSLToColor(180 + (lv - f.chance) * av, 0.89, 0.57), function() end, f.name .. f.ext)
			end
		end

		CreditShop_Items["case_id3"].DropSort = function(menu,k,v,drop)
			local hv, lv

			table.sort(drop, function(a, b)
				if not hv or hv > a.chance then hv = a.chance end
				if not lv or lv < a.chance then lv = a.chance end
				return a.chance > b.chance
			end)
			print(lv,hv)
			local av = math.Round(210 / (lv - hv), 3)

			MSD.InfoHeader(menu.canvas, "Содержание")

			for a,f in pairs(drop) do
				local item = caseid3_drop[f.drop]
				MSD.DropIcon(menu.canvas, item.icon, 10, HSLToColor(180 + (lv - f.chance) * av, 0.89, 0.57), function() end, item.Name)
			end
		end
	end
end

hook.Add("InitPostEntity", "CS_CONFIG_Initialize_Hook", function()
	timer.Simple(30, function()
		loadD()
	end)
end)

function formatCredits(num)
	return string.Comma(num) .. " ¤"
end