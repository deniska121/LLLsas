-- "addons\\glac\\lua\\autorun\\cs_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
CreditShop_Config = {}
CreditShop_ExtraPages = {}

CreditShop_Items = setmetatable({}, {
	__index = function(self, key)
		for k, v in pairs(self) do
			if (v.key == key) then return self[k] end
		end

		return nil
	end,
	__newindex = function(self, key, value)
		if (type(key) == "string" and type(value) == "table") then
			table.insert(self, value)
			self[#self].key = key
		end
	end
})

CreditShop_Items_Cats = {}
CreditShop_Cases = {}

if SERVER then
	AddCSLuaFile("cl_creditsys.lua")
	AddCSLuaFile("cs_mainconfig.lua")
	include("sv_creditsys.lua")
	include("sv_cs_permasystem.lua")
	include("cs_mainconfig.lua")
end

if CLIENT then
	include("cl_creditsys.lua")
	include("cs_mainconfig.lua")
end