-- "addons\\carradio\\lua\\wcarradio\\cl_carfui.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local tdui = wyozicr.tdui

tdui.RegisterSkin("WyoziCarRadio", {
	rect = {
		color = Color(0, 0, 0, 170)
	},
	button = {
		bgColor = Color(0, 0, 0, 200),
		bgHoverColor = Color(255, 147, 0),
		fgColor = Color(255, 255, 255)
	}
})