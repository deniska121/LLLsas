-- "addons\\gmodlamd\\lua\\autorun\\mmd_autorun.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ╔═╗╔═╗──────────╔═╗╔═╗──╔╗─────────╔╗─╔═══╗
-- ║║╚╝║║─────╔╗───║║╚╝║║─╔╝╚╗────────║║─╚╗╔╗║
-- ║╔╗╔╗╠══╦══╣╠══╗║╔╗╔╗╠═╩╗╔╬══╦═╦╦══╣║──║║║╠══╦══╦╦══╦═╗
-- ║║║║║║╔╗║╔═╩╣══╣║║║║║║╔╗║║║║═╣╔╬╣╔╗║║──║║║║║═╣══╬╣╔╗║╔╗╗
-- ║║║║║║╔╗║╚═╗╠══║║║║║║║╔╗║╚╣║═╣║║║╔╗║╚╗╔╝╚╝║║═╬══║║╚╝║║║║
-- ╚╝╚╝╚╩╝╚╩══╝╚══╝╚╝╚╝╚╩╝╚╩═╩══╩╝╚╩╝╚╩═╝╚═══╩══╩══╩╩═╗╠╝╚╝
-- ─────────────────────────────────────────────────╔═╝║
-- ─────────────────────────────────────────────────╚══╝
-- ▄▀█ ▀█▀ ▀█▀ █▀▀ █▄░█ ▀█▀ █ █▀█ █▄░█ █		This addon releases under MIT license
-- █▀█ ░█░ ░█░ ██▄ █░▀█ ░█░ █ █▄█ █░▀█ ▄		Original design by google https://material.io/
-- Copyright (c) 2020 Ayden Mactavish
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:
-- The above copyright notice and this permission notice shall be included in all
-- copies or substantial portions of the Software.
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
-- SOFTWARE.
MMD = {}
MMD.Patern = {}
MMD.Theme = {}
MMD.Text = {}

if SERVER then
	local f = file.Find("mmd/core/*", "LUA")

	for k, v in pairs(f) do
		if string.StartWith(v, "sh_") then
			include("mmd/core/" .. v)
			AddCSLuaFile("mmd/core/" .. v)
		elseif string.StartWith(v, "sv_") then
			include("mmd/core/" .. v)
		elseif string.StartWith(v, "cl_") then
			AddCSLuaFile("mmd/core/" .. v)
		end
	end

	f = file.Find("mmd/configs/*", "LUA")

	for k, v in pairs(f) do
		if string.StartWith(v, "sh_") then
			include("mmd/configs/" .. v)
			AddCSLuaFile("mmd/configs/" .. v)
		elseif string.StartWith(v, "sv_") then
			include("mmd/configs/" .. v)
		elseif string.StartWith(v, "cl_") then
			AddCSLuaFile("mmd/configs/" .. v)
		end
	end

	f = file.Find("mmd/derma/*", "LUA")

	for k, v in pairs(f) do
		AddCSLuaFile("mmd/derma/" .. v)
	end
else
	local f = file.Find("mmd/core/*", "LUA")

	for k, v in pairs(f) do
		if string.StartWith(v, "sh_") then
			include("mmd/core/" .. v)
		elseif string.StartWith(v, "cl_") then
			include("mmd/core/" .. v)
		end
	end

	f = file.Find("mmd/configs/*", "LUA")

	for k, v in pairs(f) do
		if string.StartWith(v, "sh_") then
			include("mmd/configs/" .. v)
		elseif string.StartWith(v, "cl_") then
			include("mmd/configs/" .. v)
		end
	end

	f = file.Find("mmd/derma/*", "LUA")

	for k, v in pairs(f) do
		include("mmd/derma/" .. v)
	end
end