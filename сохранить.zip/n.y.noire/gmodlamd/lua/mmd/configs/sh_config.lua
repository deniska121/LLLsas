-- "addons\\gmodlamd\\lua\\mmd\\configs\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
print("")