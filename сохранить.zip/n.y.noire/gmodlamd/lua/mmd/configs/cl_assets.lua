-- "addons\\gmodlamd\\lua\\mmd\\configs\\cl_assets.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
MMD.IconsAll = {}
MMD.Icons48 = {}

MMD.Icons48.close = Material("msd/icons/cross.png", "smooth")
MMD.Icons48.close_thick = Material("msd/icons/close-thick.png", "smooth")
MMD.Icons48.close_box = Material("msd/icons/close-box.png", "smooth")

MMD.Icons48.pause_circle_outline = Material("msd/icons/pause-circle-outline.png", "smooth")
MMD.Icons48.play_circle_outline = Material("msd/icons/play-circle-outline.png", "smooth")
MMD.Icons48.stop_circle_outline = Material("msd/icons/stop-circle-outline.png", "smooth")

MMD.IconsAll.logo = Material("gmodla/logo_c2.png", "smooth")
MMD.IconsAll.no_icon = Material("gmodla/f4/noicon.png", "smooth")
MMD.IconsAll.vignette = Material("msd/vignette.png", "smooth")
MMD.IconsAll.gradient = Material("gui/gradient", "smooth")
MMD.IconsAll.noicon = Material("gui/noicon.png", "smooth noclamp")