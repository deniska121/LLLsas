-- "addons\\gmodlamd\\lua\\mmd\\configs\\cl_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local NewFont = surface.CreateFont

NewFont("M_Roboto", {
    font = "Roboto",
    extended = true,
    size = 20,
    weight = 500
})

NewFont("M_Roboto_lil", {
    font = "Roboto",
    extended = true,
    size = 12,
    weight = 500
})

NewFont("M_Roboto16_TR", {
    font = "Roboto",
    extended = true,
    size = 16,
    weight = 600
})

NewFont("M_RobotoTh", {
    font = "Roboto Th",
    extended = true,
    size = 20,
    weight = 500
})

NewFont("M_RobotoB", {
    font = "Roboto Th",
    extended = true,
    size = 20,
    weight = 700
})

NewFont("M_RobotoB30", {
    font = "Roboto Th",
    extended = true,
    size = 30,
    weight = 500
})

NewFont("M_RobotoB36", {
    font = "Roboto",
    extended = true,
    size = 36,
    weight = 500
})

NewFont("M_RobotoExtra", {
    font = "Roboto",
    extended = true,
    size = 52,
    weight = 500
})

NewFont("M_Roboto_LA_small", {
    font = "Roboto",
    extended = true,
    size = 15,
    weight = 200
})


for i = 0, 20 do
    NewFont("M_Roboto" .. 16 + i, {
        font = "Roboto",
        extended = true,
        size = 16 + i,
        weight = 500
    })
end