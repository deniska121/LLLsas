-- "addons\\gmodlamd\\lua\\mmd\\configs\\cl_patern.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
MMD.GColors = {
	red = Color(255,0,0),
	red_light = Color(255,155,155),
	red_dark = Color(157,18,18),
	white_200 = Color(200, 200, 200),
	white_125 = Color(125, 125, 125),
	white_shadow = Color(125, 125, 125, 50),
	shadow = Color(0, 0, 0, 55),
	shadow_70 = Color(0,0,0,70),
	green = Color(0,119,16),
	green_light = Color(136,255,0),
	green_dark = Color(0,82,7),
	blue_dark = Color(0,77,173),
}

MMD.Patern.Gmod = {
	["p"] = Color(0,157,255),
	["9"] = Color(0,77,173),
	["8"] = Color(0,107,204),
	["7"] = Color(0,125,222),
	["6"] = Color(0,143,241),
	["5"] = Color(0,157,255),
	["4"] = Color(58,172,255),
	["3"] = Color(97,187,254),
	["2"] = Color(143,206,255),
	["1"] = Color(187,225,254),
}

MMD.Patern.GmodSub = {
	["s"] = Color(255,98,0),
	["9"] = Color(255,98,0),
	["8"] = Color(255,132,0),
	["7"] = Color(255,150,0),
	["6"] = Color(255,169,0),
	["5"] = Color(255,183,0),
	["4"] = Color(255,193,27),
	["3"] = Color(255,205,71),
	["2"] = Color(255,218,125),
	["1"] = Color(255,233,176),
}

MMD.Patern.GmodLA = {
	["p"] = Color(255,183,0),
	["9"] = Color(255,98,0),
	["8"] = Color(255,132,0),
	["7"] = Color(255,150,0),
	["6"] = Color(255,169,0),
	["5"] = Color(255,183,0),
	["4"] = Color(255,193,27),
	["3"] = Color(255,205,71),
	["2"] = Color(255,218,125),
	["1"] = Color(255,233,176),
}

MMD.Patern.GmodLASub = {
	["s"] = Color(0,77,173),
	["9"] = Color(0,77,173),
	["8"] = Color(0,107,204),
	["7"] = Color(0,125,222),
	["6"] = Color(0,143,241),
	["5"] = Color(0,157,255),
	["4"] = Color(58,172,255),
	["3"] = Color(97,187,254),
	["2"] = Color(143,206,255),
	["1"] = Color(187,225,254),
}

MMD.Patern.DarkTheme = {
	["d"] = Color(0,0,0),
	["l"] = Color(33,33,33),
	["m"] = Color(48,48,48),
	["s"] = Color(66,66,66),
}

MMD.Patern.LighTheme = {
	["d"] = Color(220,220,220),
	["l"] = Color(235,235,235),
	["m"] = Color(245,245,245),
	["s"] = Color(255,255,255),
}

MMD.Theme = MMD.Patern.DarkTheme
MMD.Text = MMD.Patern.LighTheme

MMD.Patern.MainColor = MMD.Patern.GmodLA
MMD.Patern.SubColor = MMD.Patern.GmodLASub