-- "addons\\gmodlamd\\lua\\mmd\\core\\cl_panels.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- ╔═══╗─────╔╗─╔╗─╔╦═══╦╗───────────────────────────
-- ║╔═╗║─────║║─║║─║║╔═╗║║───────────────────────────
-- ║╚═╝╠══╦═╗║║╔╣║─║║╚═╝║║───────────────────────────
-- ║╔╗╔╣╔╗║╔╗╣╚╝╣║─║║╔══╩╝──── By Mac and Rager ─────
-- ║║║╚╣╔╗║║║║╔╗╣╚═╝║║──╔╗───────────────────────────
-- ╚╝╚═╩╝╚╩╝╚╩╝╚╩═══╩╝──╚╝───────────────────────────
function MMD.WorkSpacePanel(parent, title, wd, hd, a_ignore)
	local bgc = MMD.ColorAlpha(MMD.Patern.DarkTheme["d"], 155)

	if not wd or not hd then
		wd, hd = 1.1, 1.3
	end

	local panel = vgui.Create("DPanel")

	if not a_ignore then
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	end

	panel.Paint = function(self, w, h)
		MMD.DrawTexturedRect(0, 0, w, h, MMD.IconsAll.vignette, bgc)
		MMD.Blur(self, 5, 5, 255, 50, w, h)
		MMD.DrawChildrenShadows(self)
	end

	panel.Close = function()
		panel:AlphaTo(0, 0.3, 0, function()
			panel:Remove()
		end)
	end

	panel.PerformLayout = function(self)
		local children = self:GetChildren()

		for k, v in pairs(children) do
			v:InvalidateLayout()
		end
	end

	parent:AddToWorkSpace(panel)
	local child = vgui.Create("DPanel", panel)
	child:SetSize(math.Clamp(panel:GetWide() / wd, 500, 900), panel:GetTall() / hd)
	child:Center()

	child.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.RoundedBox(0, 0, 0, w, 40, MMD.Patern.MainColor["p"])
		draw.DrawText(title, "M_Roboto", 10, 10, color_white, TEXT_ALIGN_LEFT)
	end

	child.PerformLayout = function(self)
		child:Center()

		if child.clsBut then
			child.clsBut:SetPos(child:GetWide() - 38, 5)
		end
	end

	child.clsBut = MMD.IconButton(child, MMD.Icons48.close_box, child:GetWide() - 38, 5, 32, MMD.Theme["s"], MMD.GColors.red, function()
		panel.Close()
	end)

	return panel, child
end

function MMD.AskPopup(parent, title, hide_clsBut, but_1, but_2)
	local bgc = MMD.ColorAlpha(MMD.Patern.DarkTheme["d"], 155)
	local panel

	if parent then
		panel = vgui.Create("DPanel")
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	else
		panel = vgui.Create("MMDSimpleFrame")
		panel:SetSize(ScrW(), ScrH())
		panel:MakePopup()
	end

	panel.Paint = function(self, w, h)
		MMD.DrawTexturedRect(0, 0, w, h, MMD.IconsAll.vignette, bgc)
		MMD.Blur(self, 5, 5, 255, 50, w, h)
		MMD.DrawChildrenShadows(self)
	end

	panel.Close = function()
		panel:AlphaTo(0, 0.3, 0, function()
			panel:Remove()
		end)
	end

	if parent then
		parent:AddToWorkSpace(panel)
	end

	local child = vgui.Create("DPanel", panel)
	child:SetSize(panel:GetWide() / 3, 135)
	child:Center()

	child.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.RoundedBox(0, 0, 0, w, 40, MMD.Patern.MainColor["p"])
		draw.DrawText(title, "M_Roboto", 10, 10, color_white, TEXT_ALIGN_LEFT)
	end

	child.PerformLayout = function(self)
		child:Center()

		if child.clsBut then
			child.clsBut:SetPos(child:GetWide() - 38, 5)
		end
	end

	if not hide_clsBut then
		child.clsBut = MMD.IconButton(child, MMD.Icons48.close_box, child:GetWide() - 38, 5, 32, MMD.Theme["s"], MMD.GColors.red, function()
			panel:Close()
		end)
	end

	if but_1 then
		local button = MMD.Button(child, but_1[1], 10, 50, child:GetWide() - 20, 30, function(self)
			panel:Close()
			but_1[2](self)
		end)

		button:DockPadding(10, 5, 10, 10)
		button:DockMargin(10, 5, 10, 10)
		button:Dock(BOTTOM)
	end

	if but_2 then
		local button = MMD.Button(child, but_2[1], 10, 50, child:GetWide() - 20, 30, function(self)
			panel:Close()
			but_2[2](self)
		end)

		button:DockPadding(10, 5, 10, 5)
		button:DockMargin(10, 5, 10, 5)
		button:Dock(BOTTOM)
	end

	return panel, child
end

function MMD.AskPopupEntr(parent, title, hide_clsBut, entr_1)
	local bgc = MMD.ColorAlpha(MMD.Patern.DarkTheme["d"], 155)
	local panel

	if parent then
		panel = vgui.Create("DPanel")
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	else
		panel = vgui.Create("MMDSimpleFrame")
		panel:SetSize(ScrW(), ScrH())
		panel:MakePopup()
	end

	panel.Paint = function(self, w, h)
		MMD.DrawTexturedRect(0, 0, w, h, MMD.IconsAll.vignette, bgc)
		MMD.Blur(self, 5, 5, 255, 50, w, h)
		MMD.DrawChildrenShadows(self)
	end

	panel.Close = function()
		panel:AlphaTo(0, 0.3, 0, function()
			panel:Remove()
		end)
	end

	if parent then
		parent:AddToWorkSpace(panel)
	end

	local child = vgui.Create("DPanel", panel)
	child:SetSize(panel:GetWide() / 3, 135)
	child:Center()

	child.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.RoundedBox(0, 0, 0, w, 40, MMD.Patern.MainColor["p"])
		draw.DrawText(title, "M_Roboto", 10, 10, color_white, TEXT_ALIGN_LEFT)
	end

	child.PerformLayout = function(self)
		child:Center()

		if child.clsBut then
			child.clsBut:SetPos(child:GetWide() - 38, 5)
		end
	end

	if not hide_clsBut then
		child.clsBut = MMD.IconButton(child, MMD.Icons48.close_box, child:GetWide() - 38, 5, 32, MMD.Theme["s"], MMD.GColors.red, function()
			panel:Close()
		end)
	end

	if entr_1 then
		local button = MMD.TextEntry(child, entr_1[1], nil, 10, 10, child:GetWide() - 20, 40, function(self)
			panel:Close()
			entr_1[2](self)
		end, true)

		button:DockPadding(10, 5, 10, 10)
		button:DockMargin(10, 5, 10, 10)
		button:Dock(BOTTOM)
	end

	return panel, child
end

function MMD.AskPopupCombo(parent, title, hide_clsBut, combo)
	local bgc = MMD.ColorAlpha(MMD.Patern.DarkTheme["d"], 155)
	local panel

	if parent then
		panel = vgui.Create("DPanel")
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	else
		panel = vgui.Create("MMDSimpleFrame")
		panel:SetSize(ScrW(), ScrH())
		panel:MakePopup()
	end

	panel.Paint = function(self, w, h)
		MMD.DrawTexturedRect(0, 0, w, h, MMD.IconsAll.vignette, bgc)
		MMD.Blur(self, 5, 5, 255, 50, w, h)
		MMD.DrawChildrenShadows(self)
	end

	panel.Close = function()
		panel:AlphaTo(0, 0.3, 0, function()
			panel:Remove()
		end)
	end

	if parent then
		parent:AddToWorkSpace(panel)
	end

	local child = vgui.Create("DPanel", panel)
	child:SetSize(panel:GetWide() / 3, 135)
	child:Center()

	child.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.RoundedBox(0, 0, 0, w, 40, MMD.Patern.MainColor["p"])
		draw.DrawText(title, "M_Roboto", 10, 10, color_white, TEXT_ALIGN_LEFT)
	end

	child.PerformLayout = function(self)
		child:Center()

		if child.clsBut then
			child.clsBut:SetPos(child:GetWide() - 38, 5)
		end
	end

	if not hide_clsBut then
		child.clsBut = MMD.IconButton(child, MMD.Icons48.close_box, child:GetWide() - 38, 5, 32, MMD.Theme["s"], MMD.GColors.red, function()
			panel:Close()
		end)
	end

	local button, cbb

	if combo then
		button = MMD.Button(child, combo[2], 10, 50, child:GetWide() - 20, 30, function(self)
			panel:Close()
			combo[3](self)
		end)

		button:DockPadding(10, 5, 10, 5)
		button:DockMargin(10, 5, 10, 5)
		button:Dock(BOTTOM)
		cbb = MMD.ComboBox(child, 10, 10, child:GetWide() - 20, 30, combo[1])
		cbb:DockPadding(10, 5, 10, 10)
		cbb:DockMargin(10, 5, 10, 10)
		cbb:Dock(BOTTOM)
	end

	return cbb, button, panel, child
end

function MMD.PopupWindow(parent, title, wd, hd)
	local bgc = MMD.ColorAlpha(MMD.Patern.DarkTheme["d"], 155)
	local panel

	if parent then
		panel = vgui.Create("DPanel")
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	else
		panel = vgui.Create("MMDSimpleFrame")
		panel:SetSize(ScrW(), ScrH())
		panel:MakePopup()
		panel:SetAlpha(1)
		panel:AlphaTo(255, 0.3)
	end

	panel.Paint = function(self, w, h)
		MMD.DrawTexturedRect(0, 0, w, h, MMD.IconsAll.vignette, bgc)
		MMD.Blur(self, 5, 5, 255, 50, w, h)
		MMD.DrawChildrenShadows(self)
	end

	panel.Close = function()
		panel:AlphaTo(0, 0.3, 0, function()
			panel:Remove()
		end)
	end

	if parent then
		parent:AddToWorkSpace(panel)
	end

	local child = vgui.Create("DPanel", panel)
	child:SetSize(panel:GetWide() / wd, panel:GetTall() / hd)
	child:Center()

	child.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.RoundedBox(0, 0, 0, w, 40, MMD.Patern.MainColor["p"])
		draw.DrawText(title, "M_Roboto", 10, 10, color_white, TEXT_ALIGN_LEFT)
	end

	child.PerformLayout = function(self)
		child:Center()

		if child.clsBut then
			child.clsBut:SetPos(child:GetWide() - 38, 5)
		end
	end

	child.clsBut = MMD.IconButton(child, MMD.Icons48.close_box, child:GetWide() - 38, 5, 32, MMD.Theme["s"], MMD.GColors.red, function()
		panel:Close()
	end)

	return panel, child
end

function MMD.PanelList(parent, x, y, w, h, horizontal, spacing, padding)
	local panel = vgui.Create("MMDPanelList", parent)
	panel:SetSize(w, h)
	panel:SetPos(x, y)
	panel:EnableVerticalScrollbar()
	panel:EnableHorizontal(horizontal)
	panel:SetSpacing(spacing)
	panel:SetPadding(padding)

	return panel
end

function MMD.IconButton(parent, mat, x, y, s, color, color2, func, rfunc)
	local button = vgui.Create("DButton", parent)
	button:SetSize(s, s)
	button:SetPos(x, y)
	button:SetText("")
	button.hovered = false
	button.alpha = 0
	button.mat = mat

	button.Paint = function(self, w, h)
		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawTexturedRect(0, 0, w, h, self.mat, MMD.ColorAlpha(color or MMD.Theme.l, 255 - self.alpha * 255))

		if self.alpha > 0 then
			MMD.DrawTexturedRect(0, 0, w, h, self.mat, MMD.ColorAlpha(color2 or MMD.Patern.MainColor["8"], self.alpha * 255))
		end

		return true
	end

	button.DoClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	if rfunc then
		button.DoRightClick = rfunc
	else
		button.DoRightClick = func
	end

	return button
end

function MMD.IconButtonR(parent, mat, x, y, s, color, color2, func, rfunc)
	local button = vgui.Create("DButton", parent)
	button:SetSize(s, s)
	button:SetPos(x, y)
	button:SetText("")
	button.hovered = false
	button.alpha = 0
	button.mat = mat

	button.Paint = function(self, w, h)
		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawTexturedRect(0, 0, w, h, self.mat, MMD.ColorAlpha(color or MMD.Text.l, 255 - self.alpha * 255))

		if self.alpha > 0 then
			MMD.DrawTexturedRect(0, 0, w, h, self.mat, MMD.ColorAlpha(color2 or MMD.Patern.MainColor["8"], self.alpha * 255))
		end

		return true
	end

	button.DoClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	if rfunc then
		button.DoRightClick = rfunc
	else
		button.DoRightClick = func
	end

	return button
end

function MMD.ButtonIcon(parent, text, mat, x, y, w, h, s, func, rfunc)
	local button = vgui.Create("DButton")
	button:SetSize(w, h)
	button:SetText(text)
	button.hovered = false
	button.alpha = 0

	button.Paint = function(self, w, h)
		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawTexturedRect(5, (h - s) / 2, s, s, mat, MMD.ColorAlpha(MMD.Text.l, 255 - self.alpha * 255))
		draw.DrawText(self:GetText(), "M_Roboto", 10 + s, h / 2 - 9, MMD.ColorAlpha(MMD.Text.s, 255 - self.alpha * 255), TEXT_ALIGN_LEFT)

		if self.alpha > 0 then
			MMD.DrawTexturedRect(5, (h - s) / 2, s, s, mat, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.alpha * 255))
			draw.DrawText(self:GetText(), "M_Roboto", 10 + s, h / 2 - 9, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.alpha * 255), TEXT_ALIGN_LEFT)
		end

		return true
	end

	button.DoClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	if rfunc then
		button.DoRightClick = rfunc
	else
		button.DoRightClick = func
	end

	if x and y then
		button:SetParent(parent)
		button:SetPos(x, y)
	else
		parent:AddItem(button)
	end

	return button
end

function MMD.ThemeSlider(parent, x, y, w, h, text, convr, var, comman)
	local conv = GetConVar(convr)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button:SetSize(w, h)
	button:SetPos(x, y)
	button.pos = conv:GetInt() == var and 1 or 0
	button.alpha = 0

	button.Paint = function(self, w, h)
		local min_w, max_w = w - 35, w - 18

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		draw.DrawText(text, "M_Roboto", 0, 0, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.alpha * 255), TEXT_ALIGN_LEFT)
		draw.DrawText(text, "M_Roboto", 0, 0, MMD.ColorAlpha(MMD.Text["s"], 255 - self.alpha * 255), TEXT_ALIGN_LEFT)

		if conv:GetInt() == var then
			self.pos = Lerp(0.1, self.pos, 1)
		else
			self.pos = Lerp(0.1, self.pos, 0)
		end

		draw.RoundedBox(6, min_w, 4, 30, 12, MMD.ColorAlpha(MMD.GColors.white_shadow, 100 - self.pos * 100))
		draw.RoundedBox(6, min_w, 4, 30, 12, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.pos * 255))
		draw.RoundedBox(8, math.Clamp(min_w + (17 * self.pos), min_w, max_w) - 1, 1, 18, 18, MMD.GColors.shadow)
		draw.RoundedBox(8, math.Clamp(min_w + (17 * self.pos), min_w, max_w), 2, 16, 16, MMD.Patern.MainColor["p"])
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	button.DoClick = function()
		RunConsoleCommand(comman)
	end

	return button
end

function MMD.BoolSlider(parent, x, y, w, h, text, var, func)
	local button = vgui.Create("DButton")
	button:SetText("")
	button:SetSize(w, h)

	if x then
		button:SetParent(parent)
		button:SetPos(x, y)
	end

	button.var = var
	button.pos = var and 1 or 0
	button.alpha = 0
	button.disabled = false

	button.Paint = function(self, w, h)
		local min_w, max_w = w - 35, w - 18

		if (self.hover or self.hovered) and not self.disabled then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		draw.DrawText(text, "M_Roboto26", 1, 1, color_black, TEXT_ALIGN_LEFT)
		draw.DrawText(text, "M_Roboto26", 0, 0, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.alpha * 255), TEXT_ALIGN_LEFT)
		draw.DrawText(text, "M_Roboto26", 0, 0, MMD.ColorAlpha(MMD.Text["s"], 255 - self.alpha * 255), TEXT_ALIGN_LEFT)

		if self.var then
			self.pos = Lerp(0.1, self.pos, 1)
		else
			self.pos = Lerp(0.1, self.pos, 0)
		end

		draw.RoundedBox(6, min_w, 4, 30, 12, MMD.ColorAlpha(MMD.GColors.white_shadow, 100 - self.pos * 100))
		draw.RoundedBox(6, min_w, 4, 30, 12, MMD.ColorAlpha(MMD.Patern.MainColor["8"], self.pos * 255))
		draw.RoundedBox(8, math.Clamp(min_w + (17 * self.pos), min_w, max_w) - 1, 1, 18, 18, MMD.GColors.shadow)
		draw.RoundedBox(8, math.Clamp(min_w + (17 * self.pos), min_w, max_w), 2, 16, 16, MMD.Patern.MainColor["p"])
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	button.DoClick = function(self)
		if self.disabled then return end
		self.var = not self.var
		func(self, self.var)
	end

	if not x then
		parent:AddItem(button)
	end

	return button
end

function MMD.MenuIconButton(parent, w, h, text, icon, s, func, matcol, nonsel)
	local mat = icon
	local subtest

	if istable(text) then
		subtest = text[2]
		text = text[1]
	end

	local button = vgui.Create("DButton")
	button:SetSize(w, h)
	button:SetText("")
	button.hovered = false

	button.anim_t = {
		fade = 0,
		alpha = 0
	}

	button.mouseEnter = {w / 2, h / 2}

	button.Paint = function(self, w, h)
		if self.hovered then
			self.anim_t.alpha = Lerp(FrameTime() * 3, self.anim_t.alpha, 1)
		else
			self.anim_t.alpha = Lerp(FrameTime() * 7, self.anim_t.alpha, 0)
		end

		if self.hover then
			self.anim_t.fade = Lerp(FrameTime() * 3, self.anim_t.fade, 1)
		else
			self.anim_t.fade = Lerp(FrameTime() * 3, self.anim_t.fade, 0)
		end

		draw.RoundedBox(0, 0, 0, w, h, MMD.ColorAlpha(MMD.Theme["m"], self.anim_t.fade * 255))

		if self.anim_t.alpha > 0.01 then
			MMD.DrawCircle(self.mouseEnter[1], self.mouseEnter[2], self.anim_t.alpha * w + 20, MMD.ColorAlpha(MMD.Theme["d"], self.anim_t.alpha * 255))
		end

		surface.SetMaterial(mat)
		surface.SetDrawColor(matcol or MMD.Text["d"])
		surface.DrawTexturedRect(5, h / 2 - s / 2, s, s)
		draw.SimpleText(text, "M_Roboto", s + 15, h / 2 - 9, MMD.ColorAlpha(MMD.Text["d"], 255 - self.anim_t.fade * 255), TEXT_ALIGN_LEFT)
		draw.DrawText(text, "M_Roboto", s + 15, h / 2 - 9, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.anim_t.fade * 255), TEXT_ALIGN_LEFT)

		if subtest and text ~= subtest then
			draw.DrawText(subtest, "M_Roboto", w - 10, h / 2 - 9, MMD.ColorAlpha(MMD.Text["d"], 100), TEXT_ALIGN_RIGHT)
		end
	end

	button.DoClick = function(self)
		if self.hovered then return end

		if not nonsel then
			self.hovered = true
		end

		self.anim_t.alpha = 0

		self.mouseEnter = {self:ScreenToLocal(gui.MousePos())}

		func(self)
	end

	button.DoRightClick = function(self)
		self:DoClick()
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.TextPanel(parent, text, x, y, w, h, blank)
	local panel = vgui.Create("DPanel")

	if x then
		panel:SetParent(parent)
		panel:SetPos(x, y)
	end

	panel:SetSize(w, h)
	panel.text = text

	panel.Paint = function(self, w, h)
		if self.text == "" then return end
		draw.SimpleText(self.text, "M_Roboto16", 0, h / 2 - 8, blank and MMD.Text["d"] or MMD.Patern.MainColor["p"], TEXT_ALIGN_LEFT)
	end

	if not x then
		parent:AddItem(panel)
	end

	return panel
end

function MMD.HeaderPanel(parent, text, x, y, w, h, clr)
	local panel = vgui.Create("DPanel")

	if x then
		panel:SetParent(parent)
		panel:SetPos(x, y)
	end

	panel:SetSize(w, h)
	panel.text = text

	panel.Paint = function(self, w, h)
		if self.text == "" then return end

		if clr then
			draw.SimpleTextOutlined(self.text, "M_Roboto27", 5, h / 2 - 12, clr, TEXT_ALIGN_LEFT, 0, 1, color_black)
		else
			draw.SimpleText(self.text, "M_Roboto27", 5, h / 2 - 12, MMD.Patern.MainColor["p"], TEXT_ALIGN_LEFT)
		end
	end

	if not x then
		parent:AddItem(panel)
	end

	return panel
end

function MMD.RichText(parent, text, x, y, w, h, font)
	if not font then
		font = "M_Roboto"
	end

	local panel = vgui.Create("DPanel")

	if x then
		panel:SetParent(parent)
		panel:SetPos(x, y)
	end

	panel:SetSize(w, h)
	panel.text = text

	panel.Paint = function(self, w, h)
		local text = DarkRP.textWrap(self.text, font, w)
		draw.DrawText(text, font, 5, 5, MMD.Text.l, TEXT_ALIGN_LEFT, 0)

		if self.oldt ~= text then
			local _, hd = surface.GetTextSize(text)
			self.oldt = text
			self:SetHeight(hd + 10)
		end
	end

	if not x then
		parent:AddItem(panel)
	end

	return panel
end

function MMD.Button(parent, text, x, y, w, h, func, rfunc)
	local button = vgui.Create("DButton")

	if x then
		button:SetParent(parent)
		button:SetPos(x, y)
	end

	button:SetSize(w, h)
	button:SetText(text)

	button.mouseEnter = {w / 2, h / 2}

	button.anim_t = {
		fadein = 0,
		alpha = 0,
		shadow = 0,
	}

	button.Paint = function(self, w, h)
		surface.DisableClipping(true)

		if self.anim_t.shadow > 0 then
			MMD.DrawShadow(2, 2, w - 4, h - 4, self.anim_t.shadow, 255)
		end

		surface.DisableClipping(false)

		if button.anim_t.fadein > 0 then
			button.anim_t.fadein = Lerp(FrameTime() * 3, button.anim_t.fadein, 0)
		end

		if self.hover then
			self.anim_t.alpha = Lerp(FrameTime() * 5, self.anim_t.alpha, 1)
			self.anim_t.shadow = Lerp(FrameTime() * 5, self.anim_t.shadow, 10)
		else
			self.anim_t.alpha = Lerp(FrameTime() * 5, self.anim_t.alpha, 0)
			self.anim_t.shadow = Lerp(FrameTime() * 5, self.anim_t.shadow, 0)
		end

		draw.RoundedBox(4, 0, 0, w, h, MMD.Patern.MainColor["7"])
		draw.RoundedBox(4, 0, 0, w, h, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.anim_t.alpha * 50))

		if button.anim_t.fadein > 0.01 then
			MMD.DrawCircle(self.mouseEnter[1], self.mouseEnter[2], (1 - button.anim_t.fadein) * w + 50, MMD.ColorAlpha(MMD.Patern.MainColor["3"], button.anim_t.fadein * 255))
		end

		draw.SimpleText(self:GetText(), "M_Roboto16", w / 2, h / 2 - 8, MMD.Patern.LighTheme["s"], TEXT_ALIGN_CENTER)

		return true
	end

	button.OnClick = function()
		button.anim_t.fadein = 1
		button.anim_t.alpha = 0
		button.anim_t.shadow = 0

		button.mouseEnter = {button:ScreenToLocal(gui.MousePos())}
	end

	button.DoClick = function(self)
		button.OnClick()
		func(self)
	end

	button.DoRightClick = function(self)
		button.OnClick()

		if rfunc then
			rfunc(self)
		else
			func(self)
		end
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	if not x then
		parent:AddItem(button)
	end

	return button
end

function MMD.TextEntry(parent, text, lable, x, y, w, h, func, ignore_focus)
	local Entry = vgui.Create("DTextEntry")

	if x then
		Entry:SetParent(parent)
		Entry:SetPos(x, y)
	end

	Entry:SetText("")
	Entry:SetFont("M_Roboto16")
	Entry:SetSize(w, h)
	Entry.alpha = 0
	Entry:SetDrawLanguageID(false)

	Entry.Paint = function(self, w, h)
		if self:HasFocus() then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 255)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		draw.RoundedBoxEx(4, 0, 0, w, h, MMD.Theme["l"], true, true, false, false)
		draw.RoundedBoxEx(0, 0, h - 1, w, 1, MMD.ColorAlpha(MMD.Text["s"], 255 - self.alpha))
		draw.RoundedBoxEx(0, 0, h - 1, w, 1, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.alpha))

		if self:GetValue() == "" then
			draw.SimpleText(text, "M_Roboto16", 3, h / 2 - 9, MMD.ColorAlpha(MMD.Text["s"], 120), TEXT_ALIGN_LEFT)
		end

		self:DrawTextEntryText(MMD.Text["d"], MMD.Patern.MainColor["p"], MMD.Text["s"])

		if lable then
			draw.SimpleText(lable, "M_Roboto_lil", 3, 1, MMD.ColorAlpha(MMD.Text["s"], 255 - self.alpha), TEXT_ALIGN_LEFT)
			draw.SimpleText(lable, "M_Roboto_lil", 3, 1, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.alpha), TEXT_ALIGN_LEFT)
		end
	end

	Entry.OnEnter = func

	if not ignore_focus then
		Entry.OnFocusChanged = function(self, gained)
			if not gained then
				func(self, self:GetValue())
			end
		end
	end

	Entry.OnCursorEntered = function(self)
		self.hover = true
	end

	Entry.OnCursorExited = function(self)
		self.hover = false
	end

	if not x then
		parent:AddItem(Entry)
	end

	return Entry
end

function MMD.MenuIconButtonSelect(parent, w, h, text, icon, s, func_select, func_deselect)
	local subtest

	if istable(text) then
		subtest = text[2]
		text = text[1]
	end

	local button = vgui.Create("DButton")
	button:SetSize(w, h)
	button:SetText("")
	button.hovered = false
	button.mat = icon

	button.anim_t = {
		fade = 0,
		alpha = 0
	}

	button.mouseEnter = {w / 2, h / 2}

	button.Paint = function(self, w, h)
		if self.hovered then
			self.anim_t.alpha = Lerp(FrameTime() * 2, self.anim_t.alpha, 1)
		else
			self.anim_t.alpha = Lerp(FrameTime() * 7, self.anim_t.alpha, 0)
		end

		if self.hover then
			self.anim_t.fade = Lerp(FrameTime() * 3, self.anim_t.fade, 1)
		else
			self.anim_t.fade = Lerp(FrameTime() * 3, self.anim_t.fade, 0)
		end

		draw.RoundedBox(0, 0, 0, w, h, MMD.ColorAlpha(MMD.Theme["m"], self.anim_t.fade * 255))

		if self.anim_t.alpha > 0.01 then
			MMD.DrawCircle(self.mouseEnter[1], self.mouseEnter[2], self.anim_t.alpha * w + 20, MMD.ColorAlpha(MMD.Theme["d"], self.anim_t.alpha * 255))
		end

		if self.disabled then
			draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["red"])
		end

		surface.SetMaterial(self.mat)
		surface.SetDrawColor(MMD.Text["d"])
		surface.DrawTexturedRect(5, h / 2 - s / 2, s, s)
		local wd = draw.DrawText(text, "M_Roboto", s + 15, h / 2 - 9, MMD.ColorAlpha(MMD.Text["d"], 255 - self.anim_t.fade * 255), TEXT_ALIGN_LEFT)
		draw.DrawText(text, "M_Roboto", s + 15, h / 2 - 9, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.anim_t.fade * 255), TEXT_ALIGN_LEFT)

		if subtest then
			draw.DrawText(subtest, "M_Roboto", s + wd + 20, h / 2 - 9, MMD.ColorAlpha(MMD.Text["s"], 255 - self.anim_t.fade * 255), TEXT_ALIGN_LEFT)
		end
	end

	button.DoClick = function(self)
		if self.disabled then return end
		self.anim_t.alpha = 0

		self.mouseEnter = {self:ScreenToLocal(gui.MousePos())}

		if self.hovered then
			self.hovered = false
			func_deselect(self)
		else
			self.hovered = true
			func_select(self)
		end
	end

	button.DoRightClick = function(self)
		self:DoClick()
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.ListView(parent)
	local panel = vgui.Create("DListView", parent)

	panel.Paint = function(s, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["d"])
	end

	panel.VBar.Paint = function(s, w, h)
		draw.RoundedBox(4, 3, 13, 8, h - 24, MMD.GColors.shadow_70)
	end

	panel.VBar.btnUp.Paint = function() end
	panel.VBar.btnDown.Paint = function() end

	panel.VBar.btnGrip.Paint = function(s, w, h)
		draw.RoundedBox(4, 5, 0, 4, h + 22, MMD.GColors.shadow_70)
	end

	return panel
end

function MMD.ComboBox(parent, x, y, w, h, val)
	local ComboBox = vgui.Create("DComboBox")

	if x then
		ComboBox:SetParent(parent)
		ComboBox:SetPos(x, y)
	end

	ComboBox:SetSize(w, h)
	ComboBox:SetValue(val)
	ComboBox:SetFont("M_Roboto16")
	ComboBox.alpha = 0
	ComboBox.disabled = false

	ComboBox.Paint = function(self, w, h)
		if self:IsMenuOpen() then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 255)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		self:SetTextColor(MMD.Text["s"])
		draw.RoundedBoxEx(4, 0, 0, w, h, MMD.Theme["l"], true, true, false, false)
		draw.RoundedBoxEx(0, 0, h - 1, w, 1, MMD.ColorAlpha(MMD.Text["s"], 255 - self.alpha))
		draw.RoundedBoxEx(0, 0, h - 1, w, 1, MMD.ColorAlpha(MMD.Patern.MainColor["p"], self.alpha))
	end

	ComboBox.OnCursorEntered = function(self)
		self.pressed = true
	end

	ComboBox.OnCursorExited = function(self)
		self.pressed = false
	end

	function ComboBox:OpenMenu(pControlOpener)
		if (pControlOpener and pControlOpener == self.TextEntry) then return end
		if (self.disabled) then return end
		if (#self.Choices == 0) then return end

		if (IsValid(self.Menu)) then
			self.Menu:Remove()
			self.Menu = nil
		end

		self.Menu = MDermaMenu(false, self)

		if (self:GetSortItems()) then
			local sorted = {}

			for k, v in pairs(self.Choices) do
				val = tostring(v)

				if (string.len(val) > 1 and not tonumber(val) and val:StartWith("#")) then
					val = language.GetPhrase(val:sub(2))
				end

				table.insert(sorted, {
					id = k,
					data = v,
					label = val
				})
			end

			for k, v in SortedPairsByMemberValue(sorted, "label") do
				local option = self.Menu:AddOption(v.data, function()
					self:ChooseOption(v.data, v.id)
				end)

				if (self.ChoiceIcons[v.id]) then
					option:SetIcon(self.ChoiceIcons[v.id])
				end
			end
		else
			for k, v in pairs(self.Choices) do
				local option = self.Menu:AddOption(v, function()
					self:ChooseOption(v, k)
				end)

				if (self.ChoiceIcons[k]) then
					option:SetIcon(self.ChoiceIcons[k])
				end
			end
		end

		local x, y = self:LocalToScreen(0, self:GetTall())
		self.Menu:SetMinimumWidth(self:GetWide())
		self.Menu:Open(x, y, false, self)
	end

	if not x then
		parent:AddItem(ComboBox)
	end

	return ComboBox
end

function MMD.ModelBox(parent, x, y, w, h, model)
	if not model then
		model = "models/player/group01/male_01.mdl"
	end

	local icon = vgui.Create("DModelPanel", parent)
	icon:SetSize(w, h)
	icon:SetPos(x, y)
	icon:SetFOV(30)
	icon:SetDirectionalLight(BOX_RIGHT, Color(255, 160, 80, 255))
	icon:SetDirectionalLight(BOX_LEFT, Color(80, 160, 255, 255))
	icon:SetAmbientLight(Vector(-64, -64, -64))
	icon:SetAnimated(true)
	icon.Angles = Angle(0, 0, 0)

	function icon.SetMDL(mdl)
		icon:SetModel(mdl)
		icon.Entity:ResetSequence("menu_combine")
		icon.Entity:SetPos(Vector(0, 0, -15))
	end

	icon.SetMDL(model)

	function icon:DragMousePress()
		self.PressX, self.PressY = gui.MousePos()
		self.Pressed = true
	end

	function icon:DoDoubleClick()
		if icon:GetFOV() < 10 then
			icon:SetFOV(40)
		else
			icon:SetFOV(icon:GetFOV() - 5)
		end
	end

	function icon:DragMouseRelease()
		self.Pressed = false
	end

	function icon:LayoutEntity(ent)
		if (self.bAnimated) then
			self:RunAnimation()
		end

		if (self.Pressed) then
			local mx, my = gui.MousePos()
			self.Angles = self.Angles - Angle(0, (self.PressX or mx) - mx, 0)
			self.PressX, self.PressY = gui.MousePos()
		end

		ent:SetAngles(self.Angles)
	end

	return icon
end

function MMD.SubListPanel(parent, w, h, minw, minh, text, alpha, lined)
	local panel = vgui.Create("DPanel")

	panel.StaticScale = {
		w = w,
		h = h,
		minw = minw,
		minh = minh
	}

	panel.text = text

	panel.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["s"])
		draw.DrawText(self.text, "M_Roboto", 10, 10, MMD.Patern.MainColor["p"], TEXT_ALIGN_LEFT)
	end

	if alpha then
		panel:SetAlpha(0)
		panel:AlphaTo(255, 0.3)
	end

	parent:AddItem(panel)
	panel.ScrP = MMD.PanelList(panel, 0, 0, panel:GetWide(), panel:GetTall() - 50, lined or false, 0, 0)
	panel.ScrP:DockPadding(0, 45, 0, 5)
	panel.ScrP:DockMargin(0, 45, 0, 5)
	panel.ScrP:Dock(FILL)

	panel.ScrP.DeselectButts = function(self)
		for k, v in pairs(panel.ScrP:GetItems()) do
			if v and v:IsValid() and v ~= self then
				v.hovered = false
			end
		end
	end

	return panel
end

function MMD.ButtonPresets(parent, pth, txt, func)
	local button = vgui.Create("DButton")
	button:SetSize(128, 150)
	button:SetText("")
	button.alpha = 0

	button.Paint = function(self, w, h)
		local mat = MMD.ImgLib.GetMaterial("http://macnco.one/rankup/" .. pth .. ".png")

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawCircle(w / 2, h / 2, self.alpha * h, MMD.Theme["d"])
		MMD.DrawTexturedRect(4, 4, 120, 120, mat, color_white)
		draw.DrawText(txt, "M_Roboto", w / 2, 125, MMD.Text.l, TEXT_ALIGN_CENTER)

		return true
	end

	button.DoClick = func
	button.DoRightClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.ButtonCateg(parent, pth, txt, func, bool)
	local button = vgui.Create("DButton")

	button.StaticScale = {
		w = 2,
		h = 5,
		minw = 200,
		minh = 100
	}

	button:SetText("")
	button.alpha = 0

	button.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		if pth then
			MMD.DrawTexturedRect(0, 0, w, h, pth, bool and Color(255, 255, 255) or MMD.Theme["d"])
		end

		if not bool then
			MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(MMD.Theme["d"], self.alpha * 255))
			draw.DrawText(txt, "M_Roboto27", w / 2, h / 2 - 9, MMD.Text.l, TEXT_ALIGN_CENTER, 0)
		else
			MMD.DrawTexturedRect(w / 1.412, 0, w / 3.41, h, "gmodla/f4/cate/light_select.png", Color(255, 255, 255, self.alpha * w))
		end

		return true
	end

	button.DoClick = func
	button.DoRightClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.ButtonJob(parent, job, func)
	local jname = job.name
	local vip

	if string.sub(jname, 0, 5) == "[VIP]" then
		vip = "V.I.P."
		jname = string.sub(jname, 6)
	elseif string.sub(jname, 0, 9) == "[PREMIUM]" then
		vip = "PREMIUM"
		jname = string.sub(jname, 10)
	end

	local color_vip = {
		["V.I.P."] = MMD.Patern.SubColor["3"],
		["PREMIUM"] = MMD.Patern.MainColor["p"],
	}

	local button = vgui.Create("DPanel")

	button.StaticScale = {
		w = 1,
		fixed_h = 120,
		minw = 200,
		minh = 120
	}

	button.alpha = 0

	button.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		if vip then
			surface.SetDrawColor(MMD.ColorAlpha(color_vip[vip], self.alpha * 200))
			surface.SetMaterial(MMD.IconsAll.gradient)
			surface.DrawTexturedRectRotated(w / 2, h / 2, w, h, 180)
			draw.DrawText(vip, "M_RobotoExtra", w - 10, h / 2 - 26, MMD.ColorAlpha(MMD.Theme.s, 255 - self.alpha * 200), TEXT_ALIGN_RIGHT, 0)
			draw.DrawText(vip, "M_RobotoExtra", w - 10, h / 2 - 26, MMD.ColorAlpha(MMD.Text.s, self.alpha * 255), TEXT_ALIGN_RIGHT, 0)
		else
			MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(MMD.Theme["d"], self.alpha * 255))
		end

		draw.DrawText(jname, "M_Roboto27", 125, 15, MMD.Text.l, TEXT_ALIGN_LEFT, 0)

		if job.max > 0 then
			draw.DrawText(#team.GetPlayers(job.team) .. "/" .. job.max, "M_Roboto", w - 10, 10, MMD.Text.l, TEXT_ALIGN_RIGHT, 0)
		else
			draw.DrawText("∞", "M_Roboto", w - 10, 10, MMD.Text.l, TEXT_ALIGN_RIGHT, 0)
		end
	end

	parent:AddItem(button)
	local model = job.model

	if istable(model) then
		model = model[1]
	end

	button.model = vgui.Create("ModelImage", button)
	button.model:SetSize(120, 120)
	button.model:SetModel(model, 1, "000000000")
	button.click = vgui.Create("DButton", button)
	button.click:Dock(FILL)
	button.click:SetText("")
	button.click.DoClick = func
	button.click.DoRightClick = func

	button.click.OnCursorEntered = function()
		button.hover = true
	end

	button.click.OnCursorExited = function()
		button.hover = false
	end

	button.click.Paint = function() end

	return button
end

function MMD.ButtonItems(parent, item, func)
	local button = vgui.Create("DPanel")

	button.StaticScale = {
		w = 1,
		fixed_h = 82,
		minw = 200,
		minh = 82
	}

	button.alpha = 0

	button.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(MMD.Theme["d"], self.alpha * 255))
		draw.DrawText(item.name, "M_Roboto27", 125, 10, MMD.Text.l, TEXT_ALIGN_LEFT, 0)
		draw.DrawText("$" .. item.price, "M_Roboto25", 125, 35, MMD.Text.d, TEXT_ALIGN_LEFT, 0)

		if item.amount and item.amount > 1 then
			draw.DrawText(item.amount .. " шт", "M_Roboto", w - 10, 10, MMD.Text.l, TEXT_ALIGN_RIGHT, 0)
		end
	end

	parent:AddItem(button)
	local model = item.model

	if istable(model) then
		model = model[1]
	end

	button.model = vgui.Create("ModelImage", button)
	button.model:SetSize(82, 82)
	button.model:SetModel(model, 1, "000000000")
	button.click = vgui.Create("DButton", button)
	button.click:Dock(FILL)
	button.click:SetText("")
	button.click.DoClick = func
	button.click.DoRightClick = func

	button.click.OnCursorEntered = function()
		button.hover = true
	end

	button.click.OnCursorExited = function()
		button.hover = false
	end

	button.click.Paint = function() end

	return button
end

function MMD.ButtonDonate(parent, item, func)
	local icon

	if item.Icon then
		icon = Material(item.IconImg, "smooth")
	end

	local button = vgui.Create("DButton")

	button.StaticScale = {
		w = 1,
		fixed_h = 120,
		minw = 200,
		minh = 120
	}

	button.alpha = 0

	button.Paint = function(self, w, h)
		if self.hovered then
			self:SetCursor("arrow")
		end

		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(MMD.Theme["d"], self.alpha * 255))

		if icon then
			MMD.DrawTexturedRect(0, 0, 120, 120, icon, color_white)
		end

		draw.DrawText(item.Name, "M_Roboto27", 125, 10, MMD.Text.l, TEXT_ALIGN_LEFT, 0)
		draw.DrawText(item.Price .. " руб.", "M_Roboto25", 125, 35, MMD.Text.d, TEXT_ALIGN_LEFT, 0)

		if self.hovered then
			surface.SetMaterial(MMD.IconsAll.noicon)
			surface.SetDrawColor(255, 255, 255, 100)
			surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, w / 64, h / 64)
			draw.DrawText("Товар уже куплен или недоступен", "M_Roboto36", w / 2, h - 40, MMD.Theme.d, TEXT_ALIGN_CENTER, 0)
		end
	end

	button:SetText("")

	button.DoClick = function(self)
		if not self.hovered then
			func(self)
		end
	end

	button.OnCursorEntered = function()
		button.hover = true
	end

	button.OnCursorExited = function()
		button.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.ButtonCases(parent, k, item, func)
	local icon

	if item.icon then
		icon = Material(item.icon, "smooth")
	end

	local button = vgui.Create("DButton")

	button.StaticScale = {
		w = 1,
		fixed_h = 120,
		minw = 200,
		minh = 120
	}

	button.alpha = 0

	button.Paint = function(self, w, h)
		if self.hovered then
			self:SetCursor("arrow")
		end

		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(MMD.Theme["d"], self.alpha * 255))
		draw.RoundedBox(0, 0, 0, 5 + self.alpha * 115, h, item.color)
		MMD.DrawTexturedRect(0, 0, 120, 120, icon or MMD.IconsAll.no_icon, icon and color_white or MMD.Theme["d"])
		draw.DrawText(item.name1, "M_Roboto27", 125, 10, MMD.Text.l, TEXT_ALIGN_LEFT, 0)
		draw.DrawText("$" .. item.price, "M_Roboto25", 125, 35, MMD.Text.d, TEXT_ALIGN_LEFT, 0)

		if self.hovered then
			surface.SetMaterial(MMD.IconsAll.noicon)
			surface.SetDrawColor(255, 255, 255, 100)
			surface.DrawTexturedRectUV(0, 0, w, h, 0, 0, w / 64, h / 64)
			draw.DrawText("Товар уже куплен или недоступен", "M_Roboto36", w / 2, h - 40, MMD.Theme.d, TEXT_ALIGN_CENTER, 0)
		end
	end

	button:SetText("")

	button.DoClick = function(self)
		if not self.hovered then
			func(self)
		end
	end

	button.OnCursorEntered = function()
		button.hover = true
	end

	button.OnCursorExited = function()
		button.hover = false
	end

	parent:AddItem(button)

	return button
end

function MMD.AchivmentStuff(parent, data)
	local icon, color = nil, Color(100, 100, 100)

	if data.Icon then
		icon = Material(data.Icon, "smooth")
	end

	if data.Completed then
		color = color_white
	end

	local button = vgui.Create("DPanel")
	button:SetSize(250, 64)

	button.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])

		if icon then
			MMD.DrawTexturedRect(0, 0, 64, 64, icon, color)
		end

		draw.DrawText(data.Name, "M_Roboto", 70, 5, MMD.Text.d, TEXT_ALIGN_LEFT, 0)
		draw.DrawText(data.Description, "M_Roboto16", 70, 25, MMD.Text.l, TEXT_ALIGN_LEFT, 0)

		if data.Completed then
			draw.DrawText(os.date("Выполненно %b %d, %Y %I:%M %p", tonumber(data.CompletedOn)), "M_Roboto16", 70, h - 22, MMD.Text.l, TEXT_ALIGN_LEFT, 0)
		else
			local prec = data.Value / data.Target
			prec = math.Clamp(prec, 0, 1)
			draw.RoundedBox(4, 70, h - 12, w - 80, 8, MMD.Theme["d"])
			draw.RoundedBox(4, 70, h - 12, (w - 80) * prec, 8, MMD.Patern.MainColor["p"])
			draw.SimpleTextOutlined(data.Value .. "/" .. data.Target, "M_Roboto16", w / 2 + 35, h - 18, MMD.Text.l, TEXT_ALIGN_CENTER, 0, 1, MMD.Theme.l)
		end
	end

	parent:AddItem(button)

	return button
end

function MakeGBUpdateButton(parent, x, y, func)
	local bgfade = 0
	local rotate = 0
	local rot_timer = 0
	local button = vgui.Create("DButton", parent)
	button:SetPos(x, y)
	button:SetSize(32, 32)
	button:SetText("")
	button.rotate = false

	button.Paint = function(self, w, h)
		local color

		if self.hover then
			bgfade = Lerp(FrameTime() * 5, bgfade, 150)
		else
			bgfade = Lerp(FrameTime() * 5, bgfade, 0)
		end

		if self.rotate and rot_timer < CurTime() then
			self.rotate = false
		end

		rotate = Lerp(FrameTime() * 0.1, rotate, 530)

		if self.rotate then
			surface.SetMaterial(Material("gui/html/refresh.vtf"))
			surface.SetDrawColor(100, 200, 0, 255)
			surface.DrawTexturedRectRotated(16, 16, 32, 32, (rotate * -3) % 360)
		else
			surface.SetMaterial(Material("gui/html/refresh.vtf"))
			surface.SetDrawColor(100, 200, 0, 255 - (150 - bgfade))
			surface.DrawTexturedRectRotated(16, 16, 32, 32, 0)
		end
	end

	button.DoClick = function(self)
		if self.rotate then return end
		func(self)
		rot_timer = CurTime() + 6
		self.rotate = true
		rotate = 0
	end

	button.DoRightClick = function(self)
		if self.rotate then return end
		func(self)
		rot_timer = CurTime() + 6
		self.rotate = true
		rotate = 0
	end

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	return button
end

function MMD.CreateINVModule(k, v, parent, func)
	local col, icon = v.color or MMD.Theme["d"], nil

	if v.icon then
		icon = Material(v.icon, "smooth")
	end

	local text_pos = 0
	local text_dir
	local button = vgui.Create("DButton")

	button.StaticScale = {
		w = 4,
		h = 3,
		minw = 180,
		minh = 220
	}

	button:SetText("")
	button.alpha = 0

	button.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["l"])
		MMD.DrawCircle(w / 2, h / 2, self.alpha * w, MMD.ColorAlpha(col, self.alpha * 155))
		MMD.DrawTexturedRect(0, 0, w, w, icon or MMD.IconsAll.no_icon, icon and color_white or MMD.Theme["d"])

		if self.hover or self.hovered then
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 1)
		else
			self.alpha = Lerp(FrameTime() * 5, self.alpha, 0)
		end

		draw.RoundedBox(0, 0, w, w, h, col)

		if v.itemType == "Weapon" and v.permanent then
			draw.RoundedBox(0, 0, w - 25, w, 25, MMD.Theme["d"])
			draw.SimpleText("НАВСЕГДА", "M_Roboto", w / 2, w - 23, color_white, TEXT_ALIGN_CENTER, 2)
		end

		if self.SmallFond then
			local text = DarkRP.textWrap(v.name1, "M_Roboto16", w)
			draw.DrawText(text, "M_Roboto16", w / 2, 5, color_white, TEXT_ALIGN_CENTER, 2)
		else
			local text = DarkRP.textWrap(v.name1, "M_Roboto", w)
			draw.DrawText(text, "M_Roboto", w / 2, 5, color_white, TEXT_ALIGN_CENTER, 2)
		end

		return true
	end

	button.DoClick = func

	button.OnCursorEntered = function(self)
		self.hover = true
	end

	button.OnCursorExited = function(self)
		self.hover = false
	end

	parent:AddItem(button)

	return button
end