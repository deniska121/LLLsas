-- "addons\\gmodlamd\\lua\\mmd\\core\\cl_fuctions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
-- █░█ ▀█▀ █ █░░ █ ▀█▀ █▄█   █▀▀ █░█ █▄░█ █▀▀ ▀█▀ █ █▀█ █▄░█ █▀
-- █▄█ ░█░ █ █▄▄ █ ░█░ ░█░   █▀░ █▄█ █░▀█ █▄▄ ░█░ █ █▄█ █░▀█ ▄█
MMD.SU = Material("shadow/u.png", "smooth noclamp")
MMD.SL = Material("shadow/l.png", "smooth noclamp")
MMD.SR = Material("shadow/r.png", "smooth noclamp")
MMD.SD = Material("shadow/d.png", "smooth noclamp")
MMD.SLU = Material("shadow/lu.png", "smooth noclamp")
MMD.SRU = Material("shadow/ru.png", "smooth noclamp")
MMD.SLD = Material("shadow/ld.png", "smooth noclamp")
MMD.SRD = Material("shadow/rd.png", "smooth noclamp")

function MMD.DrawTexturedRect(x, y, w, h, mat, color)
	if isstring(mat) then
		mat = Material(mat)
	end

	surface.SetDrawColor(color)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(x, y, w, h)
end

function MMD.FormatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
	n = tostring(n)
	local sep = sep or ","
	local dp = string.find(n, "%.") or #n + 1

	for i = dp - 4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i + 1)
	end

	return n
end

function MMD.DrawShadow(x, y, w, h, s, fade)
	if not fade then
		fade = 255
	end

	surface.SetDrawColor(255, 255, 255, fade)
	surface.SetMaterial(MMD.SU)
	surface.DrawTexturedRect(x, y - s, w, s)
	surface.SetMaterial(MMD.SR)
	surface.DrawTexturedRect(x + w, y, s, h)
	surface.SetMaterial(MMD.SD)
	surface.DrawTexturedRect(x, y + h, w, s)
	surface.SetMaterial(MMD.SL)
	surface.DrawTexturedRect(x - s, y, s, h)
	surface.SetMaterial(MMD.SLU)
	surface.DrawTexturedRect(x - s, y - s, s, s)
	surface.SetMaterial(MMD.SRU)
	surface.DrawTexturedRect(x + w, y - s, s, s)
	surface.SetMaterial(MMD.SRD)
	surface.DrawTexturedRect(x + w, y + h, s, s)
	surface.SetMaterial(MMD.SLD)
	surface.DrawTexturedRect(x - s, y + h, s, s)
end

function MMD.DrawChildrenShadows(panel, parent)
	local children = parent and panel.MasterPanel.Items or panel:GetChildren()

	for k, v in pairs(children) do
		local x, y, w, h = v:GetBounds()
		local sw = v.shadow or 6
		MMD.DrawShadow(x, y, w, h, sw, v:GetAlpha())
	end
end

function MMD.ColorAlpha(cl, alfa)
	local color = table.Copy(cl)
	color.a = alfa
	return color
end

function MMD.LCircle(x, y, radius, seg, start, ending)
	local cir = {}

	cir[1] = {
		x = x,
		y = y,
		u = 0.5,
		v = 0.5
	}

	for i = seg, 0, -1 do
		local a = math.rad((i / seg) * 360)
		local s1 = start / 360 * 6.2831853
		local s2 = ending / 360 * 6.2831853

		if s1 > s2 then
			s1, s2 = s2, s1
		end

		if a < s2 and a > s1 then
			table.insert(cir, {
				x = x - math.sin(a) * radius,
				y = y - math.cos(a) * radius,
				u = math.sin(a) / 2 + 0.5,
				v = math.cos(a) / 2 + 0.5
			})
		end
	end

	surface.DrawPoly(cir)
end

function MMD.DrawCircle(posx, posy, radius, color, seg, mat)
	local poly = {}
	local v = 40

	if seg then
		v = seg
	end

	for i = 0, v do
		poly[i + 1] = {
			x = math.sin(-math.rad(i / v * 360)) * radius + posx,
			y = math.cos(-math.rad(i / v * 360)) * radius + posy,
			u = math.sin(-math.rad(i / v * 360)) / 2 + 0.5,
			v = math.cos(-math.rad(i / v * 360)) / 2 + 0.5
		}
	end

	if mat then
		surface.SetMaterial(Material(mat))
	else
		draw.NoTexture()
	end

	surface.SetDrawColor(color)
	surface.DrawPoly(poly)
end

local blur = Material("pp/blurscreen")

function MMD.Blur(panel, inn, density, alpha, back_alpha, w, h)
	local x, y = panel:LocalToScreen(0, 0)
	surface.SetDrawColor(255, 255, 255, alpha)
	surface.SetMaterial(blur)

	for i = 1, 3 do
		blur:SetFloat("$blur", (i / inn) * density)
		blur:Recompute()
		render.UpdateScreenEffectTexture()

		if w and h then
			render.SetScissorRect(-x, -y, x + w, y + h, true)
			surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
			render.SetScissorRect(0, 0, 0, 0, false)
		else
			surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
		end
	end

	draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, back_alpha))
end

function MMD.GetRankIcon(path, url)
	if url then
		return MMD.ImgLib.GetMaterial(path)
	else
		return Material(path, "smooth noclamp")
	end
end

MMD.ImgLib = {}
MMD.ImgLib.Images = {}
MMD.ImgLib.PreCacheStarted = {}
MMD.ImgLib.NoMaterial = Material("mmd/icons/download-circle.png", "smooth noclamp")

function MMD.ImgLib.GetMaterial(url)
	local crc = util.CRC(url) .. ".png"
	if MMD.ImgLib.Images[crc] then return MMD.ImgLib.Images[crc] end

	if (file.Exists("mmd_imgs/" .. crc, "DATA")) then
		MMD.ImgLib.Images[crc] = Material("data/mmd_imgs/" .. crc, "smooth noclamp")

		return MMD.ImgLib.Images[crc]
	else
		return MMD.ImgLib.PreCacheMaterial(url, crc)
	end
end

function MMD.ImgLib.PreCacheMaterial(url, crc)
	if not crc then
		crc = util.CRC(url) .. ".png"
	end

	if not file.Exists("mmd_imgs", "DATA") then
		file.CreateDir("mmd_imgs")
	end

	if not MMD.ImgLib.PreCacheStarted[crc] then
		MMD.ImgLib.PreCacheStarted[crc] = true

		http.Fetch(url, function(body, size, headers, code)
			if (body:find("^.PNG")) then
				file.Write("mmd_imgs/" .. crc, body)
				MMD.ImgLib.Images[crc] = Material("data/mmd_imgs/" .. crc, "smooth noclamp")

				return MMD.ImgLib.Images[crc]
			else
				print("Image is not a PNG, url - " .. url)
			end
		end, function()
			print("Failed to get image, url - " .. url)
		end)
	end

	return MMD.ImgLib.NoMaterial
end