-- "addons\\gmodlamd\\lua\\mmd\\core\\sh_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
print(1)