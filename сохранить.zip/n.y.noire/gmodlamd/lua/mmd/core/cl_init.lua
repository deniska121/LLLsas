-- "addons\\gmodlamd\\lua\\mmd\\core\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
﻿local donate_cat = {
	[1] = {Color(255, 183, 0), Color(255, 150, 0)},
	[2] = {Color(54, 152, 237), Color(0, 108, 198)},
	[3] = {Color(77, 35, 255), Color(55, 25, 183)},
	[4] = {Color(180, 35, 255), Color(138, 25, 183)},
	[5] = {Color(250, 30, 30), Color(205, 25, 25)},
}

local donate_cat_price = {
	[1] = 200,
	[2] = 500,
	[3] = 1000,
	[4] = 3100,
}

local star_mat = Material("gmodla/star2.png", "smooth")
local gc_mat = Material("gmodla/gc.png", "smooth")

function MMD.OpenF4Menu(page)
	if MMD.F4Menu then return end
	local mScrW = ScrW() - ScrW() / 8
	local mScrH = ScrH() - ScrH() / 6
	local ply = LocalPlayer()
	--local donate_text = "Наш проект, как все, нуждается в материальной помощи. Благодаря вашей поддержке мы можем спокойно арендовать оборудование для игровых серверов и совершенствовать проект в целом.\nИменно по этим причинам мы предоставляем за ваши пожертвования особые донат баллы на игровом сервере для вас.\n \nЧтобы получить донат баллы, нажмите кнопку 'Пожертвования проекту'.\n \nЗеленая кнопка выше отвечает за обновление баланса баллов. Нажмите на неё сразу после пополнения и ожидать поступления в течении 1-10 минут. Если по истечению времени донат не пришел, либо Вы уже перезашли, попробуйте воспользоваться кнопкой и подождать снова.\nВ противном случае, обратитесь в ЛС группы ВК: https://vk.com/gmodla"
	local Main = vgui.Create("MMDMultyPanel")
	Main:SetSize(mScrW, mScrH)
	Main:Center()
	Main:MakePopup()
	Main:SetDraggable(true)

	function Main:OnClose()
		MMD.F4Menu = nil
	end

	MMD.F4Menu = Main
	Main.butts = {}

	Main.DeselectButts = function(self)
		MMD.F4Menu.UpdateINV = nil

		for k, v in pairs(Main.Menu.ScrP:GetItems()) do
			if v and v:IsValid() and v ~= self then
				v.hovered = false
			end
		end
	end

	Main.Think = function(self)
		if (input.IsKeyDown(KEY_F4) or input.IsKeyDown(KEY_ESCAPE)) and self:GetAlpha() == 255 then
			self:AlphaTo(0, 0.4, 0, function()
				self:Close()
			end)
		end
	end

	local menus = {}
	local wallet = vgui.Create("DPanel", Main.Menu)
	wallet:SetSize(230, 30)
	wallet:SetPos(8, Main.Menu:GetTall() - 70)

	wallet.Paint = function(s, w, h)
		draw.SimpleText("Деньги: " .. string.Comma(ply:getDarkRPVar("money") or 0), "M_Roboto", 3, h / 2, MMD.Text["s"], TEXT_ALIGN_LEFT, 1)
	end

	local slider = MMD.ThemeSlider(Main.Menu, 10, 50, Main.Menu:GetWide() - 20, 25, "Темная тема", "mmd_theme_new", 2, "mmd_theme_swap")
	slider:DockPadding(10, 5, 10, 0)
	slider:DockMargin(10, 5, 10, 10)
	slider:Dock(BOTTOM)

	Main.butts["main"] = MMD.MenuIconButton(Main.Menu.ScrP, 254, 50, "Главная", MMD.Icons48.home, 32, function(self)
		Main.DeselectButts(self)
		menus["main"]()
	end)

	-- Main.butts["job"] = MMD.MenuIconButton(Main.Menu.ScrP, 254, 50, "Работы", MMD.Icons48.briefcase, 32, function(self)
	-- 	Main.DeselectButts(self)
	-- 	menus["job"]()
	-- end)

	-- Main.butts["market"] = MMD.MenuIconButton(Main.Menu.ScrP, 254, 50, "Маркет", MMD.Icons48.cart, 32, function(self)
	-- 	Main.DeselectButts(self)
	-- 	menus["market"]()
	-- end)

	-- Main.butts["donate"] = MMD.MenuIconButton(Main.Menu.ScrP, 254, 50, "Донат", MMD.Icons48.lacoin, 32, function(self)
	-- 	menus["donate"]()
	-- 	Main.DeselectButts(self)
	-- end)

	--Main.butts["access"] = MMD.MenuIconButton(Main.Menu.ScrP, 254, 50, "Аксессуары", MMD.Icons48.shopping, 32, function(self) menus["access"]() Main.DeselectButts(self) end)
	-- local citizen_ic
	-- local police_ic
	-- local pet_ic

	if game.GetMap() == "rp_rockford_v2b" then
		citizen_ic = "gmodla/f4/cate/citizen_msk.png"
		police_ic = "gmodla/f4/cate/police_msk.png"
	else
		if game.GetMap() == "rp_downtown_tits_v1" or game.GetMap() == "rp_bangclaw" then
			pet_ic = "gmodla/f4/cate/pets_tky.png"
		else
			pet_ic = "gmodla/f4/cate/pets.png"
		end

		citizen_ic = "gmodla/f4/cate/citizen.png"
		police_ic = "gmodla/f4/cate/police.png"
	end

	menus["main"] = function()
		Main.Canvas:Clear()
		local m_panel = MMD.SubListPanel(Main.Canvas, 1.5, 1, 250, 200, "Информация", true, true)
		m_panel.ScrP:SetPadding(7)
		m_panel.ScrP:SetSpacing(5)
		local av = vgui.Create("AvatarImage")
		av:SetSize(128, 128)
		av:SetPlayer(ply, 128)
		m_panel.ScrP:AddItem(av)
		local panel = vgui.Create("DPanel")

		panel.StaticScale = {
			w = 1.3,
			fixed_h = 1,
			minw = 250,
			minh = 128
		}

		panel.Paint = function(self, w, h)
			w = draw.SimpleText(ply:FullName(), "M_Roboto27", 5, 5, MMD.Patern.MainColor["p"], TEXT_ALIGN_LEFT)
			draw.SimpleText(" | " .. ply:SteamName(), "M_Roboto27", 5 + w, 5, MMD.Text["d"], TEXT_ALIGN_LEFT)
			w = draw.SimpleText("Деньги: " .. string.Comma(ply:getDarkRPVar("money") or 0), "M_Roboto", 5, 38, MMD.Text["l"], TEXT_ALIGN_LEFT)
			local salary = ply:getDarkRPVar("salary") or 0

			if salary > 0 then
				draw.SimpleText(" + " .. string.Comma(salary), "M_Roboto", 5 + w, 38, MMD.Text["d"], TEXT_ALIGN_LEFT)
			end

			draw.SimpleText("Работа: " .. team.GetName(ply:Team()), "M_Roboto", 5, 64, MMD.Text["l"], TEXT_ALIGN_LEFT)

			if ply:GetNWString("GangName") ~= "" then
				draw.SimpleText("Банда: " .. ply:GetNWString("GangName"), "M_Roboto", 5, 90, MMD.Text["l"], TEXT_ALIGN_LEFT)
			end
		end

		m_panel.ScrP:AddItem(panel)

		local l_panel = MMD.SubListPanel(m_panel.ScrP, 2, 1.3, 220, 400, "Быстрые команды", true)
		l_panel.ScrP:SetPadding(5)
		l_panel.ScrP:SetSpacing(5)

		MMD.TextEntry(l_panel.ScrP, "Передать деньги игроку", nil, nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "/give " .. self:GetValue())
		end, true)

		MMD.TextEntry(l_panel.ScrP, "Бросить деньги", nil, nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "/moneydrop " .. self:GetValue())
		end, true)

		MMD.TextEntry(l_panel.ScrP, "Сменить имя", nil, nil, nil, 250, 35, function(self)
			RunConsoleCommand("darkrp", "rpname", self:GetValue())
		end, true)

		MMD.TextEntry(l_panel.ScrP, "Уникальная работа", nil, nil, nil, 250, 35, function(self)
			RunConsoleCommand("darkrp", "job", self:GetValue())
		end, true)

		MMD.Button(l_panel.ScrP, "Бросить оружие", nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "/drop")
		end)

		MMD.Button(l_panel.ScrP, "Продать все двери", nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "/unownalldoors")
		end)

		MMD.Button(l_panel.ScrP, "Меню банды", nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "/gangmenu")
		end)

		MMD.Button(l_panel.ScrP, "Законы", nil, nil, 250, 35, function(self)
			RunConsoleCommand("law")
		end)

		MMD.TextPanel(l_panel.ScrP, "Уволить игрока", nil, nil, 250, 30)
		local mcd = MMD.ComboBox(l_panel.ScrP, nil, nil, 250, 30, "Выберете игрока")

		for k, v in pairs(player.GetAll()) do
			if v ~= LocalPlayer() then
				mcd:AddChoice(v:FullName(), v:UserID())
			end
		end

		MMD.TextEntry(l_panel.ScrP, "Причина", nil, nil, nil, 250, 30, function(self)
			local _, data = mcd:GetSelected()
			if not data then return end
			RunConsoleCommand("darkrp", "demote", data, self:GetValue())
		end, true)

		MMD.TextPanel(l_panel.ScrP, "Дополнительные", nil, nil, 250, 25)

		MMD.TextEntry(l_panel.ScrP, "Написать администратору", nil, nil, nil, 250, 35, function(self)
			RunConsoleCommand("say", "@ " .. self:GetValue())
		end, true)

		local url_p = MMD.SubListPanel(m_panel.ScrP, 2, 1.3, 150, 400, "Полезные ссылки", true)

		MMD.MenuIconButton(url_p.ScrP, 254, 50, "Наш веб-сайт", MMD.Icons48.web, 32, function(self)
			gui.OpenURL("https://gmodla.ru")
		end, nil, true)

		MMD.MenuIconButton(url_p.ScrP, 254, 50, "Группа steam", MMD.Icons48.steam, 32, function(self)
			gui.OpenURL("https://steamcommunity.com/groups/gmodLAproject")
		end, nil, true)

		MMD.MenuIconButton(url_p.ScrP, 254, 50, "Группа VK", MMD.Icons48.vk, 32, function(self)
			gui.OpenURL("https://vk.com/gmodla")
		end, nil, true)

		MMD.MenuIconButton(url_p.ScrP, 254, 50, "Discord", MMD.Icons48.discord, 32, function(self)
			gui.OpenURL("https://discord.com/invite/rFaYUtn")
		end, nil, true)

		MMD.MenuIconButton(url_p.ScrP, 254, 50, "Контент", MMD.Icons48.download, 32, function(self)
			gui.OpenURL("https://steamcommunity.com/sharedfiles/filedetails/?id=1552876136")
		end, nil, true)

		inv = MMD.SubListPanel(Main.Canvas, 3, 1, 220, 400, "Инвентарь", true)
		inv.ScrP:SetPadding(5)
		inv.ScrP:SetSpacing(5)
		McINV.InventoryUI = inv.ScrP
		inv.ScrP.Update = function()
			inv.ScrP:Clear()

			inv.text = "Инвентарь " .. McINV.GetSpace(McINV.inv) .. " / " .. LocalPlayer():GetDefaultSpace() .. " кг"

			for type,ilist in pairs(McINV.inv) do
				for id, item in pairs(ilist) do
					local ent = McINV.GetItem(type, item.class, item)
					McINV.InventoryItem(inv.ScrP, ent, type, item, function(self)
						RunConsoleCommand("Inventory.Drop", type, item.class, id)
					end)
				end
			end
		end

		inv.ScrP:Update()
	end

	menus["access"] = function()
		Main.Canvas:Clear()
		local l_panel = MMD.SubListPanel(Main.Canvas, 1.5, 1, 250, 600, "Каталог услуг", true)
		l_panel.ScrP:EnableHorizontal(true)
		l_panel.ScrP:SetPadding(5)
		l_panel.ScrP:SetSpacing(5)
		l_panel.ScrP.IgnoreVbar = false
		local j_panel = MMD.SubListPanel(Main.Canvas, 3, 1, 250, 600, "Ваш профиль ", true)
		j_panel.ScrP:SetPadding(5)
	end

	if page and menus[page] then
		Main.butts[page].hovered = true
		menus[page]()
	else
		Main.butts["main"].hovered = true
		menus["main"]()
	end

	if page == "case" then
		Main.DeselectButts()
		Main.butts["donate"].hovered = true
		menus["donate"](true)
	end

	MMD.F4Menu.menus = menus
end

function MMD.CaseOpener(cid)
	if not MMD.F4Menu then return end
	local item = BUC2.ITEMS[cid]
	local panel, child = MMD.WorkSpacePanel(MMD.F4Menu, item.name1, 1.5, 1.2, true)
	local icon

	timer.Simple(0.1, function()
		surface.PlaySound("box/drop.wav")
	end)

	local cfg_list = vgui.Create("DPanel", child)
	cfg_list:SetSize(child:GetWide() - 20, child:GetTall() - 60)
	cfg_list:DockMargin(5, 50, 0, 5)
	cfg_list:Dock(FILL)
	cfg_list.anim = 0
	icon = vgui.Create("DModelPanel", cfg_list)
	icon:Dock(FILL)
	icon:SetFOV(55)
	icon:SetModel(item.model)
	icon:SetAnimated(true)
	icon:SetLookAt(Vector(0, 0, 20))
	icon.Entity:SetAngles(Angle(0, 270, 0))
	icon.Entity:ResetSequence("drop")
	icon.Entity:SetBodygroup(2, 1)
	icon.Entity:SetBodygroup(3, 1)
	icon.Entity:SetPos(Vector(-10, 0, 10))

	function icon:LayoutEntity(ent)
		if (self.bAnimated) then
			self:RunAnimation()
		end
	end

	local p_w, p_h = child:GetWide() - 20, child:GetTall() / 3
	local item_s = 150

	if p_w > 800 then
		item_s = (p_w - 50) / 5
	end

	local clist = MMD.PanelList(cfg_list, 10, 50, p_w, p_h, true, 5, 0)
	clist:DockMargin(10, 0, 10, 10)
	clist:Dock(BOTTOM)

	for k, v in pairs(item.items) do
		local button = MMD.CreateINVModule(v, BUC2.ITEMS[v], clist, function() end)
		button.StaticScale = nil
		button.SmallFond = true
		button:SetSize(item_s, item_s + 5)
	end

	local sel_but = MMD.Button(child, "Открыть", 10, 50, child:GetWide() - 20, 35, function(self)
		if self.blocked then return end
		self.blocked = true

		timer.Simple(2.2, function()
			if panel and IsValid(panel) then
				panel:Remove()
			end
		end)

		net.Start("gmodlaBeginSpin")
		net.WriteString(cid)
		net.SendToServer()
		surface.PlaySound("box/open.wav")
		icon.Entity:ResetSequenceInfo()
		icon.Entity:SetSequence("open")
		icon.Entity:SetCycle(0)
		icon.Entity:SetPlaybackRate(0.85)
	end)

	cfg_list.Paint = function()
		if input.IsKeyDown(KEY_ENTER) then
			if not IsValid(sel_but) then return end
			if sel_but.blocked then return end
			sel_but.blocked = true

			timer.Simple(2.2, function()
				if panel and IsValid(panel) then
					panel:Remove()
				end
			end)

			net.Start("gmodlaBeginSpin")
			net.WriteString(cid)
			net.SendToServer()
			surface.PlaySound("box/open.wav")
			icon.Entity:ResetSequenceInfo()
			icon.Entity:SetSequence("open")
			icon.Entity:SetCycle(0)
			icon.Entity:SetPlaybackRate(0.85)
		end
	end

	if not ub_hasItem(item.requiredKey) then
		sel_but.blocked = true
		sel_but:SetText("Нет ключа")
	end

	sel_but:DockMargin(10, 0, 10, 10)
	sel_but:Dock(BOTTOM)
end

net.Receive("gmodlaStartClientSpinAnimation", function()
	if not MMD.F4Menu then return end
	local cid = net.ReadString()
	local item = BUC2.ITEMS[cid]
	local panel, child = MMD.WorkSpacePanel(MMD.F4Menu, item.name1, 2, 2, true)
	local col, icon = item.color or MMD.Theme["d"], nil
	local sh, s, l = ColorToHSL(col)
	local col2 = HSLToColor(sh, s, l - 0.1)

	if item.icon then
		icon = Material(item.icon, "smooth")
	end

	local cfg_list = vgui.Create("DPanel", child)
	cfg_list:SetSize(child:GetWide() - 20, child:GetTall() - 60)
	cfg_list:DockPadding(5, 50, 0, 5)
	cfg_list:DockMargin(5, 50, 0, 5)
	cfg_list:Dock(FILL)
	cfg_list.anim = 0
	surface.PlaySound("mp_bonus_start_02.wav")

	local sel_but = MMD.Button(child, "Закрыть", 10, 50, child:GetWide() - 20, 35, function()
		panel.Close()
	end)

	cfg_list.Paint = function(self, w, h)
		self.anim = Lerp(FrameTime() * 6, self.anim, 1)
		local size = h / 1.5
		surface.SetDrawColor(col2)
		surface.SetMaterial(star_mat)
		surface.DrawTexturedRectRotated(w / 2, h / 2 - 10, size + size / 2, size + size / 2, -CurTime() * 25 % 360)
		surface.SetDrawColor(col)
		surface.DrawTexturedRectRotated(w / 2, h / 2 - 10, size, size, CurTime() * 25 % 360)
		MMD.DrawTexturedRect(w / 2 - size / 2, h / 2 - size / 2 - 10, size, size, icon or MMD.IconsAll.no_icon, icon and color_white or MMD.Theme["d"])
		local size2 = self.anim * w * 2
		MMD.DrawTexturedRect(w / 2 - size2 / 2, h / 2 - size2 / 2, size2, size2, gc_mat, Color(255, 255, 255, 255 - self.anim * 255))
		draw.DrawText(item.name1, "M_Roboto32", w / 2, h - 32, MMD.Text["l"], TEXT_ALIGN_CENTER)

		if input.IsKeyDown(KEY_ENTER) then
			panel.Close()
		end
	end

	sel_but:DockPadding(10, 0, 10, 0)
	sel_but:DockMargin(10, 0, 10, 10)
	sel_but:Dock(BOTTOM)
end)

net.Receive("LA.Donate.Note", function(length, ply)
	if not MMD.F4Menu then return end
	local success = net.ReadBool()
	local item, panel, child

	local text = {"Покупка прервана", "У вас недостаточно донат баллов, пожалуйста, пополните баллы и повторите снова"}

	if success then
		item = net.ReadInt(32)
		item = CreditShop_Items[item]

		text = {"Покупка совершена", "Благодарим вас за покупку!"}

		panel, child = MMD.WorkSpacePanel(MMD.F4Menu, text[2], 2, 2, true)
	else
		panel, child = MMD.WorkSpacePanel(MMD.F4Menu, text[1], 3, 4, true)
	end

	if item then
		local mat
		local l_cat = 1

		for k, v in pairs(donate_cat_price) do
			if item.Price >= v then
				l_cat = k + 1
			end
		end

		if item.IconImg then
			mat = Material(item.IconImg, "smooth")
		end

		local cfg_list = vgui.Create("DPanel", child)
		cfg_list:SetSize(child:GetWide() - 20, child:GetTall() - 60)
		cfg_list:DockPadding(5, 50, 0, 5)
		cfg_list:DockMargin(5, 50, 0, 5)
		cfg_list:Dock(FILL)
		cfg_list.anim = 0

		cfg_list.Paint = function(self, w, h)
			self.anim = Lerp(FrameTime() * 6, self.anim, 1)
			local size = h / 1.5
			surface.SetDrawColor(donate_cat[l_cat][2])
			surface.SetMaterial(star_mat)
			surface.DrawTexturedRectRotated(w / 2, h / 2 - 10, size + size / 2, size + size / 2, -CurTime() * 25 % 360)
			surface.SetDrawColor(donate_cat[l_cat][1])
			surface.DrawTexturedRectRotated(w / 2, h / 2 - 10, size, size, CurTime() * 25 % 360)

			if mat then
				MMD.DrawTexturedRect(w / 2 - size / 2, h / 2 - size / 2 - 10, size, size, mat, color_white)
			end

			local size2 = self.anim * w * 2
			MMD.DrawTexturedRect(w / 2 - size2 / 2, h / 2 - size2 / 2, size2, size2, gc_mat, Color(255, 255, 255, 255 - self.anim * 255))
			draw.DrawText(item.Name, "M_Roboto32", w / 2, h - 32, MMD.Text["l"], TEXT_ALIGN_CENTER)
		end

		local snd = donate_cat[l_cat][3] or "mp_bonus_start_02.wav"
		surface.PlaySound(snd)
	else
		local cfg_list = MMD.PanelList(child, 10, 50, child:GetWide() - 20, child:GetTall() - 60, false, 5, 0)
		MMD.RichText(cfg_list, text[2], nil, nil, 250, 200, "M_Roboto22")
	end

	local sel_but = MMD.Button(child, "Закрыть", 10, 50, child:GetWide() - 20, 35, function()
		panel.Close()
	end)

	sel_but:DockPadding(10, 0, 10, 0)
	sel_but:DockMargin(10, 0, 10, 10)
	sel_but:Dock(BOTTOM)
end)

net.Receive("MMD.OpenF4", function()
	local page = net.ReadString()
	MMD.OpenF4Menu(page)
end)

concommand.Add("gmodla_f4_old", MMD.OpenF4Menu)