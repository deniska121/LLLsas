-- "addons\\gmodlamd\\lua\\mmd\\derma\\mmdmultypanel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local PANEL = {}

function PANEL:Init()
    self:SetSizable(true)
    self:SetMinWidth(800)
    self:SetMinHeight(600)
    self:SetAlpha(1)
    self:AlphaTo(255, 0.3)
    self.Limited = false

    self.WorkSpace = {
        x = 0,
        y = 70,
        w = 0,
        h = 0
    }

    self.WorkComponents = {}
    self.cfade = 0

    self.clsBut = MMD.IconButton(self, MMD.Icons48.close_box, self:GetWide() - 25, 0, 20, nil, MMD.GColors.red, function()
        if self.OnPress then
            self.OnPress()

            return
        end

        self:AlphaTo(0, 0.4, 0, function()
            self:Close()
        end)
    end)

    self.Canvas = vgui.Create("MMDPanelList", self)
    self.Canvas:SetSize(self:GetWide(), self:GetTall() - 75)
    self.Canvas:SetPos(0, 70)
    self.Canvas:EnableVerticalScrollbar()
    self.Canvas:EnableHorizontal(true)
    self.Canvas:SetSpacing(10)
    self.Canvas:SetPadding(10)
    self.Canvas.IgnoreVbar = false

    self.Canvas.pnlCanvas.Paint = function(s)
        MMD.DrawChildrenShadows(s, true)
    end

    self.Menu = vgui.Create("DPanel", self)
    self.Menu:SetSize(250, self:GetTall() - 75)
    self.Menu:SetPos(0, 70)
    self.Menu.Closed = false

    self.Menu.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w - 5, h, MMD.Theme["s"])
        surface.SetDrawColor(255, 255, 255, 255)
        surface.SetMaterial(MMD.SR)
        surface.DrawTexturedRect(w - 5, 0, 5, h)
    end

    self.Menu.ScrP = vgui.Create("MMDPanelList", self.Menu)
    self.Menu.ScrP:SetSize(254, self.Menu:GetTall() - 50)
    self.Menu.ScrP:SetPos(0, 0)
    self.Menu.ScrP:DockPadding(0, 0, 5, 50)
    self.Menu.ScrP:DockMargin(0, 0, 5, 50)
    self.Menu.ScrP:Dock(FILL)
    self.Menu.ScrP:EnableVerticalScrollbar()
    self.Menu.ScrP:EnableHorizontal(false)
    self.Menu.ScrP:SetSpacing(0)

    self.menuBut = MMD.IconButton(self, MMD.Icons48.menu, 5, 29, 32, Color(255, 255, 255), Color(255, 255, 255), function()
        if self.menuBut:IsEnabled() and self.Limited then
            if self.menuBut.Extended then
                self.Menu:MoveTo(-250, 70, 0.3)
                self.menuBut:MoveTo(5, 29, 0.3)
                self.logo:MoveTo(60, 21, 0.3)
            else
                self.Menu:MoveTo(0, 70, 0.3)
                self.menuBut:MoveTo(210, 29, 0.3)
                self.logo:MoveTo(290, 21, 0.3)
            end

            self.menuBut.Extended = not self.menuBut.Extended
        end
    end)

    --self.menuBut:SetAlpha(0)
    self.menuBut.Extended = false
    self.logo = vgui.Create("DImage", self)
    self.logo:SetPos(60, 21)
    self.logo:SetSize(119, 48)
    self.logo:SetMaterial(MMD.IconsAll.logo)
end

function PANEL:OnModified()
end

function PANEL:AddToWorkSpace(panel)
    panel:SetParent(self)
    panel:SetSize(self.WorkSpace.w, self.WorkSpace.h)
    panel:SetPos(self.WorkSpace.x, self.WorkSpace.y)
    local id = table.insert(self.WorkComponents, panel)

    panel.OnRemove = function()
        self.WorkComponents[id] = nil
    end
end

function PANEL:Paint(w, h)
    if self:GetAlpha() < 255 then
        self.cfade = Lerp(FrameTime() * 5, self.cfade, w)
        MMD.DrawCircle(w / 2, h, self.cfade, MMD.Theme["m"])
    end

    draw.RoundedBox(0, 0, 0, w, h, MMD.Theme["m"])
    draw.RoundedBox(0, 0, 0, w, 20, MMD.Patern.MainColor["8"])
    draw.RoundedBox(0, 0, h - 5, w, 5, MMD.Patern.MainColor["8"])
    draw.RoundedBox(0, 0, 20, w, 50, MMD.Theme["d"])
    MMD.DrawTexturedRect(w - 89, 20, 89, 50, "gmodla/f4/cate/plus.png", Color(255, 255, 255))
    surface.SetMaterial(MMD.SD)
    surface.DrawTexturedRect(0, 70, w, 5)
end

function PANEL:PerformLayout()
    local Wide = self:GetWide()
    local Tall = self:GetTall()
    self.clsBut:SetPos(Wide - 25, 0)

    if Wide < 1000 then
        self.Limited = true
        self.Canvas:SetSize(self:GetWide(), self:GetTall() - 75)
        self.Canvas:SetPos(0, 70)

        if self.Menu then
            self.Menu:SetSize(250, self:GetTall() - 70)

            if not self.Menu.Closed then
                self.Menu:MoveTo(-250, 70, 0.3)
                self.Menu.Closed = true
            end

            if not self.menuBut:IsEnabled() then
                self.menuBut:SetEnabled(true)
                self.menuBut:AlphaTo(255, 0.3, 0.1)
                self.menuBut:MoveTo(5, 29, 0.3)
                self.logo:MoveTo(60, 21, 0.2)
                self.menuBut.Extended = false
            end
        end
    else
        self.Limited = false

        if not self.Menu then
            self.Canvas:SetSize(self:GetWide(), self:GetTall() - 75)
            self.Canvas:SetPos(0, 70)
        end

        if self.Menu then
            self.Menu:SetSize(250, self:GetTall() - 70)
            self.Canvas:SetSize(self:GetWide() - 250, self:GetTall() - 75)
            self.Canvas:SetPos(250, 70)

            if self.Menu.Closed then
                self.Menu:MoveTo(0, 70, 0.3)
                self.Menu.Closed = false
            end

            if self.menuBut:IsEnabled() then
                self.menuBut:SetEnabled(false)
                self.menuBut:AlphaTo(0, 0.3)
                self.logo:MoveTo(10, 21, 0.3)
            end
        end
    end

    self.WorkSpace = {
        x = 0,
        y = 20,
        w = Wide,
        h = Tall - 20
    }

    if self.WorkComponents and #self.WorkComponents > 0 then
        for i = 1, #self.WorkComponents do
            local panel = self.WorkComponents[i]

            if panel and ispanel(panel) then
                panel:SetSize(self.WorkSpace.w, self.WorkSpace.h)
                panel:SetPos(self.WorkSpace.x, self.WorkSpace.y)
                panel:InvalidateLayout()
            end
        end
    end

    if self.Menu then
        self.Menu:InvalidateLayout()
    end
end

derma.DefineControl("MMDMultyPanel", "A Panel that organises multy panels", PANEL, "MMDSimpleFrame")