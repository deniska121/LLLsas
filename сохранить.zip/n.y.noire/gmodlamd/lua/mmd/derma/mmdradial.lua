-- "addons\\gmodlamd\\lua\\mmd\\derma\\mmdradial.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
local MAT_BLUR = Material("pp/blurscreen.png", "noclamp")

local Panel = {}

function Panel:Init()
	self.actions = {}
	self:SetCursor( "blank" )
	self:Build()
end

function Panel:Build()
	if self.m_tblButtons then
		for k, v in pairs(self.m_tblButtons) do
			if IsValid(v) then
				v:Remove()
			end
		end
	end

	self.m_strSndHover = "msd/ui/click.wav"
	self.m_matBlur = MAT_BLUR
	self.m_texWhite = surface.GetTextureID("vgui/white")
	self.m_int360 = math.pi * 2
	self.m_intCurAngle = 90
	self.m_intTargetAngle = 90
	self:InitializeButtons()
end

function Panel:InitializeButtons()
	self.m_tblButtons = {}

	for k, v in ipairs(self.actions) do
		if v[4] and not v[4]() then continue end
		self.m_tblButtons[k] = {
			Name = v[1],
			Cmd = v[2],
			icon = v[3],
		}
	end

	local count = #self.m_tblButtons
	self.m_intBtnAng = math.pi * 2 / count

	for k, v in pairs(self.m_tblButtons) do
		v.Angle = (k - 2) * self.m_intBtnAng - math.pi / 2

		while v.Angle < 0 do
			v.Angle = v.Angle + math.pi * 2
		end
	end
end

local MOUSE_CHECK_DIST = 120
local MOUSE_CUR_DIST = 0

function Panel:Think()
	local mx, my = gui.MousePos()
	local cx, cy = ScrW() / 2, ScrH() / 2
	MOUSE_CUR_DIST = math.Distance(mx, my, cx, cy)

	if MOUSE_CUR_DIST > 48 then
		local norm = Vector(mx - cx, cy - my, 0):GetNormal()
		self.m_intTargetAngle = norm:Angle().y

		if MOUSE_CUR_DIST > MOUSE_CHECK_DIST then
			gui.SetMousePos(cx + norm.x * MOUSE_CHECK_DIST, cy - norm.y * MOUSE_CHECK_DIST)
		end
	end

	self.m_intCurAngle = math.ApproachAngle(self.m_intCurAngle, self.m_intTargetAngle, 55 * (math.AngleDifference(self.m_intCurAngle, self.m_intTargetAngle) / 180))
	self.m_intCurSelection, _ = self:GetCurrentSelection()

	if self.m_intLastSelection and self.m_intCurSelection ~= self.m_intLastSelection then
		MSD.PlaySnd(self.m_strSndHover)
	end

	self.m_intLastSelection = self.m_intCurSelection

	if self.KeyThink then self.KeyThink() end
end

function Panel:GetCurrentSelection()
	local selectionAngle, selection = -1, nil
	local selectedAng = -1

	for k, v in pairs(self.m_tblButtons) do
		local ang = math.deg(v.Angle - self.m_intBtnAng / 2)
		local diff = math.AngleDifference(self.m_intCurAngle, ang)

		if selectionAngle == -1 or diff < selectionAngle then
			selectionAngle = diff
			selection = k
			selectedAng = math.deg(v.Angle) + 180
		end
	end

	return selection, math.NormalizeAngle(selectedAng)
end

function Panel:BuildPoly(x, y, radius, count)
	self.m_tblCurrentPoly = {
		x = x,
		y = y,
		radius = radius,
		count = count
	}

	local delta = self.m_int360 / count
	local verts = {}

	for n = 0, self.m_int360, delta do
		local c, s = math.cos(n), math.sin(n)

		table.insert(verts, {
			x = x + c * radius,
			y = y + s * radius,
			u = 0.5 + c * 0.5,
			v = 0.5 + s * 0.5
		})
	end

	self.m_tblCurrentPoly.Verts = verts
end

function Panel:DrawCircle(x, y, radius, count)
	local cur = self.m_tblCurrentPoly

	if not cur or cur.x ~= x or cur.y ~= y or cur.radius ~= radius or cur.count ~= count then
		self:BuildPoly(x, y, radius, count)
	end

	if self.m_tblCurrentPoly and self.m_tblCurrentPoly.Verts then
		surface.SetTexture(self.m_texWhite)
		surface.DrawPoly(self.m_tblCurrentPoly.Verts)
	end
end

function Panel:PaintBackground(intW, intH)
	local bgRadius = intW / 2
	local bgPolyCount = 38

	render.ClearStencil()
	render.SetStencilEnable(true)
	render.SetStencilReferenceValue(1)
	render.SetStencilTestMask(1)
	render.SetStencilWriteMask(1)
	render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_NEVER)
	render.SetStencilFailOperation(STENCILOPERATION_REPLACE)
	render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
	render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
	surface.SetDrawColor(color_white)
	self:DrawCircle(intW - bgRadius, bgRadius, bgRadius, bgPolyCount)
	render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
	render.SetStencilFailOperation(STENCILOPERATION_KEEP)
	render.SetStencilPassOperation(STENCILOPERATION_KEEP)
	render.SetStencilZFailOperation(STENCILOPERATION_KEEP)
	surface.SetMaterial(self.m_matBlur)
	surface.SetDrawColor(color_white)
	for i = 0, 1, 0.33 do
		self.m_matBlur:SetFloat("$blur", 5 * i)
		self.m_matBlur:Recompute()
		render.UpdateScreenEffectTexture()
		local x, y = self:GetPos()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
	render.SetStencilEnable(false)
	surface.SetDrawColor(MSD.Theme.d)
	self:DrawCircle(intW - bgRadius, bgRadius, bgRadius, bgPolyCount)

	surface.SetDrawColor(MSD.Theme.d)
	self:DrawCircle(intW - bgRadius, bgRadius, bgRadius / 2, bgPolyCount)

end

function Panel:Paint(intW, intH)
	local sx, sy = intW / 2, intH / 2
	local center = intW / 2.66
	local mp = intW / 4
	self:PaintBackground(intW, intH)

	for k, v in pairs(self.m_tblButtons) do
		local sel = k == self.m_intCurSelection
		local ang = v.Angle
		local vx, vy = math.cos(ang), math.sin(ang)
		local x, y = sx - vx * center, sy + vy * (center - 1)
		local lx, ly = math.cos(ang + self.m_intBtnAng / 2), math.sin(ang + self.m_intBtnAng / 2)
		surface.SetDrawColor(MMD.Theme.l)
		surface.DrawLine(sx + lx * mp, sy + ly * mp, sx + lx * sx, sy + ly * sx)
		if v.icon then
			MSD.DrawTexturedRect(x - 24, y - 24, 48, 48, v.icon, sel and MMD.Patern.MainColor.p or MMD.Text.l)
		else
			draw.DrawText(v.Name, "MSDFont.22", x, y, sel and MMD.Patern.MainColor.p or MMD.Text.l, TEXT_ALIGN_CENTER)
		end
	end

	if self.m_intCurSelection then
		local but = self.m_tblButtons[self.m_intCurSelection]
		draw.DrawText(but.Name, "MSDFont.28", sx, sy - sy / 4, sel and MMD.Patern.MainColor.p or MMD.Text.l, TEXT_ALIGN_CENTER)
	end
end

function Panel:OnMousePressed(nmg)
	if nmg == 107 then
		local selection = self:GetCurrentSelection()
		local action = self.m_tblButtons[selection]

		if action then
			action.Cmd()
		end
	end
end

vgui.Register("MMD.RadialMenu", Panel, "EditablePanel")


local PANEL = {}

AccessorFunc(PANEL, "Min", "Min")
AccessorFunc(PANEL, "Max", "Max")
AccessorFunc(PANEL, "Value", "Value")
AccessorFunc(PANEL, "OldValue", "OldValue")
AccessorFunc(PANEL, "Percentage", "Percentage")
AccessorFunc(PANEL, "Desc", "Desc")
AccessorFunc(PANEL, "Animated", "Animated")

function PANEL:Init()
	self:SetSize(500, 32)
	self:SetMax(100)
	self:SetMin(0)
	self:SetValue(0)
end

function PANEL:SetValue(value)
	if self:GetAnimated() then
		self:SetOldValue(self:GetValue() or value)
	else
		self:SetOldValue(value)
	end
	self.Value = value
end

function PANEL:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, DarkRP.Hud.Patern["bgr"])

	if self:GetAnimated() then
		self:SetOldValue(Lerp(0.1, self:GetOldValue(), self:GetValue()))
	end

	local width = math.min(math.Round(w * (self:GetOldValue() - self:GetMin()) / (self:GetMax() - self:GetMin())), w)
	draw.RoundedBox(0, 2, 2, width-4, h-4, DarkRP.Hud.Patern["yellow"])
end

derma.DefineControl( "MProgressBar", "", PANEL)