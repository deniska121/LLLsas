-- "addons\\gmodlamd\\lua\\mmd\\derma\\mmdmenu.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
if SERVER then return end
local tblOpenMenus = {}

function RegisterDermaMenuForClose(dmenu)
	table.insert(tblOpenMenus, dmenu)
end

function MDermaMenu(parentmenu, parent)
	if (not parentmenu) then
		CloseDermaMenus()
	end

	local fade, cfade = 0, 0
	local dmenu = vgui.Create("MMD.DMenu", parent)
	dmenu.ShadowStatic = 0
	dmenu.ShadowInt = 1

	dmenu.Paint = function(self, w, h)
		surface.DisableClipping(true)

		if fade > 80 then
			MMD.DrawShadow(0, 0, w, h, (self.ShadowInt or 16), fade)
		end

		surface.DisableClipping(false)

		if fade < 250 then
			cfade = Lerp(FrameTime() * 5, cfade, w * 1.5)
			MMD.DrawCircle(w / 2, 0, cfade, MMD.Theme["l"])
		end

		fade = math.Round(math.Approach(fade, 255, 500 * FrameTime()))

		if fade > 200 then
			draw.RoundedBox(0, 0, 0, w, h, MMD.ColorAlpha(MMD.Theme["d"], fade))
		end

		if extrapaint then
			extrapaint(self, w, h)
		end

		if self.ShadowStatic > 0 then
			self.ShadowInt = self.ShadowStatic
		else
			if self.pressed then
				self.ShadowInt = Lerp(FrameTime() * 5, self.ShadowInt, 8)
			else
				self.ShadowInt = Lerp(FrameTime() * 5, self.ShadowInt, 1)
			end
		end
	end

	return dmenu
end

function CloseDermaMenus()
	for k, dmenu in pairs(tblOpenMenus) do
		if (IsValid(dmenu)) then
			dmenu:SetVisible(false)

			if (dmenu:GetDeleteSelf()) then
				dmenu:Remove()
			end
		end
	end

	tblOpenMenus = {}
	hook.Run("CloseDermaMenus")
end

local function DermaDetectMenuFocus(panel, mousecode)
	if (IsValid(panel)) then
		if (panel.m_bIsMenuComponent) then return end

		return DermaDetectMenuFocus(panel:GetParent(), mousecode)
	end

	CloseDermaMenus()
end

hook.Add("VGUIMousePressed", "MatDMenuDetectMenuFocus", DermaDetectMenuFocus)
local PANEL = {}
AccessorFunc(PANEL, "m_bBorder", "DrawBorder")
AccessorFunc(PANEL, "m_bDeleteSelf", "DeleteSelf")
AccessorFunc(PANEL, "m_iMinimumWidth", "MinimumWidth")
AccessorFunc(PANEL, "m_bDrawColumn", "DrawColumn")
AccessorFunc(PANEL, "m_iMaxHeight", "MaxHeight")
AccessorFunc(PANEL, "m_pOpenSubMenu", "OpenSubMenu")

function PANEL:Init()
	self:SetIsMenu(true)
	self:SetDrawBorder(true)
	self:SetPaintBackground(true)
	self:SetMinimumWidth(100)
	self:SetDrawOnTop(true)
	self:SetMaxHeight(ScrH() * 0.9)
	self:SetDeleteSelf(true)
	self:SetPadding(0)
	-- Automatically remove this panel when menus are to be closed
	RegisterDermaMenuForClose(self)
end

function PANEL:AddOption(strText, funcFunction)
	local pnl = vgui.Create("MMD.DMenuOption", self)
	pnl:SetMenu(self)
	pnl:SetText(strText)

	if (funcFunction) then
		pnl.DoClick = funcFunction
	end

	self:AddPanel(pnl)

	return pnl
end

function PANEL:AddSubMenu(strText, funcFunction)
	local pnl = vgui.Create("MMD.DMenuOption", self)
	local SubMenu = pnl:AddSubMenu(strText, funcFunction)
	pnl:SetText(strText)

	if (funcFunction) then
		pnl.DoClick = funcFunction
	end

	self:AddPanel(pnl)

	return SubMenu, pnl
end

derma.DefineControl("MMD.DMenu", "A Menu 2", PANEL, "DMenu")
local PANEL = {}
AccessorFunc(PANEL, "m_pMenu", "Menu")
AccessorFunc(PANEL, "m_bChecked", "Checked")
AccessorFunc(PANEL, "m_bCheckable", "IsCheckable")

function PANEL:Init()
	self:SetContentAlignment(4)
	self:SetTextInset(10, 0)
	self:SetFont("M_Roboto16")
	self:SetTextColor(MMD.Text["s"])
	self:SetChecked(false)
	self.Fade = 0
	self.Alpha = 0

	self.CordsEnter = {0, 0}

	self.ColorText = MMD.Text["s"]
end

function PANEL:OnCursorEntered()
	local mx, my = gui.MousePos()
	local x, y = self:ScreenToLocal(mx, my)
	self.Alpha = 0

	self.CordsEnter = {x, y}

	self.Hover = true

	if (IsValid(self.ParentMenu)) then
		self.ParentMenu:OpenSubMenu(self, self.SubMenu)

		return
	end

	self:GetParent():OpenSubMenu(self, self.SubMenu)
end

function PANEL:OnCursorExited()
	self.Hover = false
end

function PANEL:AddSubMenu()
	local SubMenu = MDermaMenu(true, self)
	SubMenu:SetVisible(false)
	SubMenu:SetParent(self)
	self:SetSubMenu(SubMenu)

	return SubMenu
end

function PANEL:Paint(w, h)
	if self.Hover then
		self.ColorText = MMD.Patern.MainColor["p"]
		self.Fade = 255
		self.Alpha = Lerp(FrameTime() * 5, self.Alpha, w + w / 2)
	else
		self.ColorText = MMD.Text["s"]
		self.Fade = Lerp(FrameTime() * 5, self.Fade, 0)
	end

	if self.Fade > 1 then
		MMD.DrawCircle(self.CordsEnter[1], self.CordsEnter[2], self.Alpha, MMD.ColorAlpha(MMD.Theme["m"], self.Fade))
	end

	self:SetTextColor(self.ColorText)
end

derma.DefineControl("MMD.DMenuOption", "Menu Option Line 2", PANEL, "DMenuOption")